############################################################
##a simple deterministic model for persistent TB
##written by Andreas Handel (ahandel@uga.edu), last change 7/1/14
##see the paper "Prolonged latency and reduced disease activation can improve population-level survival of M. tuberculosis" by Zheng, Whalen and Handel for more details
##should be run twice, onnce without and once with LHS sampling. See comments in script below
############################################################
rm(list=ls()) #this clears the workspace  
graphics.off(); #close all graphics windows,  
library(deSolve)  #loads ODE solver package.  
require(lhs)

###################################################################
#specify the function that describes the simple differential equation model for TB infection 
###################################################################
odeequations=function(t,y,parameters) 
{ 
  	S=y[1]; L=y[2];I=y[3];  
		N=(S+L+I); 
		 
   	dSdt=lam*N*(1-N/Nm)-beta*I*S-mu*S;   
		dLdt=(1-f)*beta*I*S+w*I-f*k*beta*I*L-L*a-mu*L;
		dIdt=f*beta*I*S + L*a + f*k*beta*I*L -(mu+mu_TB+w)*I;

		return(list(c(dSdt,dLdt,dIdt))); 
} #end function specifying the ODEs

                                                                                                         
###################################################################
#main program
###################################################################
tmax=4000
timevec=seq(0,tmax,by=0.2); #this creates a vector of times for which integration is evaluated  
set.seed(111) #seed for random number generator

#set up activation rate vector
ha=0.1 #max value for a
atot=50; #number of entries in a-vector
avec=seq(0,ha,length=atot)

#empty matrix to recor I, L, P, and alpha
Pvec1=rep(0,length(avec))
Iout1=rep(0,length(avec))
Lout1=rep(0,length(avec))
alpha1=rep(0,length(avec))
Pvec2=Pvec1; alpha2=alpha1; tpvec2=alpha1;  

#LHS sampled parameters - turn on (uncomment) one of the 2 lines, run model, then switch and run again
#samplemax.initial=1; filename='noLHSdata.Rdata'; mx=1; #choose this for a single run without sampling to get baseline
samplemax.initial=1000; filename='LHSdata.Rdata'; mx=2; #choose this to do LHS sampling over multiple parameter choices
#mx is factor by which bounds are increased/decreased, i.e. mx=2 means upper/lower bound are 2x and 1/2 of base value

lhssample=randomLHS(samplemax.initial,8)       #LHS for parameters

Nm.0=1; #max population size
Nmmin=Nm.0/mx; Nmmax=Nm.0*mx; Nmvec=(Nmmax-Nmmin)*lhssample[,1]+Nmmin  
lam.0=0.05;  #birth rate
lammin=lam.0/mx; lammax=lam.0*mx; lamvec=(lammax-lammin)*lhssample[,2]+lammin 
mu.0=0.02; #natural death rate
mumin=mu.0/mx; mumax=mu.0*mx; muvec=(mumax-mumin)*lhssample[,3]+mumin  
muTB.0=1/3; #TB induced dath rate
muTBmin=muTB.0/mx; muTBmax=muTB.0*mx; muTBvec=(muTBmax-muTBmin)*lhssample[,4]+muTBmin  
w.0=0.25; #rate of regression/recovery
wmin=w.0/mx; wmax=w.0*mx; wvec=(wmax-wmin)*lhssample[,5]+wmin 
k.0=0.5; #reduction of disease progression upon re-infection
kmin=k.0/mx; kmax=k.0*mx; kvec=(kmax-kmin)*lhssample[,6]+kmin  
f.0=0.1; #fast progression fraction
fmin=f.0/mx; fmax=f.0*mx; fvec=(fmax-fmin)*lhssample[,7]+fmin 
beta.0=10; #rate of transmission
betamin=beta.0/mx; betamax=beta.0*mx; bvec=(betamax-betamin)*lhssample[,8]+betamin;     

#throw out biologically unreasonable samples for which by chance death > birth
ind=(muvec<lamvec)
bvec=bvec[ind];  wvec=wvec[ind];  kvec=kvec[ind];  muvec=muvec[ind];
muTBvec=muTBvec[ind];  fvec=fvec[ind];  lamvec=lamvec[ind];  Nmvec=Nmvec[ind];

samplemax=length(lamvec) #update number of samples after we kicked those out those that were unreasonable
print(sprintf('%d samples were removed',samplemax.initial-samplemax)); #if this is large, might want to redo sampling with a different seed. If just a few are dropped, it's not a problem. One can always increase the initial number of samples.

MM=matrix(0,samplemax,length(avec))    #matrix to store P

Pmax1=rep(0,samplemax); alpmax1=Pmax1; amax1=Pmax1; 
Pmax2=rep(0,samplemax); alpmax2=Pmax2; amax2=Pmax2; tpmax2=Pmax2;

for (m in 1:samplemax) #loop for LHS samples
{      
  #LHS parameter values
  beta=bvec[m]
  w=wvec[m]
  k=kvec[m]
  mu=muvec[m]
  mu_TB=muTBvec[m]
  f=fvec[m]
  lam=lamvec[m]
  Nm=Nmvec[m]
  print(sprintf('starting sample %d/%d at time %s',m,samplemax,date()))
  #initial conditions             
  S0=(1-mu/lam)*Nm; #initial number of susceptible people 
	L0=0; #initial number of latent people
	I0=S0/1000; #initial number of infectious people
  Y0=c(S0, L0,I0);  #combine initial conditions into a vector 

  for (j in 1:length(avec))  #loop over activation rate for each sample
  {     
    a=avec[j]   #activation rate
    odeoutput=lsoda(Y0,timevec,odeequations,parms=NULL); #call ODE solver. Parameters are defined globally.
    tvec=odeoutput[,1];
    Svec=odeoutput[,2];
    Lvec=odeoutput[,3];
    Ivec=odeoutput[,4];
    alpvec=(avec[j]+k*f*beta*Ivec)/(avec[j]+mu+k*f*beta*Ivec)
    Pvec=Ivec+alpvec*Lvec; #persistence as function of time    
   
    #at SS
    Sf=tail(Svec,1); Lf=tail(Lvec,1);
    Iend=tail(Ivec,1); alpf=tail(alpvec,1)
    Nf=Sf+Lf+Iend;
    if (abs(Lf - odeoutput[length(tvec)-10,3]) > 1e-4) {print(sprintf('SS not reached')); browser();} #just a check to make sure we reach SS
   
    Iout1[j]=Iend   #I at steady state
    Lout1[j]=Lf     #L at steady state
    alpha1[j]=alpf; #alpha at SS
    Pvec1[j]=Iend+alpf*Lf #P at SS, recorded for every value of activation rate 
    
    #find P_m for non-SS scenario
    for (n in 2:(length(Ivec)-1)) #find 1st peak
    {
      if ((Ivec[n-1] < Ivec[n]) && (Ivec[n+1] < Ivec[n])) {break;} #leave loop, index n contains location of 1st peak
    }
    #Pm for epidemic non-SS state - after 1st peak
    #this way we make sure to not get the value at the very beginning
    Pvec.cut=Pvec[-(1:n)]; alpvec.cut=alpvec[-(1:n)];
    tvec.cut=tvec[-(1:n)];
    
    Pvec2[j]=min(Pvec.cut) #P_m for every value of activation rate
    tpvec2[j]=tvec.cut[which.min(Pvec.cut)] #time at which P_m happened for each activation rate
    alpha2[j]=alpvec.cut[which.min(Pvec.cut)] #non SS alpha for every value of activation rate
  
  } #ends loop over activation rate
  
  ind1=which.max(Pvec1) #find max persistence for SS for each parameter sample
  Pmax1[m]=Pvec1[ind1]; #for SS
  amax1[m]=avec[ind1];  #for SS
  alpmax1[m]=alpha1[ind1]; #for SS

  ind2=which.max(Pvec2) #find max persistence for non-SS for each parameter sample
  Pmax2[m]=Pvec2[ind2]; 
  amax2[m]=avec[ind2];  
  alpmax2[m]=alpha2[ind2]; 
  tpmax2[m]=tpvec2[ind2]; #find time at which Pm happened
}

save(list=ls(), file = filename);   #saves the whole workspace with all results into file. This file will be loaded by the figure script to produce figures.
 

###################################################################
#end main program
###################################################################                           
  
