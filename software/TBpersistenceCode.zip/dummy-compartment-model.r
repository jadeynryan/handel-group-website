############################################################
##a simple deterministic model for persistent TB
##uses dummy-compartments to achieve more realistic (i.e. gamma-distributed) waiting times in latent and infected compartments
##written by Andreas Handel (ahandel@uga.edu), last change 7/1/14
##see the paper "Prolonged latency and reduced disease activation can improve population-level survival of M. tuberculosis" by Zheng, Whalen and Handel for more details
##should be run several times at J=1,10,50,100 to be used with figure script 
############################################################
rm(list=ls()) #this clears the workspace  
graphics.off(); #close all graphics windows,  
library(deSolve)  #loads ODE solver package.  
library(lhs) #for parameter sampling
  
###################################################################
odeequations=function(t,y,parameters) 
{ 
  	if (J>2) #model with dummy compartments
  	{
    S=y[1:J]; L=y[(J+1):(2*J)]; I=y[(2*J+1):(3*J)];
    St=sum(S); Lt=sum(L); It=sum(I);  
    N=St+Lt+It;

    dS1=lam*N*(1-N/Nm)-b*It*S[1]-del*S[1]
		dSj=del*S[1:(J-2)]-del*S[2:(J-1)]-b*It*S[2:(J-1)]
    dSJ=del*S[J-1]-b*It*S[J]-del*S[J]
    
    dL1=(1-f)*b*It*S[1]       -a*L[1]       + w*I[1]      -f*k*b*It*L[1]       - del*L[1]
    dLj=(1-f)*b*It*S[2:(J-1)] -a*L[2:(J-1)] +w*I[2:(J-1)] -f*k*b*It*L[2:(J-1)] + del*L[1:(J-2)] - del*L[2:(J-1)]
    dLJ=(1-f)*b*It*S[J]       -a*L[J]       + w*I[J]      -f*k*b*It*L[J]       - del*L[J]
    
    dI1=f*b*It*S[1]       +a*L[1]       -w*I[1]       +f*k*b*It*L[1]       -(w+mu_TB)*I[1]       - del*I[1]
    dIj=f*b*It*S[2:(J-1)] +a*L[2:(J-1)] -w*I[2:(J-1)] +f*k*b*It*L[2:(J-1)] -(w+mu_TB)*I[2:(J-1)] + del*I[1:(J-2)]-del*I[2:(J-1)]
    dIJ=f*b*It*S[J]       +a*L[J]       -w*I[J]       +f*k*b*It*L[J]       -(w+mu_TB)*I[J]       - del*I[J]
		return(list(c(dS1,dSj,dSJ,dL1,dLj,dLJ,dI1,dIj,dIJ))); 
    }
    
    if (J==1) #basic exponential model, for comparison
    {
   	S=y[1]; L=y[2]; I=y[3];  
   	dSdt=lam*(S+L+I)*(1-(S+L+I)/Nm)-b*I*S-del*S;   
		dLdt=(1-f)*b*I*S+w*I-f*k*b*I*L-L*a-del*L;
		dIdt=f*b*I*S + L*a + f*k*b*I*L -(del+mu_TB+w)*I;

		return(list(c(dSdt,dLdt,dIdt))); 
     }
 
} #end function specifying the ODEs

                                                                                                         
###################################################################
#main program
###################################################################
  tmax=500
  timevec=seq(0,tmax,by=1); #this creates a vector of times for which integration is evaluated  

  J=100; #number of dummy compartments - minimum is 3, just because of the way it's coded. Can also be 1 to run the simple ODE model
	
  #set up activation rate vector
	ha=0.1 #max value for a
	atot=50;
	avec=seq(0,ha,length=atot)
	
	#empty matrix to recor I, L, P, and alpha
	Pvec1=rep(0,length(avec))
	Iout1=rep(0,length(avec))
	Lout1=rep(0,length(avec))
	alpha1=rep(0,length(avec))
  Pvec2=Pvec1; alpha2=alpha1; tpvec=alpha1;
  
  #LHS sampled parameters - could be done, is not implemented right now. To skip lhs sampling, set samplemax.initial=1 and mx=1 (i.e. only 1 sample, at baseline).
  #not really used right now, but could be done
  samplemax.initial=1
  mx=1;
  
  lhssample=randomLHS(samplemax.initial,8)       #LHS for parameters
 
  Nm.0=1; #max population size
  Nmmin=Nm.0/mx; Nmmax=Nm.0*mx; Nmvec=(Nmmax-Nmmin)*lhssample[,1]+Nmmin  #LHS for lam
  lam.0=0.05;  #inflow rate
  lammin=lam.0/mx; lammax=lam.0*mx; lamvec=(lammax-lammin)*lhssample[,2]+lammin  #LHS for lam
  mu.0=0.02; #natural death rate
  mumin=mu.0/mx; mumax=mu.0*mx; muvec=(mumax-mumin)*lhssample[,3]+mumin  #LHS for mu
  muTB.0=1/3; #TB induced dath rate
  muTBmin=muTB.0/mx; muTBmax=muTB.0*mx; muTBvec=(muTBmax-muTBmin)*lhssample[,4]+muTBmin  #LHS for mu_TB
  w.0=0.25; #rate of regression/recovery
  wmin=w.0/mx; wmax=w.0*mx; wvec=(wmax-wmin)*lhssample[,5]+wmin  #LHS for w
  k.0=0.5; #reduction of disease progression upon re-infection
  kmin=k.0/mx; kmax=k.0*mx; kvec=(kmax-kmin)*lhssample[,6]+kmin  #LHS for k
  f.0=0.1; #fast progression fraction
  fmin=f.0/mx; fmax=f.0*mx; fvec=(fmax-fmin)*lhssample[,7]+fmin  #LHS for f
  beta.0=10; #rate of transmission
  betamin=beta.0/mx; betamax=beta.0*mx; bvec=(betamax-betamin)*lhssample[,8]+betamin;     #LHS for beta
  
  #throw out samples for which death > birth
  ind=(muvec<lamvec)
  
  bvec=bvec[ind];
  wvec=wvec[ind];
  kvec=kvec[ind];
  muvec=muvec[ind];
  muTBvec=muTBvec[ind];
  fvec=fvec[ind];
  lamvec=lamvec[ind];
  Nmvec=Nmvec[ind];
 
  samplemax=length(lamvec) #update number of samples after we kicked those out that were unreasonable
  
  MM=matrix(0,samplemax,length(avec))    #matrix to store P
 
 
  Pmax=rep(0,samplemax); alpmax=Pmax; amax=Pmax; 
  Pmax2=rep(0,samplemax); alpmax2=Pmax2; amax2=Pmax2; 

  for (m in 1:samplemax) #loop for LHS samples
  {      

  #LHS parameter values
  Nm=Nmvec[m]
  b=bvec[m]
  w=wvec[m]
  k=kvec[m]
  mu_TB=muTBvec[m]
  f=fvec[m]
  lam=lamvec[m]
  mu=muvec[m]
  del=J*mu; 

  print(sprintf('starting sample %d/%d with J=%d',m,samplemax,J))
  S0=1-mu/lam; #initial number of susceptible people 
	L0=0; #initial number of latent people
	I0=S0/1000; #initial number of infectious people
  Y0=c(rep(S0,J)/J, rep(L0,J),rep(I0,J)/J);  #combine initial conditions into a vector 

  for (an in 1:length(avec))  #for each parameter set, loop for activation rate
  { 
    a=avec[an]   #activation rate
    odeoutput=lsoda(Y0,timevec,odeequations,parms=NULL);
    
    if (J>2) #retrieve results from ode solver depending on if dummy compartments were used or not
    {
      Svec=rowSums(odeoutput[,2:(J+1)]) ;
      Lvec=rowSums(odeoutput[,(J+2):(2*J+1)]);
      Ivec=rowSums(odeoutput[,(2*J+2):(3*J+1)]);
    }
    if (J==1)
    {
      Svec=odeoutput[,2];
      Lvec=odeoutput[,3];
      Ivec=odeoutput[,4];
    }
    
    alpvec=(avec[an]+k*f*b*Ivec)/(avec[an]+mu+k*f*b*Ivec)
    Pvec=Ivec+alpvec*Lvec;     
   
    #deterministic model at SS
    Sf=tail(Svec,1);
    Lf=tail(Lvec,1);
    Iend=tail(Ivec,1);
    alpf=tail(alpvec,1)
    Nf=Sf+Lf+Iend;
    if ((Iend - Ivec[length(Ivec)-1])>0.001) {cat('SS not reached')}
   
    Iout1[an]=Iend     #I at steady state
    Lout1[an]=Lf     #L at steady state
    alpha1[an]=alpf;  #alpha at SS
    Pvec1[an]=Iend+alpf*Lf #P at SS 

    #finding non-SS P_m    
    for (n in 2:(length(Ivec)-1)) #find 1st peak
    {
      if ((Ivec[n-1] < Ivec[n]) && (Ivec[n+1] < Ivec[n])) {break;} #leave loop, index n contains location of 1st peak
    }
    #Pm for epidemic non-SS state - after 1st peak
    Pvec.cut=Pvec[-(1:n)]; alpvec.cut=alpvec[-(1:n)];
    Pvec2[an]=min(Pvec.cut)
    tpvec[an]=which.min(Pvec.cut)
    alpha2[an]=alpvec.cut[tpvec[an]]
  
  } #end loop over all values of a

  ind=which.max(Pvec1) #find max persistence
  Pmax[m]=Pvec1[ind]; #for SS
  amax[m]=avec[ind];  #for SS
  alpmax[m]=alpha1[ind]; #for SS

  ind2=which.max(Pvec2) #find max persistence
  Pmax2[m]=Pvec2[ind]; #for SS
  amax2[m]=avec[ind];  #for SS
  alpmax2[m]=alpha2[ind]; #for SS
                                                  
  } #end loop over all LHS samples 
        
filename=paste('noLHSdata-dummymodel-J',as.character(J),'.Rdata',sep="") #save results in file. Will be loaded by script producing figures
save(list=ls(), file = filename);

###################################################################
#end main program
###################################################################                           