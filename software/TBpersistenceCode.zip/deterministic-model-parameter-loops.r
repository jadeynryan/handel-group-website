############################################################
##a simple deterministic model for persistent TB
## this code loops over various model parameters in addition to activation rate to produce data for 2-d heatmaps of persistence as function of activation rate and a 2nd model parameter
##written by Andreas Handel (ahandel@uga.edu), last change 7/1/14
##see the paper "Prolonged latency and reduced disease activation can improve population-level survival of M. tuberculosis" by Zheng, Whalen and Handel for more details
############################################################
############################################################
rm(list=ls()) #this clears the workspace  
graphics.off(); #close all graphics windows,  
library(deSolve)  #loads ODE solver package.  

###################################################################
#specify the function that describes the simple differential equation model for TB infection 
###################################################################
odeequations=function(t,y,parameters) 
{ 
  	S=y[1]; L=y[2];I=y[3];  
		N=(S+L+I); 
   	dSdt=lam*N*(1-N/Nm)-b*I*S-mu*S;  
		dLdt=(1-f)*b*I*S+w*I -f*k*b*I*L - L*a - mu*L;
		dIdt=f*b*I*S         +f*k*b*I*L + L*a - (mu+muTB+w)*I;

		return(list(c(dSdt,dLdt,dIdt)));
} #end function specifying the ODEs

                                                                                                         
###################################################################
#main program
###################################################################
  tmax=2000
  timevec=seq(0,tmax,by=0.2); #this creates a vector of times for which integration is evaluated  
	
  #set up activation rate vector
	ha=0.05 #max value for a
	atot=100/1;
	avec=seq(0,ha,length=atot)
	
	#empty matrix to recor I, L, P, and alpha
	Pvec1=rep(0,length(avec))
	Iout1=rep(0,length(avec))
	Lout1=rep(0,length(avec))
	alpha1=rep(0,length(avec))
  Pvec2=Pvec1; alpha2=alpha1; tpvec2=alpha1;
 
  for (pn in 1:8) #loop over all parameters
  {
  
    filename=paste('parameter',as.character(pn),'loop.Rdata',sep='');  #save results for each model parameter into a separate file
    #base parameters
    Nm=1; #max population size
    lam=0.05;  #inflow rate
    mu=0.02; #natural death rate
    muTB=1/3; #TB induced dath rate
    w=0.25; #rate of regression/recovery
    k=0.5; #reduction of disease progression upon re-infection
    f=0.1; #fast progression fraction
    b=10; #rate of transmission 
    
    ptot=80; #number of points for each parameter which is varied
    
    Nmvec=seq(Nm/2,2*Nm,length=ptot); #vary parameters between 1/2 and 2x baseline
    lamvec=seq(lam/2,2*lam,length=ptot);
    muvec=seq(mu/2,2*mu,length=ptot);
    muTBvec=seq(0.15,0.65,length=ptot); #to make labeling easier, go from 0.15 - 0.65 instead of 1/6 - 2/3 (=muTB/2 - 2*muTB)
    wvec=seq(w/2,2*w,length=ptot);
    kvec=seq(k/2,2*k,length=ptot);
    fvec=seq(f/2,2*f,length=ptot);
    bvec=seq(b/2,2*b,length=ptot);
    
    Pmat1=matrix(0,atot,ptot); Pmat2=Pmat1; #save results in these matrices
    Pmax1=rep(0,ptot); alpmax1=Pmax1; amax1=Pmax1; 
    Pmax2=rep(0,ptot); alpmax2=Pmax2; amax2=Pmax2; tpmax2=Pmax2;
      
                  
    for (pval in 1:ptot) #loop over each parameter
    {
      
      print(sprintf('parameter %d, value %d',pn,pval))
      
      if (pn==1) {Nm=Nmvec[pval]}
      if (pn==2) {lam=lamvec[pval]}
      if (pn==3) {mu=muvec[pval]}
      if (pn==4) {muTB=muTBvec[pval]}
      if (pn==5) {w=wvec[pval]}
      if (pn==6) {k=kvec[pval]}
      if (pn==7) {f=fvec[pval]}
      if (pn==8) {b=bvec[pval]}
    
      #initial conditions             
      S0=(1-mu/lam)*Nm; #initial number of susceptible people 
    	L0=0; #initial number of latent people
    	I0=S0/1000; #initial number of infectious people
      Y0=c(S0, L0,I0);  #combine initial conditions into a vector 

      for (j in 1:length(avec)) #loop over activation rate of each parameter 
      { 
        a=avec[j]   #activation rate
        odeoutput=lsoda(Y0,timevec,odeequations,parms=NULL);
        
        tvec=odeoutput[,1];
        Svec=odeoutput[,2];
        Lvec=odeoutput[,3];
        Ivec=odeoutput[,4];
        alpvec=(avec[j]+k*f*b*Ivec)/(avec[j]+mu+k*f*b*Ivec)
        Pvec=Ivec+alpvec*Lvec;     
   
        #at SS
        Sf=tail(Svec,1);
        Lf=tail(Lvec,1);
        Iend=tail(Ivec,1);
        alpf=tail(alpvec,1)
        Nf=Sf+Lf+Iend;
        if (abs(Lf - odeoutput[length(tvec)-10,3]) > 1e-3) {print(sprintf('SS not reached')); browser();}
   
        Iout1[j]=Iend     #I at steady state
        Lout1[j]=Lf     #L at steady state
        alpha1[j]=alpf;  #alpha at SS
        Pvec1[j]=Iend+alpf*Lf #P at SS 
     
        #find P_m for non-SS scenario
        for (n in 2:(length(Ivec)-1)) #find 1st peak
        {
          if ((Ivec[n-1] < Ivec[n]) && (Ivec[n+1] < Ivec[n])) {break;} #leave loop, index n contains location of 1st peak
        }
        #Pm for epidemic non-SS state - after 1st peak
        #this way we make sure to not get the value at the very beginning
        Pvec.cut=Pvec[-(1:n)]; alpvec.cut=alpvec[-(1:n)];
        tvec.cut=tvec[-(1:n)];
    
        Pvec2[j]=min(Pvec.cut) #P_m for every value of activation rate
        tpvec2[j]=tvec.cut[which.min(Pvec.cut)] #time at which P_m happened for each activation rate
        alpha2[j]=alpvec.cut[which.min(Pvec.cut)] #non SS alpha for every value of activation rate
     
        Pmat1[j,pval]=Pvec1[j];
        Pmat2[j,pval]=Pvec2[j];
      } # finish loop over activation rate
     
      #record P and Pm for each activation rate and 
      ind1=which.max(Pvec1) #find max persistence for SS for each parameter sample
      Pmax1[pval]=Pvec1[ind1]; #for SS
      amax1[pval]=avec[ind1];  #for SS
      alpmax1[pval]=alpha1[ind1]; #for SS
    
      ind2=which.max(Pvec2) #find max persistence for non-SS for each parameter sample
      Pmax2[pval]=Pvec2[ind2]; 
      amax2[pval]=avec[ind2];  
      alpmax2[pval]=alpha2[ind2]; 
      tpmax2[pval]=tpvec2[ind2]; #find time at which Pm happened
                                                    
  } #finish loop over each individual parameter

  #save result into file for each parameter
  save(list=ls(), file = filename);

} # finish loop over all parameters

###################################################################
#end main program
###################################################################                           
  
