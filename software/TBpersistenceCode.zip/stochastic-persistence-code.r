############################################################
##a stochastic model for persistent TB
##written by Andreas Handel (ahandel@uga.edu), last change 7/1/14
##see the paper "Prolonged latency and reduced disease activation can improve population-level survival of M. tuberculosis" by Zheng, Whalen and Handel for more details
############################################################
rm(list=ls()) #this clears the workspace to make sure no leftover variables are floating around. Not strictly needed
graphics.off(); #close all graphics windows
require(adaptivetau) #uses the package adaptivetau to perform the stochastic simulation
require(snow) #for parallel runs on multiple cores
require(deSolve) #differential equation solver

#function to specify ODE model
odeequations = function(t,y,p) #the function needs to have a certain form, dictated by deSolve
{ 
  	S=y[1]; L=y[2]; I=y[3];  #S,L,I: number of susceptible,latent,and infectious people,respectively
		
		dS=p["lam"]*(S+L+I)*(1-(S+L+I)/p["Nm"]) - p["b"]*I*S - p["mn"]*S;   #
		dL=(1-p["f"])*p["b"]*I*S - p["f"]*p["k"]*p["b"]*I*L + p["w"]*I - p["a"]*L - p["mn"]*L;
		dI=p["f"]*p["b"]*I*S + p["a"]*L + p["f"]*p["k"]*p["b"]*I*L - p["md"]*I - p["w"]*I - p["mn"]*I;
  
		return(list(c(dS,dL,dI))); #this command returns the result back to the solver (i.e. lsoda). 
} #end function specifying the ODEs



#function to specify stochastic model, as dictated by the adaptivetau package
transrates = function(x, p, t)  #no reinfection
{
         rates=c(p["lam.stoch"]*(x["S"]+x["I"]+x["L"])*(1-(x["S"]+x["I"]+x["L"])/p["Nm"]),                #birth               
                 (1-p["f"])*p["b"]*x["S"]*x["I"], #slow progression         
                 p["f"]*p["b"]*x["S"]*x["I"],     #fast progression     
                 p["mn"]*x["S"],              #natural death    of susceptible              
                 p["a"]*x["L"]+p["f"]*p["k"]*p["b"]*x["L"]*x["I"],              #latent activation and reinfection
                 p["mn"]*x["L"],              #natural death  of latent              
                 p["w"]*x["I"],                 #recovery                
                 (p["mn"]+p["md"])*x["I"])         #natural and disease induced death


          return(rates)
}

#function to parallelize things 
#each scenario/realization is the same, so nn is not really used
parallel.fc <- function(nn)
{
      out=ssa.adaptivetau(Y0,M,transrates,pvec.stoch,tmax,tl.params = list(extraChecks=FALSE))
      result=tail(out,1)[2:4] #S, L and I at end of simulation
}
 


#################################
#main program
#################################
tstart=proc.time(); #capture current time to measure duration of process

#the seed initializes the random number generator to a specific value. For the same seed, the same sequence of (pseudo)-random numbers is returned
#this is very important to allow for reproducibility/model comparison/debugging/etc.
#if you change this number, a different sequence of random numbers will be produced, leading to different simulation results
set.seed(111) 

real.time.start=date(); #get current time to measure length of optimization for each strain

#print(sprintf('Simulation %d started at %s',popdyn, real.time.start));

# State-change matrix - 3 variables, 8 reactions each column is one reaction
M = cbind( c(1,0,0), c(-1,1,0), c(-1,0,1), c(-1,0,0) , c(0,-1,1), c(0,-1,0), c(0,1,-1), c(0,0,-1) ) 
tmax = 1000           # years to run for stochastic simulation
samplemax=10000; #number of runs for a given parameter set
 
mn=1/50.0 #natural life expectancy - all units of years
md=1/3.0  #TB patient life expectancy
lam=0.05; #birth rate
b0=10   #transmission coefficient
w=0.25 #rate of recovery
f=0.1; #fast progression fraction
k=0.5; #reactivation fraction
                 
avec=c(seq(0,0.01,length=30),seq(0.011,0.1,length=70)) #values of a for which simulations are run - unevenly spaced to resolve initial steep rise better

parallel.comp=1; #turn on or off parallel computing 
node.num=50; #number of sockets/nodes to use for parallel computing
node.type=2; #choose socket/node type. 1 for SOCK (can be run locally), 2 for an MPI cluster

if (parallel.comp==0) #standard non-parallel run using 1 core
   {  
        node.num=1; #just for printing purposes below
        node.type=1; #always set to 1 so script doesn't try to quit MPI in the last line
        #next command applies the specified function and runs it for each value in "scenarios"
        reslist <- lapply(1:samplemax, parallel.fc)   #reslist contains results for all scenarios
  }
if (parallel.comp==1) #using snow package to do parallel computing
 {
      if (node.type==1) {clust <- makeCluster(node.num, type = "SOCK")} #use this to run on your local multi-core machine
      if (node.type==2) {clust <- makeCluster(node.num, type = "MPI")} #use this to run on an MPI cluster
      clusterEvalQ(clust, library(adaptivetau)) #load any needed packages on each node. Those packages need to be installed on each node.
 } 


for (popdyn in 1:3) #main loop - steady, growing, declining populations
{



if (popdyn==1) #those 3 files contain the results for steady, growing and declining populations
{
  filename="stochasticres-steady.Rdata"; 
  lam.stoch=lam;
}
if (popdyn==2) 
{
  filename="stochasticres-growth.Rdata";
  lam.stoch=1.2*lam;
}
if (popdyn==3) 
{
  filename="stochasticres-decline.Rdata";
  lam.stoch=0.8*lam;
}


                                           
timevec.det=seq(0,1000,by=10); #this creates a vector of times for which integration is evaluated - just used for ODE model

persistfrac=rep(0,length(avec)) #all results
SSvec=matrix(0,ncol=3,nrow=length(avec)); #matrix that will contain steady state values
Pvec=rep(0,length(avec)) #vector that will contain values for persistence


for (ct in 1:length(avec)) #loop over all values of a
{
    a=avec[ct]

    print(sprintf('starting run %d/%d for activation rate %f',ct,length(avec),a))

    #run ODE model to get steady state - used as starting condition for stochastic solver
    #initial conditions for deterministic model             
    Nm=100;
    b=b0/Nm;
    S0=Nm*(1-mn/lam)
    pvec=c(mn=mn,md=md,lam=lam,b=b,w=w,f=f,k=k,a=a,Nm=Nm);
    pvec.stoch=c(mn=mn,md=md,lam.stoch=lam.stoch,b=b,w=w,f=f,k=k,a=a,Nm=Nm);
  	#call ode-solver to integrate ODEs. 
    #this produces the initial condition at which stochastic model is started
    odeout=lsoda(c(S0,0,1e-4),timevec.det,odeequations,pvec);
    S0=ceiling(tail(odeout,1)[2])
    L0=ceiling(tail(odeout,1)[3])
    I0=ceiling(tail(odeout,1)[4])
    SSvec[ct,]=c(S0,L0,I0);
    Y0=c(S=S0,L=L0,I=I0)   
    #browser()    
    
    #once more for SS with population Nm = 1, used to compute deterministic P for comparison with stochastic model
    Nm=1;
    b=b0/Nm;
    S0=Nm*(1-mn/lam)
    pvec2=c(mn=mn,md=md,lam=lam,b=b,w=w,f=f,k=k,a=a,Nm=Nm);
    odeout=lsoda(c(S0,0,1e-4),timevec.det,odeequations,pvec2);
    S0=(tail(odeout,1)[2])
    L0=(tail(odeout,1)[3])
    I0=(tail(odeout,1)[4])
    alpha=(a+k*f*b*I0)/(a+mn+k*f*b*I0)
    Pvec[ct]=I0+alpha*L0;  
  
  
    if (parallel.comp==0) #standard non-parallel run using 1 core
    {  
         #next command applies the specified function and runs it for each value in "scenarios"
        reslist <- lapply(1:samplemax, parallel.fc)   #reslist contains results for all scenarios
    }
    if (parallel.comp==1) #using snow package to do parallel computing
    {
      clusterExport(clust,ls()) #make global variables available on each node
      #next command applies the specified function and runs it for each value in "scenarios"
      #it does some kind of load balancing to try and use faster nodes more often than slower nodes
      reslist <- clusterApplyLB(clust, 1:samplemax, parallel.fc) #reslist contains results for all scenarios
    } 
    Sf=rep(0,samplemax); Lf=Sf; If=Sf;
    for (nn in 1:samplemax)
    {
     Sf[nn]=reslist[[nn]][1]
     Lf[nn]=reslist[[nn]][2]
     If[nn]=reslist[[nn]][3]
    }
    persistfrac[ct]=1-sum(Sf>0 & (Lf+If == 0))/sum(Sf>0); #ignore runs where extinction happened due to susceptible dying out
} #loop over activation rate


real.time.stop=date();
tend=proc.time(); #capture current time
tdiff=tend-tstart;
runtime.minutes=tdiff[[3]]/60; #run time in minutes

save(list = ls(all=TRUE), file = filename); #save results into a file, to be processed by another script that produces the result figures

} #ends loop over different popdyn scenarios

#this printed to the screen will only show up when run locally, not on a distributed MPI cluster. But it won't hurt.
print(sprintf('Simulation ended at %s and took %f minutes using %d sockets',real.time.stop,runtime.minutes,node.num));
alarm(); Sys.sleep(0.5); alarm(); Sys.sleep(0.5); alarm(); #play alarm to signal end of run - only works on local machine

if (parallel.comp==1)
{
  stopCluster(clust)  #shut down the parallel cluster  
}


if (node.type==2) {mpi.quit() } #quit MPI libraries. 
###################################################################
#end  program
###################################################################                     