##################################################################
#R script to pre-process and clean the raw data from the Kawempe study
#written by Andreas Handel (ahandel@uga.edu).
##################################################################
rm(list=ls());
graphics.off();
library(plyr)
library(dplyr) #for data manipulation
library(mice)

##################################################################
#read data from a CSV file
#see the accompanying codebook for details on the data
raw.data=read.csv('../rawdata/kawempe-study/kawempe_data.csv')

#make a copy of the original data
mydata=raw.data

#rename outcome to be consistent across datasets
smalldat1 <- mydata %>% dplyr::rename(totalcoughdays = cough_duration)

#change all 999 which code for missing values to NA
smalldat1[smalldat1 == 999] <- NA

#remove individuals that have missing outcome data 
smalldat2 <- smalldat1 %>% dplyr::filter( !is.na(totalcoughdays) )

#remove variables that are not useable as predictors for analysis
smalldat5 <- smalldat2 %>% dplyr::select( -c(peoprmnew, study, Relation_to_index_case, RFLP_matching) ) 

#remove more variables
#tribe has too many factor levels, not useful
#Grade of eduction is too similar to education level
##lots of missing in weightnew, remove that variable
##remove "know other TB case" since it has lots of unique missing 
##remove IFN  since it has lots of unique missing 
smalldat6 <- smalldat5 %>% dplyr::select( -c(tribe, Grade_of_education, weightnew, Interferon_levels, Know_another_TB_case))



#remove more variables
#only few entries in one of these YES/NO categories, makes predictor not useful
smalldat7 <- smalldat6 %>% dplyr::select( -c(coprindx, prior_TB, Culture_status ))

#remove more variables
#delete variables that are categorized versions of other variables
smalldat8 <- smalldat7 %>% dplyr::select( -c(People_per_room) )

#remove more variables
#drop some variables that measure contacts not index cases
smalldat9 <- smalldat8 %>% dplyr::select( - c(Contacts_10mm_at_baseline, Contacts_5mm_at_baseline, Proportion_infected_10mm, Proportion_infected_5mm, TST_induration))

#rename some variables
smalldat10 <- smalldat9 %>% dplyr::rename(Smoking_status = smoker, Smear_status = Smear, Education_level = Education, Alcohol_use = Drinking_status, People_per_room = People_per_room_continuous, Number_of_windows = Window)

smalldat.f <- smalldat10

#ensure variables are properly coded as numeric or factor
fact<-colnames(smalldat.f) #first convert everything to factors, then switch back the few that are numeric
x <- which(names(smalldat.f) %in% fact) 
smalldat.f[,x] <- lapply(smalldat.f[,x], as.factor) 

#converting factors to numeric in R is weird, needs to go through an extra step
#this 1-line function does it
as.numeric.factor <- function(x) {as.numeric(levels(x))[x]} 
num_vars <- smalldat.f %>% dplyr::select(age, BMI, Doors_per_room, Number_in_household, Number_of_household_contacts, People_per_room, totalcoughdays, Number_of_windows)
nums <- colnames(num_vars)
x <- which(names(smalldat.f) %in% nums) 
smalldat.f[,x] <- lapply(smalldat.f[,x], as.numeric.factor) #change numeric variables back from factor variables 


#place outcome (cough days) in first column
smalldat.sort <- smalldat.f %>% dplyr::select(totalcoughdays, everything() )

#too few entries with smear status 7/scanty, combine with 0/negative
smalldat.sort$Smear_status <- mapvalues(smalldat.sort$Smear_status, c(0,1,2,3,7), c(0,1,2,3,0))

#religion 4 and 5 have too few entries and codebook doesn't define what 5 is
#combine with 6/other such that it's 1/2/3/6 catholic/anglican/muslim/other
smalldat.sort$religion <- mapvalues(smalldat.sort$religion, c(1,2,3,4,5,6), c(1,2,3,6,6,6))

#education level has a few categories with too few entries
#recode into low/high (1/2) education level
smalldat.sort$Education_level <- mapvalues(smalldat.sort$Education_level, c(0,1,2,3,4), c(1,1,2,2,2))

#drop any unused factor levels
smalldat.sort <- droplevels(smalldat.sort)


#final name of processed/cleaned data
data_kawempe_clean <- smalldat.sort

##################################################################
#linear model can't deal with missing values, need to make a dataset for this method that doesn't contain missing
#check for columns/variables with NA
x=colSums(is.na(data_kawempe_clean)) 
print(x) 

#drop observations that have missing values
data_kawempe_clean_completecases <- droplevels(data_kawempe_clean[complete.cases(data_kawempe_clean),])


##impute missing values 
data_kawempe_imputed <- mice::complete(mice(data = data_kawempe_clean, m = 1, defaultMethod = c('rf','rf','rf')))
#drop any unused factor levels
data_kawempe_clean_imputed <- droplevels(data_kawempe_imputed)

##################################################################
#save cleaned/processed data to files
saveRDS(data_kawempe_clean, file='../cleandata/data_kawempe_clean.rds')
saveRDS(data_kawempe_clean_completecases, file='../cleandata/data_kawempe_clean_completecases.rds')
saveRDS(data_kawempe_clean_imputed, file='../cleandata/data_kawempe_clean_imputed.rds')
