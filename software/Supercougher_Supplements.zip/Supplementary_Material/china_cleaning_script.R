##################################################################
#R script to pre-process and clean the raw data from the China study
#written by Andreas Handel (ahandel@uga.edu). 
##################################################################
rm(list=ls());
graphics.off();
library(plyr) #for data manipulation
library(dplyr) #for data manipulation
library(mice)


##################################################################
#read data from a CSV file
#see the accompanying codebook for details on the data
raw.data=read.csv('../rawdata/china-study/china_data.csv')

#make a copy of the original data
mydata=raw.data

#rename outcome to be consistent across datasets
smalldat1 <- mydata %>% dplyr::mutate(totalcoughdays =durationcough_days)

#remove observations for individuals that have missing data for outcome of interest (duration of cough) 
smalldat2 <- smalldat1 %>% dplyr::filter( !is.na(totalcoughdays) )

#remove variable income since it has too many missing
#also drop original outcome variable
smalldat3 <- smalldat2 %>% dplyr::select( -c(income,durationcough_days) ) 

#convert most predictors to categorical/factors
allnames <- colnames(smalldat3) 
facvars <- allnames[-which(allnames %in% c('totalcoughdays','age','numsteps'))] #these are not categorical
x <- which(names(smalldat3) %in% facvars) 
smalldat3[,x] <- lapply(smalldat3[,x], as.factor) 

#rename some variables for easier understanding
smalldat4 <- smalldat3 %>% dplyr::rename(Smoking_status = smoker, Employment_status = employment, Marital_status = marriage, Prior_TB = tbepis, Diabetes_status = diabetes, owned_cell_phone = cellphone, person_suspected_TB = suspect)

#save as intermediate variable
smalldat.f <- smalldat4

#place outcome (cough days) in first column
smalldat.sort <- smalldat.f %>% dplyr::select(totalcoughdays, everything() )

#drop any unused factor levels
smalldat.sort <- droplevels(smalldat.sort)


#final name of processed/cleaned data
#this datastill can still contain missing values
data_china_clean <- smalldat.sort

##################################################################
#save cleaned/processed data to file
#this data file will be used by other scripts
#saving as Rdata to not loose factor coding and such 
saveRDS(data_china_clean, file='../cleandata/data_china_clean.rds')



##################################################################
#linear model can't deal with missing values, need to make a dataset for this method that doesn't contain missing
#look at all the missing values
#check for columns/variables with NA
x=colSums(is.na(data_china_clean)) 
print(x) 

##pretty complete dataset, only 1 missing.

## remove further columns with lots of missing and/or missing rows/observations to get to a complete dataset 
data_china_clean_completecases <- data_china_clean[complete.cases(data_china_clean),]
data_china_clean_completecases <- droplevels(data_china_clean_completecases)

#perform imupation on missing data using the mice package
data_china_clean_imputed <- mice::complete(mice(data_china_clean,m=1))
#drop any unused factor levels
data_china_clean_imputed <- droplevels(data_china_clean_imputed)


##################################################################
#save cleaned/processed data to file
#this data file contains no NA and can be used for linear modeling
#saving as Rdata to not loose factor coding and such 
saveRDS(data_china_clean_completecases, file='../cleandata/data_china_clean_completecases.rds')
saveRDS(data_china_clean_imputed, file='../cleandata/data_china_clean_imputed.rds')




