The following materials are included as SM:

* Each dataset has a codebook and an associated R script which cleans and processes the raw data before analysis. We are unfortunately not able to share the raw data. As such, it is not possible to run the scripts, but they show the details of how the analysis is performed. If you are interested in obtaining the underlying data, you can get in touch with the corresponding author, who can connect you with the "owners" of the data to see if they might be willing to share their respective datasets.


* The R scripts starting with SS perform all descriptive and statistical analyses described in the paper and SM and produce all tables and figures. Again, due to data availability limitations, those scripts can unfortunately not be run, but they show how each step of the analysis is done.
