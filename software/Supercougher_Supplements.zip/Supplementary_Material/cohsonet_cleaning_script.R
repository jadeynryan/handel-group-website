##################################################################
#R script to pre-process and clean the raw data from the COHSONET study
#written by Andreas Handel (ahandel@uga.edu). 
##################################################################
rm(list=ls());
graphics.off();
library(plyr) #for data manipulation
library(dplyr) #for data manipulation
library(mice) #for imputation

##################################################################
#read data from a tab-delimited txt file
#see the accompanying codebook for details on the data
raw.data=read.csv('../rawdata/cohsonet-study/cohsonet_data.csv')

#make a copy of the original data
mydata=raw.data

#rename outcome to be consistent across datasets
smalldat1 <- mydata %>% dplyr::rename(totalcoughdays = cough_duration)

#remove variables that are not useful
smalldat2 <- smalldat1 %>% dplyr::select( -c(netid, Height_in_meters) ) 

#remove individuals that have missing outcome data 
smalldat3 <- smalldat2 %>% dplyr::filter( totalcoughdays != "NA" )

#transform some of the variables to factors
#most predictors are categorical/factors, convert them
allnames <- colnames(smalldat3) 
#these are not categorical
facvars <- allnames[!(allnames %in% c('totalcoughdays','Weight','Height','BMI','Age',"Karnovsky_score"))] 
smalldat4 = smalldat3;
smalldat4[,facvars] <- lapply(smalldat3[,facvars], as.factor) 

#place outcome (cough days) in first column
smalldat5 <- smalldat4 %>% dplyr::select(totalcoughdays, everything() )

#combine BCG categories 1 and 2 
smalldat5$BCG <- mapvalues(smalldat5$BCG, c(0,1,2), c(0,2,2))

#recode smoking from 0/1/2 current/former/never to yes/no
smalldat5$Smoking <- mapvalues(smalldat5$Smoking, c(0,1,2), c(1,0,0))

#combine 2 lowest cough frequencies since there is only 1 in the lowest category
smalldat5$Frequency_cough <- mapvalues(smalldat5$Frequency_cough, c(1,2,3,4), c(2,2,3,4))

##remove smeargrade since it contains very similar information to smearstatus 
##also has too few entries in some categories
smalldat6 <- smalldat5 %>% dplyr::select( -c(smear) ) 

#remove this variable since it is not very informative, almost everyone is in a single category. 
smalldat7 <- smalldat6 %>% dplyr::select( -c(Frequency_cough_per_week) )

#remove this variable since it is not very informative, almost everyone is in a single category and lots of missing. 
smalldat7 <- smalldat7 %>% dplyr::select( -c(Wasting) ) 

#drop any unused factor levels
smalldat8 <- droplevels(smalldat7)

#rename a few variables
smalldat9 <- smalldat8 %>% dplyr::rename(age = Age, Smoking_status = Smoking, Prior_TB = prior_TB, Alcohol_use = Drinking_status )

##for HIV status all NA are refusals. Recode them as '2'
smalldat9$HIV <- as.numeric(as.character(smalldat9$HIV))
smalldat9$HIV[is.na(smalldat9$HIV)]=2  
smalldat9$HIV = as.factor(smalldat9$HIV)

data_cohsonet_clean <- smalldat9

##################################################################
#linear model can't deal with missing values, need to make a dataset for this method that doesn't contain missing
#look at all the missing values


#check for columns/variables with NA
x=colSums(is.na(data_cohsonet_clean)) 
print(x) 

## remove further columns with lots of missing and/or missing rows/observations to get to a complete dataset 
data_cohsonet_clean_completecases <- data_cohsonet_clean[complete.cases(data_cohsonet_clean),]
data_cohsonet_clean_completecases <- droplevels(data_cohsonet_clean_completecases)


## perform imputation of missing values on remaining variables
imputedat <- mice::mice(data = data_cohsonet_clean, m = 1, defaultMethod = c('rf','rf','rf'))
data_cohsonet_clean_imputed <- mice::complete(imputedat)
#drop any unused factor levels
data_cohsonet_clean_imputed <- droplevels(data_cohsonet_clean_imputed)


##################################################################
#save cleaned/processed data to files
saveRDS(data_cohsonet_clean, file='../cleandata/data_cohsonet_clean.rds')
saveRDS(data_cohsonet_clean_completecases, file='../cleandata/data_cohsonet_clean_completecases.rds')
saveRDS(data_cohsonet_clean_imputed, file='../cleandata/data_cohsonet_clean_imputed.rds')


