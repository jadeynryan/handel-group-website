##################################################################
#R script to analyze assocation of TB cough duration and other variables
#this script looks at individual predictors
#written by Andreas Handel (ahandel@uga.edu). Last change 11/17/2016
##################################################################
rm(list=ls());
library(plyr)
library(dplyr) #for data manipulation - load last
library(tableone) #for quick creation of overview/descriptive tables
library(compareGroups) #for nicely formatted simple results tables


##################################################################
#read data 
#these data files have been processed by previous scripts
#see those scripts for details


#loop over all data sets
datanames=c('china','peru','gambia','cohsonet','kawempe','steps')

#save results for each dataset in list
#make empty list to hold all studies
reslist = vector("list", length(datanames))
names(reslist) = datanames

MST=rep(0,length(datanames)) #mean square total
SST=MST;

#indicates if we want to run analysis on datasets that contain missing values (=0) complete cases (=1) or imputed (=2)
cc = 1


ct=1;
totvar = 0; #total number of predictors across all datasets 
for (dataname in datanames)
{
    
  print(sprintf('***** starting to analyze dataset %s ******',dataname))

  if (cc == 0)
  {
    mydata <- readRDS(paste('../cleandata/data_',dataname,'_clean.rds',sep=''))
    savefile = '../results/basic_analysis_all.Rdata'
  }
  if (cc == 1)
  {
    mydata <- readRDS(paste('../cleandata/data_',dataname,'_clean_completecases.rds',sep=''))
    savefile = '../results/basic_analysis_completecases.Rdata'
  }
  if (cc == 2)
  {
    mydata <- readRDS(paste('../cleandata/data_',dataname,'_clean_imputed.rds',sep=''))
    savefile = '../results/basic_analysis_imputed.Rdata'
  }
  
  
  #save observations/outcome in variable for later easy use
  #name of outcome variable is totalcoughdays
  
  #this does outcome on linear scale
  outcome <- mydata$totalcoughdays; outcomename = 'totalcoughdays'
  
  predictors <- mydata[,-1]
  
  npred=ncol(predictors) #number of predictors
  nobs=nrow(mydata) # number of observations
  SST[ct] = sum( (outcome - mean(outcome))^2 ) #for R2 computations below
  MST[ct] = SST[ct]/nobs

  
  ##################################################################
  ##create a few tables using some packages
  ##################################################################
  #this uses the tableone package to create an overview table, optionally stratified
  #lots of options exist to format it the way one wants to
  #tab1 = tableone::CreateTableOne(data = mydata)
  #tab2= data.frame(print(tab1)) #need the result as data frame for use in R Markdown
  #reslist[[ct]]$descriptivtable = tab2 #save table in list 

  #use the compareGroups package to make an OR table
  #performs univariate analysis  
  #res1 <- compareGroups::compareGroups(totalcoughdays ~ . , data = mydata)
  #browser()
  #ortable = compareGroups::createTable(res1, show.ratio = TRUE, show.n = FALSE, show.p.trend = TRUE)
  #compareGroups::export2md(ortable, file='../results/ortable1.csv') #export table as CSV to be loaded into manuscript
  #reslist[[ct]]$ortable = ortable
  
  
    ##################################################################
    #doing a univariate regression for each predictor
    #print("******* doing univariate analyses ********")
    var_and_p_R2 = data.frame(VariableName = colnames(predictors), ValueofCoefficient = 0, SEofCoefficient = 0, pvalue = 0, R2 = 0) #save name of variable and p-value
    
  
    for (nn in 1:ncol(predictors))
    {
        fitlm_uni = lm(outcome ~ predictors[,nn])
        predicteduni <- predict(fitlm_uni)
        R2fit = summary(fitlm_uni)$r.squared
        
        ano_res = anova(fitlm_uni, test = "F") #anova table
        
        var_and_p_R2[nn,2]= summary(fitlm_uni)$coefficients[2,1]
        var_and_p_R2[nn,3]= summary(fitlm_uni)$coefficients[2,2]
          
        var_and_p_R2[nn,4]=ano_res[,'Pr(>F)'][1]; #get the p-value
        
        var_and_p_R2[nn,5]= R2fit
        
        #browser()

    }
  
    var_and_p_uni <- arrange(var_and_p_R2, pvalue) #sort according to smallest p-value
    var_and_p_uni_sig <- var_and_p_uni[var_and_p_uni$pvalue<=0.05,]
    
    reslist[[ct]]$unifall=var_and_p_uni
    reslist[[ct]]$unifsig=var_and_p_uni_sig

    totvar = totvar + nrow(var_and_p_uni)
      
        
    ##################################################################
    #doing a full linear model
    print("******* doing a full linear model *******")
    fitlm_full <- lm(totalcoughdays ~ ., data=mydata)
    
    predictedlm <- predict(fitlm_full) 
    
    R2fitlm=1 - sum((predictedlm-outcome)^2)/SST[ct]
    residlm_full <- outcome - predictedlm
    maxval <- max(c(predictedlm,outcome))
    
    ano_res = anova(fitlm_full, test = "F") #anova table
    var_and_p_full = data.frame(varname = rownames(ano_res), pval=ano_res[,'Pr(>F)'])
    var_and_p_full <- arrange(var_and_p_full, pval)
    var_and_p_full <- var_and_p_full[1:(nrow(var_and_p_full)-1),] #remove entry for residuals
    var_and_p_full_sig <- var_and_p_full[var_and_p_full$pval<=0.05,]

    reslist[[ct]]$fulllmall=var_and_p_full
    reslist[[ct]]$fulllmsig=var_and_p_full_sig
    reslist[[ct]]$fulllmR2=R2fitlm

    ct=ct+1;
} #finish loop over all datasets

#turn list into table that can be placed in manuscript

studylabels = c('China','Peru','The Gambia','U-Cohsonet','U-Kawempe','U-Steps')
unifmat=data.frame(Study=studylabels,Significant.Variables=rep(0,length(datanames)),R.Squared=rep(0,length(datanames)))
uniffullmat=data.frame(matrix(ncol = 6, nrow = totvar))
colnames(uniffullmat) = c( "Study", colnames(var_and_p_uni)) 

fulllmmat=unifmat
ct3 = 1
for (ct in 1:length(datanames))
{
    unifmat[ct,2]=paste(as.vector(reslist[[ct]]$unifsig$varname), collapse= ', ')
    unifmat[ct,3]=paste(as.vector(round(reslist[[ct]]$unifsig$R2,3)), collapse= ', ')

    fulllmmat[ct,2]=paste(as.vector(reslist[[ct]]$fulllmsig$varname), collapse= ', ')
    fulllmmat[ct,3]=as.numeric(reslist[[ct]]$fulllmR2)
    
    for (ct2 in 1:nrow(reslist[[ct]]$unifall))
    {
      uniffullmat[ct3,] = c(studylabels[ct],as.character(reslist[[ct]]$unifall[ct2,1]), reslist[[ct]]$unifall[ct2,-1])
      ct3=ct3+1
    }
    
    
}

save(list=ls(), file=savefile)


print('all done')