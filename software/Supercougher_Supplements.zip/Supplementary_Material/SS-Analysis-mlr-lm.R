##################################################################
#R script to analyze assocation of TB cough duration and other variables
#using the mlr package for this
#this script looks at linear models and subset selection
#written by Andreas Handel (ahandel@uga.edu). Last change 12/15/2016
##################################################################
rm(list=ls()); #clear workspace

library(parallelMap) #for using multiple processors when running models through mlr
library(mlr) #for analysis
library(plyr)
library(dplyr) #for data manipulation - load last
library(relaimpo) #to do relative variable importance of variables in final model

#initialize multiple cores for parallel processing using mlr
#note that this is actually the number of 'logical processors', which is 2x the number of cores, i.e. 32 on my machine
ncpu=30;
parallelStartSocket(ncpu, show.info=FALSE)

myseed=123; #set random number seed
set.seed(myseed) 


##################################################################
#read data 
#these data files have been processed by previous scripts
#see those scripts for details

#loop over all data sets
datanames=c('china','peru','gambia','cohsonet','kawempe','steps')

#save results for each dataset in list
#make empty list to hold results for each study
reslist = vector("list", length(datanames))
names(reslist) = datanames
MST=rep(0,length(datanames)) #mean square total

MSE_fullmodel_full=MST; #hold values for full model
R2_fullmodel_full=MST;

ct2=1; #counter over each dataset

#indicates if we want to run analysis on datasets that contain missing values (=0) complete cases (=1) or imputed (=2)
cc = 1

for (dataname in datanames) #loop over all studies
{
    
    print(sprintf('***** starting to analyze dataset %s ******',dataname))

  if (cc == 0)
  {
    mydata <- readRDS(paste('../cleandata/data_',dataname,'_clean.rds',sep=''))
    savefile = '../results/lm_selection_all.Rdata'
  }
  if (cc == 1)
  {
    mydata <- readRDS(paste('../cleandata/data_',dataname,'_clean_completecases.rds',sep=''))
    savefile = '../results/lm_selection_completecases.Rdata'
  }
  if (cc == 2)
  {
    mydata <- readRDS(paste('../cleandata/data_',dataname,'_clean_imputed.rds',sep=''))
    savefile = '../results/lm_selection_imputed.Rdata'
  }
    
    #save observations/outcome in variable for later easy use
    #name of outcome variable is totalcoughdays
    
    #this does outcome on linear scale
    outcome <- mydata$totalcoughdays; outcomename = 'totalcoughdays'
    
    predictors <- mydata[,-1]
    
    npred=ncol(predictors) #number of predictors
    nobs=nrow(mydata) # number of observations
    SST = sum( (outcome - mean(outcome))^2 ) #for R2 computations below
    MST[ct2] = SST/nobs
    
    ##################################################################
    #doing a bit of predictive modeling with mlr
    #print(sprintf('****doing a bit of linear model feature selection with mlr****'))
    
    ## Generate the task, i.e. outcome and predictors to be fit
    mytask = makeRegrTask(id='SSanalysis', data = mydata, target = outcomename)

    #set learner/model
    #learner_name = "regr.glm";
    #mylearner = makeLearner(learner_name, family = 'gaussian')
    learner_name = "regr.lm";
    mylearner = makeLearner(learner_name)
    
    ########################
    #set sampling method for performance evaluation
    sampling_choice = makeResampleDesc("RepCV", reps = 10, folds = 10)
    #sampling_choice = makeResampleDesc("CV", iters = 3)
 
    
    #########################
    #do full linear model with CV
    fullmodel = resample(mylearner, task = mytask, resampling = sampling_choice, show.info = FALSE )
    MSE_fullmodel_full[ct2] = fullmodel$aggr[1]
    R2_fullmodel_full[ct2] = 1 - MSE_fullmodel_full[ct2]/MST[ct2]
    
    
    #########################
    ## Do feature selection
    #########################
    
    tstart=proc.time(); #capture current CPU time
    
    select_methods=c("sbs","sfbs","sfs","sffs") #do 2 forms of forward and backward selection, just to compare
    #select_methods=NULL
    
    seq_res=list(NULL)
    ct=1;
    for (select_method in select_methods)
    {
        ctrl = makeFeatSelControlSequential(method = select_method)
        print(sprintf('doing subset selection with method %s ',select_method))
        
        #do 'pure' feature selection using the resampling scheme specified
        set.seed(myseed) 
        sfeat_res = selectFeatures(learner = mylearner, 
                                task = mytask, 
                                resampling = sampling_choice, 
                                control = ctrl, 
                                show.info = FALSE)
        #analyzeFeatSelResult(sfeat_res)
        #print(sfeat_res)

        #combine feature selection and training/fitting of final chosen model 
        #result should be same as above if random seed is set the same
        #set.seed(myseed) 
        #featlearn = makeFeatSelWrapper(learner = mylearner, 
         #                              resampling = sampling_choice, 
          #                             control = ctrl,
           #                            show.info = FALSE)
        #selmod = train(featlearn, task = mytask)
        #sfeat_res=getFeatSelResult(selmod)
        #print(sfeat_res)
        
      #cross validated performance of selected dataset using the sampling scheme specified      
      #this can give different feature sets each time, therefore not useful
      #r = resample(learner = featlearn, task = mytask, resampling = outer_sampling, measures = list(mse,rsq), models=TRUE, show.info = FALSE)

        #RMSE is minimized, R2 is also computed/reported
        seq_res[[ct]]=sfeat_res; #save results for all sequential selection methods
        
        ct=ct+1;
        #browser()
    }
    
    reslist[[ct2]]$sequential=seq_res #save results from forward and backward selection methods
    
    
    runtime.minutes_SS=(proc.time()-tstart)[[3]]/60; #total time in minutes the optimization took
    print(sprintf('forward/backward subset selection of dataset %s took %f minutes',dataname,runtime.minutes_SS));
  
    
    if (1==1) #genetic algorithm, i.e. smart/efficient way of trying to do full subset selection
    {
        print(sprintf('starting GA search'))
        tstart=proc.time(); #capture current CPU time
        maxit_GA=1000L
        ctrl_GA =makeFeatSelControlGA(maxit = maxit_GA)
        ## Select features
        set.seed(myseed) 
        sfeatga_res = selectFeatures(learner = mylearner, 
                                   task = mytask, 
                                   resampling = sampling_choice, 
                                   control = ctrl_GA, 
                                   show.info = FALSE)
        
        #featlearn_ga = makeFeatSelWrapper(learner = mylearner, 
         #                                 resampling = sampling_choice, 
          #                                control = ctrl_GA,
           #                               show.info = FALSE,
            #                              measures = list(rmse,rsq))
        #sfeatsga = train(featlearn_ga, task = mytask)
        #sfeatga_res=getFeatSelResult(sfeatsga)
        #print(sfeatga_res)
        
       
        
        #do a fit of best model
        preds = paste(sfeatga_res$x, collapse =" + ")
        modform = as.formula(paste("totalcoughdays ~", preds))
        
        fit_final_lm <- lm(modform , data=mydata)
        #fit_final_lm <- glm(modform , data=mydata, family = gaussian())
        #ano_res = anova(fit_final_lm) #anova table
        
        
        #relimp = relaimpo::calc.relimp(fit_final_lm, type = 'pmvd', rela = TRUE) #compute relative importance
        varimp = 0;
        
        runtime.minutes_GA=(proc.time()-tstart)[[3]]/60; #total time in minutes the optimization took
        print(sprintf('GA search of dataset %s took %f minutes',dataname,runtime.minutes_GA));
    
    } #end GA search
 
    reslist[[ct2]]$ga=sfeatga_res #save GA result
    reslist[[ct2]]$gavarimp = round(varimp, digits = 3) * 100
    ct2=ct2+1; #counter over datasets
    
    print(sprintf('***** finished analysis of dataset %s ******',dataname))
    
    #browser()
       
} #end loop over all studies    
    
#turn list into tables that can be placed in manuscript

#tables for each subset selection approach
nst=length(datanames)
studylabels = c('China','Peru','The Gambia','U-Cohsonet','U-Kawempe','U-Steps')
bestgamat=data.frame(Study=studylabels, Model.Variables=rep(0,nst), Variable.Importance = rep(0,nst), MSE=rep(0,nst), Rsquared=rep(0,nst))
bestsbsmat = bestgamat;
bestsfbsmat = bestgamat;
bestsfsmat = bestgamat;
bestsffsmat = bestgamat;
for (ct in 1:nst)
{
    sortimp=sort(reslist[[ct]]$gavarimp, decreasing=TRUE)
    
    bestgamat[ct,2]=paste(as.vector(names(sortimp)), collapse= ', ')
    bestgamat[ct,3]= paste(as.vector(sortimp), collapse = ', ')
    bestgamat[ct,4]=paste(as.vector(reslist[[ct]]$ga$y), collapse= ', ')
    bestgamat[ct,5]= 1 - as.numeric(bestgamat[ct,4])/MST[ct]
    
    if (length(select_methods)>0)
    {
      bestsbsmat[ct,2]=paste(as.vector(reslist[[ct]]$sequential[[1]]$x), collapse= ', ')
      bestsbsmat[ct,4]=paste(as.vector(reslist[[ct]]$sequential[[1]]$y), collapse= ', ')
      bestsbsmat[ct,5]= 1 - as.numeric(bestsbsmat[ct,4])/MST[ct]
  
      bestsfbsmat[ct,2]=paste(as.vector(reslist[[ct]]$sequential[[2]]$x), collapse= ', ')
      bestsfbsmat[ct,4]=paste(as.vector(reslist[[ct]]$sequential[[2]]$y), collapse= ', ')
      bestsfbsmat[ct,5]= 1 - as.numeric(bestsfbsmat[ct,4])/MST[ct]
      
      bestsfsmat[ct,2]=paste(as.vector(reslist[[ct]]$sequential[[3]]$x), collapse= ', ')
      bestsfsmat[ct,4]=paste(as.vector(reslist[[ct]]$sequential[[3]]$y), collapse= ', ')
      bestsfsmat[ct,5]= 1 - as.numeric(bestsfsmat[ct,4])/MST[ct]
      
      bestsffsmat[ct,2]=paste(as.vector(reslist[[ct]]$sequential[[4]]$x), collapse= ', ')
      bestsffsmat[ct,4]=paste(as.vector(reslist[[ct]]$sequential[[4]]$y), collapse= ', ')
      bestsffsmat[ct,5]= 1 - as.numeric(bestsffsmat[ct,4])/MST[ct]
    }
}


#shut down parallel computing framework
parallelStop()

save(list=ls(), file=savefile)

print('all done')