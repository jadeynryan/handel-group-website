##################################################################
#R script to pre-process and clean the raw data from the Gambia  study
#written by Andreas Handel (ahandel@uga.edu). 
##################################################################
rm(list=ls());
graphics.off();
library(plyr) #for data manipulation
library(dplyr) #for data manipulation
library(mice)


##################################################################
#read data from a CSV file
#see the accompanying codebook for details on the data
raw.data=read.csv('../rawdata/gambia-study/gambia_data.csv')

#make a copy of the original data
mydata=raw.data

#rename outcome to be consistent across datasets
smalldat1 <- mydata %>% dplyr::mutate(totalcoughdays = coughduration_days)

#remove observations for individuals that have missing data for outcome of interest (duration of cough) 
smalldat2 <- smalldat1 %>% dplyr::filter( !is.na(totalcoughdays) )

#remove several variables since they have >50% missing
#also drop original outcome
smalldat3 <- smalldat2 %>% dplyr::select( -c(hiv_type,windows,familysize,time_opened_windows,coughduration_days) ) 

#convert most predictors to categorical/factors
allnames <- colnames(smalldat3) 
facvars <- allnames[-which(allnames %in% c('totalcoughdays','age'))] #these are not categorical
x <- which(names(smalldat3) %in% facvars) 
smalldat3[,x] <- lapply(smalldat3[,x], as.factor) 



#rename some variables
smalldat4 <- smalldat3 %>% dplyr::rename(Smoking_status = smoker, HIV = hiv_status, Cavitary_status = cavitary_disease)


smalldat.f <- smalldat4

#place outcome (cough days) in first column
smalldat.sort <- smalldat.f %>% dplyr::select(totalcoughdays, everything() )

#drop any unused factor levels
smalldat.sort <- droplevels(smalldat.sort)

#final name of processed/cleaned data
data_gambia_clean <- smalldat.sort

#check for columns/variables with NA
x=colSums(is.na(data_gambia_clean)) 
print(x) 

##pretty complete dataset - only HIV has missing. 

## remove further columns with lots of missing and/or missing rows/observations to get to a complete dataset 
##since HIV has a lot of missing and almost everyone is negative, remove that variable
smalldatc1 <- data_gambia_clean %>% dplyr::select( -c(HIV) ) 
data_gambia_clean_completecases <- droplevels(smalldatc1[complete.cases(smalldatc1),])


#perform imupation on missing data
data_gambia_clean_imputed <- droplevels(mice::complete(mice(data_gambia_clean,m=1)))


##################################################################
#save cleaned/processed data to files
saveRDS(data_gambia_clean, file='../cleandata/data_gambia_clean.rds')
saveRDS(data_gambia_clean_completecases, file='../cleandata/data_gambia_clean_completecases.rds')
saveRDS(data_gambia_clean_imputed, file='../cleandata/data_gambia_clean_imputed.rds')

