##################################################################
#R script to estimate distribution of cough duration
#script written by Andreas Handel (ahandel@uga.edu). Last change 5/10/2017
##################################################################

rm(list=ls());
library(plyr)
library(MASS)
library(fitdistrplus)
library(dplyr) #for data manipulation - load last
library(actuar) #for log-logistic distribution
library(flexsurv) #for gamma hazard

##################################################################
#read data 
#these data files have been processed by previous scripts
#see those scripts for details

#loop over all data sets
datanames=c('china','peru','gambia','cohsonet','kawempe','steps')
studylabels = c('China','Peru','The Gambia','U-Cohsonet','U-Kawempe','U-Steps')

#save results for each dataset in list
#make empty list to hold all studies
reslist = vector("list", length(datanames))
names(reslist) = datanames


ct=1;
graphics.off(); #close all graphics windows
ww=17.8/2.54; wh=2/3*ww; #size is 17.8cm, needs to be in inches
windows(width=ww, height=wh) #for windows: opens window of the specified dimensions
par(mfrow=c(2,3))
par(oma=c(0.2,0.2,0.2,0.2)) #outer margins 
par(mar=c(0, 0, 0, 0)) #bottom, left, top, right margins

ytext='Cumulative days of cough'
xtext='Days of cough'

#indicates if we want to run analysis on datasets that contain missing values (=0) complete cases (=1) or imputed (=2)
cc = 0

for (dataname in datanames)
{
  
  print(sprintf('***** starting to analyze dataset %s ******',dataname))

  if (cc == 0)
  {
    mydata <- readRDS(paste('../cleandata/data_',dataname,'_clean.rds',sep=''))
    savefile = '../results/distribution_fit_all.Rdata'
    figfile = "../results/cdffit_all.png"    
    hazfigfile = "../results/hazfit_all.png"
  }
  if (cc == 1)
  {
    mydata <- readRDS(paste('../cleandata/data_',dataname,'_clean_completecases.rds',sep=''))
    savefile = '../results/distribution_fit_completecases.Rdata'
    figfile = "../results/cdffit_completecases.png"    
    hazfigfile = "../results/hazfit_completecases.png"
  }
  if (cc == 2)
  {
    mydata <- readRDS(paste('../cleandata/data_',dataname,'_clean_imputed.rds',sep=''))
    savefile = '../results/distribution_fit_imputed.Rdata'
    figfile = "../results/cdffit_imputed.png"    
    hazfigfile = "../results/hazfit_imputed.png"
  }
  
  #cumulative cough and days
  mydata <- mydata  %>% arrange(desc(totalcoughdays)) #sort data for each study by descending cough duration
  mydata <- mydata  %>% mutate(CumDaysofCough = cumsum(totalcoughdays)  ) #compute cumulative cough duration for each study

  expfit = fitdistrplus::fitdist(mydata$totalcoughdays, distr='exp')
  weibullfit = fitdistrplus::fitdist(mydata$totalcoughdays, distr='weibull')
  llogfit = fitdistrplus::fitdist(mydata$totalcoughdays, distr='llogis')
  gamfit = fitdistrplus::fitdist(mydata$totalcoughdays, distr='gamma')
  
  #expcurve = sort(rgeom(n=nrow(mydata),prob=expfit$estimate),decreasing=TRUE)
  #weibullcurve = sort(rweibull(n=nrow(mydata),shape =  weibullfit$estimate[1], scale =  weibullfit$estimate[2]),decreasing=TRUE)
  #llogcurve = sort(rllogis(n=nrow(mydata),shape =  llogfit$estimate[1], scale =  llogfit$estimate[2]),decreasing=TRUE)
  
  #compute hazard
  days = 0:max(mydata$totalcoughdays)
  
  exphaz = rep(expfit$estimate,length(days))
  
  wbshape = weibullfit$estimate[1] #k on wikipedia
  wbscale = weibullfit$estimate[2] #lambda on wikipedia
  wbhaz = (wbshape/wbscale) * (days/wbscale)^(wbshape - 1)  
  
  llogshape = llogfit$estimate[1] #beta on wikipedia
  llogscale = llogfit$estimate[2] #alpha on wikipedia
  lloghaz = (llogshape/llogscale)*(days/llogscale)^(llogshape-1) / (1+ (days/llogscale)^llogshape)
  #see help file for the generalized gamma in the flexsurv package
  k = gamfit$estimate[1] #shape
  scale = 1/gamfit$estimate[2] #scale = 1/rate
  gamhaz = flexsurv::hgengamma.orig(x=days, shape=1, scale=scale, k=k )
  
  #day at which hazard is maximum for llog function
  maxhazday=days[which.max(lloghaz)]
  
  reslist[[ct]]$coughmean=mean(mydata$totalcoughdays)
  reslist[[ct]]$expcoef=1/coef(expfit)
  reslist[[ct]]$weibcoef=coef(weibullfit)
  reslist[[ct]]$llogcoef=coef(llogfit)
  reslist[[ct]]$AICexp=expfit$aic
  reslist[[ct]]$AICweib=weibullfit$aic
  reslist[[ct]]$AICllog=llogfit$aic
  reslist[[ct]]$AICgam=gamfit$aic
  reslist[[ct]]$exphaz = exphaz
  reslist[[ct]]$wbhaz = wbhaz
  reslist[[ct]]$lloghaz = lloghaz
  reslist[[ct]]$gamhaz = gamhaz
  reslist[[ct]]$maxcough = max(mydata$totalcoughdays)
  reslist[[ct]]$maxhazday = maxhazday
  reslist[[ct]]$totalcoughdays = mydata$totalcoughdays
    
  #plot CDF for all studies 
  par(mai=c(0.5, 0.5, 0.2, 0.1)) #bottom, left, top, right margins
  ltext1=paste('Exp, AIC =',round(expfit$aic,0))
  ltext2=paste('Wb, AIC =',round(weibullfit$aic,0))
  ltext3=paste('Gam, AIC =',round(gamfit$aic,0))
  ltext4=paste('Llog, AIC =',round(llogfit$aic,0))
  fitdistrplus::cdfcomp(ft=list(Exp=expfit,Wb=weibullfit,Gam=gamfit,Llog=llogfit),lwd=1.5,legendtext=c(ltext1,ltext2,ltext3,ltext4),xlab='',ylab='',main=studylabels[ct],horizontals=FALSE,datacol = 'black',fitcol=c('blue','green','red','cyan'),fitlty=c('solid','dashed','dotted','dotdash'),datapch=20)
  
  if (ct>3) { mtext(xtext,side=1,line=2.5) } #x-axis - change line to move in/out
  if (ct == 1 | ct == 4) { mtext(ytext,side=2,line=2) }#y-axis
  
  
  ct=ct+1;
} #finish loop over all datasets
#save CDF figure
#save in various formats
#dev.print(device=pdf,width=ww,height=wh, paper="special",file="iav-fit.pdf"); 
#dev.print(device=tiff,filename ="fig2.tif",width=ww, height=wh, units="in",pointsize = 12, compression =c("lzw"), res=300) 
dev.print(device=png,width=ww,height=wh,units="in",res=600,file=figfile)

#browser()


#do hazard figure
ct=1
graphics.off(); #close all graphics windows
ww=17.8/2.54; wh=2/3*ww; #size is 17.8cm, needs to be in inches
windows(width=ww, height=wh) #for windows: opens window of the specified dimensions
par(mfrow=c(2,3))
par(oma=c(0.2,0.2,0.2,0.2)) #outer margins 
par(mar=c(0, 0, 0, 0)) #bottom, left, top, right margins
xtext='Days of cough'
ytext='Diagnosis hazard rate'
for (dataname in datanames)
{
    par(mai=c(0.5, 0.5, 0.2, 0.1)) #bottom, left, top, right margins

    hist(reslist[[ct]]$totalcoughdays, freq = FALSE, ylim=c(0,0.05), xlab='',ylab='',main=studylabels[ct], breaks = 30)    
    xdat=0:reslist[[ct]]$maxcough
    #plot(xdat,reslist[[ct]]$exphaz,type='l',col='blue',lty='solid',lwd=2,ylim=c(0,0.05),xlab='',ylab='',main=studylabels[ct])
    lines(xdat,reslist[[ct]]$exphaz,type='l',col='blue',lty='solid',lwd=2)
    lines(xdat,reslist[[ct]]$wbhaz,type='l',col='green',lty='dashed',lwd=2)
    lines(xdat,reslist[[ct]]$gamhaz,type='l',col='red',lty='dotted',lwd=2)
    lines(xdat,reslist[[ct]]$lloghaz,type='l',col='cyan',lwd=2,lty='dotdash')
    if (ct==1) { legend('top',legend=c('Exp','Wb','Gam','Llog'),lty=c('solid','dashed','dotted','dotdash'),col=c('blue','green','red','cyan') )}
    #par(new = T)

    #axis(side = 4)    
    if (ct>3) { mtext(xtext,side=1,line=2.5) } #x-axis - change line to move in/out
    if (ct == 1 | ct == 4) { mtext(ytext,side=2,line=2) }#y-axis
    
    
    ct=ct+1;
}

dev.print(device=png,width=ww,height=wh,units="in",res=600,file=hazfigfile)


#plot(wbhaz)
#lines(lloghaz,col='red')
#lines(exphaz,col='blue')  


#turn list into table that can be placed in manuscript

studylabels = c('China','Peru','The Gambia','U-Cohsonet','U-Kawempe','U-Steps')
resmat=data.frame(Study=studylabels,Expcoef=rep(0,length(datanames)), wbshape=rep(0,length(datanames)), wbscale=rep(0,length(datanames)), Shape_llog=rep(0,length(datanames)),AIC_ex=rep(0,length(datanames)),AIC_wb=rep(0,length(datanames)),AIC_llog=rep(0,length(datanames)),Maxhazday = rep(0,length(datanames)))

for (ct in 1:length(datanames))
{
  resmat[ct,2]=paste(as.vector(round(reslist[[ct]]$expcoef[1], 3)), collapse= ', ')
  resmat[ct,3]=paste(as.vector(round(reslist[[ct]]$weibcoef[1],3)), collapse= ', ')
  resmat[ct,4]=paste(as.vector(round(reslist[[ct]]$weibcoef[2],3)), collapse= ', ')
  
  resmat[ct,5]=paste(as.vector(round(reslist[[ct]]$llogcoef[1],3)), collapse= ', ')
  
  resmat[ct,6]=paste(as.vector(round(reslist[[ct]]$AICexp,3)), collapse= ', ')
  resmat[ct,7]=paste(as.vector(round(reslist[[ct]]$AICweib,3)), collapse= ', ')
  resmat[ct,8]=paste(as.vector(round(reslist[[ct]]$AICllog,3)), collapse= ', ')
  resmat[ct,9]=paste(as.vector(round(reslist[[ct]]$maxhazday,3)), collapse= ', ')
}


save(list=ls(), file=savefile)


print('all done')




###################################################################################
#generate plots
###################################################################################
