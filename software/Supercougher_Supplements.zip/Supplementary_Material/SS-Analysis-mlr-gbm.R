##################################################################
#R script to analyze superspreaders 
#using the mlr package and gbm algorithm for this
#written by Andreas Handel (ahandel@uga.edu). Last change 12/13/2016
##################################################################
rm(list=ls());
#graphics.off();

library(parallelMap) #for using multiple processors when running models through mlr
library(mlr) #for analysis
library(plyr)
library(dplyr) #for data manipulation - load last
library(gbm)

#initialize multiple cores for parallel processing using mlr
#note that this is actually the number of 'logical processors', which is 2x the number of cores, i.e. 32
ncpu=30;
parallelStartSocket(ncpu, show.info=FALSE)
#parallelStartSocket(ncpu, show.info=FALSE, level= "mlr.resample")

myseed=1231; #set random number seed
set.seed(myseed) 


##################################################################
#read data 
#these data files have been processed by previous scripts
#see those scripts for details

#loop over all data sets
datanames=c('china','peru','gambia','cohsonet','kawempe','steps')

#save results for each dataset in list
#make empty list to hold results for each study
reslist = vector("list", length(datanames))
names(reslist) = datanames
MST=rep(0,length(datanames)) #mean square total

ct2=1;
#indicates if we want to run analysis on datasets that contain missing values (=0) complete cases (=1) or imputed (=2)
cc = 1

for (dataname in datanames) #loop over all studies
{
  
  print(sprintf('***** starting to analyze dataset %s ******',dataname))
  
  if (cc == 0)
  {
    mydata <- readRDS(paste('../cleandata/data_',dataname,'_clean.rds',sep=''))
    savefile = '../results/gbm_all.Rdata'
  }
  if (cc == 1)
  {
    mydata <- readRDS(paste('../cleandata/data_',dataname,'_clean_completecases.rds',sep=''))
    savefile = '../results/gbm_completecases.Rdata'
  }
  if (cc == 2)
  {
    mydata <- readRDS(paste('../cleandata/data_',dataname,'_clean_imputed.rds',sep=''))
    savefile = '../results/gbm_imputed.Rdata'
  }

  #save observations/outcome in variable for later easy use
  #name of outcome variable is totalcoughdays
  outcome <- mydata$totalcoughdays 
  outcomename = 'totalcoughdays'
  

  predictors <- mydata[,-1]
  
  npred=ncol(predictors) #number of predictors
  nobs=nrow(mydata) # number of observations
  SST = sum( (outcome - mean(outcome))^2 ) #for R2 computations below
  MST[ct2] = SST/nobs
  
  
  ##################################################################
  #doing a bit of predictive modeling with mlr
  ## See what the best possible performance is for this dataset
  #print(sprintf('****doing a bit of predictive modeling using various methods through mlr****'))
  
  ## Generate the task, i.e. outcome and predictors to be fit
  mytask = makeRegrTask(id='SSanalysis', data = mydata, target = outcomename)
  
  #########################
  #set sampling method for tuning and final performance evaluation
  sampling_choice = makeResampleDesc("RepCV", reps = 10, folds  = 10)
  #sampling_choice = makeResampleDesc("CV", iters  = 3)
  sampling_final = sampling_choice
  
  #set learner
  learner_name = "regr.gbm";
  mylearner = makeLearner(learner_name)

  #getParamSet(mylearner)
  
  #specify method of tuning/optimization
  #ctrl_gbm = makeTuneControlIrace(budget = 100L)
  #ctrl_gbm = makeTuneControlRandom( maxit = 10L)
  ctrl_gbm = makeTuneControlGenSA(budget = 100L)
  #ctrl_gbm = makeTuneControlGrid(resolution = 5L)
  
    
  #specify parameters that should be tuned for gbm
  ps_gbm = makeParamSet( makeIntegerParam("n.trees", lower = 100L, upper = 2000L),  
                           makeIntegerParam("interaction.depth", lower = 1L, upper = 8L), #tree complexity  
                           makeIntegerParam("n.minobsinnode",  lower = 1L, upper = 10L),
                           makeNumericParam('bag.fraction', lower = 0.4, upper = 1 )
    )
  
  #set some parameters of the algorithm that are not tuned
  mylearner = setHyperPars(mylearner, shrinkage = 0.001, distribution = 'gaussian') #shrinkage = learning rate
  
    #run the optimization/tuning
   tstart=proc.time(); #capture current CPU time
    tuneres_gbm = tuneParams(learner = mylearner, 
                             task = mytask, 
                             resampling = sampling_choice, 
                              par.set = ps_gbm, 
                             show.info = FALSE,
                             control = ctrl_gbm)

    reslist[[ct2]]$MSE = tuneres_gbm$y[1]
    reslist[[ct2]]$R2 = 1 - tuneres_gbm$y[1]/MST[ct2]

    #run model with best fit parameters again to estimate variable importance
    #getting variable importance from tuneParams() is not possible, thus we need to do a final run
    optim_gbm = setHyperPars(mylearner, par.vals = tuneres_gbm$x)
    optim_gbm = resample(learner = optim_gbm, 
                         task = mytask, 
                         resampling = sampling_final, 
                         show.info = FALSE , 
                         models = FALSE,
                         extract = function(x) summary(x$learner.model) ) #this is specific to the GBM model and allows us to get variable importance information
    
    
    #look at variable importance
    varimplist = optim_gbm$extract
    varmean = rep(0,npred)
    for (nn in 1:length(varimplist)) #loop over all samples, compute mean importance for each variable
    {
      sortvals = dplyr::arrange(varimplist[[nn]],var)$rel.inf #sort each variable list by variable name to make sure the right values are added
      varmean = varmean + sortvals
    }
    varmean = round(varmean/length(varimplist), digits = 3)
    varimps1 = data.frame(variable = dplyr::arrange(varimplist[[1]],var)$var, value = varmean)
    varimps2 <- varimps1 %>% dplyr::arrange( desc(value))

    #p_gbm = ggplot(varimps, aes(x=variable, y = value)) + geom_bar(stat="identity") + coord_flip() + scale_y_continuous('') + scale_x_discrete('')
    #plot(p_gbm)
    #plotfilename=paste('../Manuscript/',dataname,'_varimp_plot_gbm.png',sep='')
    #ggsave(plotfilename,p_gbm)
    

  tend=proc.time(); #capture current CPU time
  tdiff=tend-tstart;
  runtime.minutes_xgb=tdiff[[3]]/60; #total time in minutes the optimization took
  print(sprintf('%s optimization for dataset %s took %f minutes',learner_name, dataname, runtime.minutes_xgb));

  reslist[[ct2]]$varimp=varimps2
  
  #browser()
  ct2=ct2+1;
} #end loop over a single study/dataset


#turn list into table that can be placed in manuscript
nst=length(datanames)

studylabels = c('China','Peru','The Gambia','U-Cohsonet','U-Kawempe','U-Steps')

bestgbmmat=data.frame(Study=studylabels, Model.Variables=rep(0,nst), Variable.Importance = rep(0,nst),  MSE=rep(0,nst), Rsquared=rep(0,nst) )
for (ct in 1:nst)
{
  bestgbmmat[ct,2]=paste(as.vector(reslist[[ct]]$varimp[1:5,1]), collapse= ', ')
  bestgbmmat[ct,3]=paste(as.vector(reslist[[ct]]$varimp[1:5,2]), collapse= ', ')
  bestgbmmat[ct,4]=as.numeric(reslist[[ct]]$MSE)
  bestgbmmat[ct,5]=as.numeric(reslist[[ct]]$R2)
}

parallelStop()
print('all done')

save(list=ls(), file=savefile)


