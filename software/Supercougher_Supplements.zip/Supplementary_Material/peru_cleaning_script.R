##################################################################
#R script to pre-process and clean the raw data from the Peru study
#written by Andreas Handel (ahandel@uga.edu). 
##################################################################
rm(list=ls());
graphics.off();
library(plyr) #for data manipulation
library(dplyr) #for data manipulation


##################################################################
#read data from a CSV file
#see the accompanying codebook for details on the data
raw.data=read.csv('../rawdata/peru-study/peru_data.csv')

#make a copy of the original data
mydata=raw.data

#rename outcome to be consistent across datasets
#also convert from weeks to days
smalldat1 <- mydata %>% dplyr::mutate(totalcoughdays = 7 * cough_duration)

#remove observations for individuals that have missing data for outcome of interest (duration of cough) 
smalldat2 <- smalldat1 %>% dplyr::filter( !is.na(totalcoughdays) )

#some individuals report cough duration as 0 weeks
#not sure what that means
#remove those observations/individuals
smalldat2b <- smalldat2 %>% dplyr::filter( totalcoughdays!=0)

#remove variables that are not useable as predictors for analysis
#also drop original outcome
smalldat3 <- smalldat2b %>% dplyr::select( -c(family_code, cough_duration) ) 

#all predictors are categorical/factors
allnames <- colnames(smalldat3) 
facvars <- allnames[-which(allnames %in% c('totalcoughdays'))] #not categorical
x <- which(names(smalldat3) %in% facvars) 
smalldat3[,x] <- lapply(smalldat3[,x], as.factor) 

#smear grade and smear status are collinear, remove one
smalldat4 <- smalldat3 %>% dplyr::select( -c(smear) )  

#rename a few more variables
smalldat6 <- smalldat4 %>% dplyr::rename(Smear_status = Smear_status, Hospitalization = Hospitalized)

smalldat.f <- smalldat6

#place outcome (cough days) in first column
smalldat.sort <- smalldat.f %>% dplyr::select(totalcoughdays, everything() )

#drop any unused factor levels
smalldat.sort <- droplevels(smalldat.sort)


#final name of processed/cleaned data
data_peru_clean <- smalldat.sort

##################################################################
#linear model can't deal with missing values, need to make a dataset for this method that doesn't contain missing

#check for columns/variables with NA
x=colSums(is.na(data_peru_clean)) 
print(x) 

##pretty complete dataset


#remove incomplete observations
data_peru_clean_completecases <- droplevels(na.omit(data_peru_clean)) #drop observations with NA 

#perform imupation on missing data
data_peru_clean_imputed <- droplevels(mice::complete(mice(data_peru_clean,m=1)))


##################################################################
#save cleaned/processed data to files
saveRDS(data_peru_clean, file='../cleandata/data_peru_clean.rds')
saveRDS(data_peru_clean_completecases, file='../cleandata/data_peru_clean_completecases.rds')
saveRDS(data_peru_clean_imputed, file='../cleandata/data_peru_clean_imputed.rds')



