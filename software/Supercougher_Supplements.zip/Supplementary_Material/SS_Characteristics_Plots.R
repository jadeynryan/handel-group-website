##################################################################
#R script to look for signs of superspreaders 
#see manuscript for more details on these studies
#script written by Andreas Handel (ahandel@uga.edu). 
#Last change 5/12/2019
##################################################################
rm(list=ls());
graphics.off();
library(dplyr)
library(ggplot2)
library(cowplot) #for better multi-panel plotting in ggplot2
library(tidyr)

##################################################################
#load data
#see the accompanying codebook for details on the data
#this data has been processed by previous scripts
#see those scripts for details
#data is named as file
#indicates if we want to run analysis on datasets that contain missing values (=0) complete cases (=1) or imputed (=2)
cc = 0
#this loads the complete cases data
if (cc == 0)
{
  d1 = readRDS('../cleandata/data_china_clean.rds')
  d2 = readRDS('../cleandata/data_peru_clean.rds')
  d3 = readRDS('../cleandata/data_gambia_clean.rds')
  d4 = readRDS('../cleandata/data_cohsonet_clean.rds')
  d5 = readRDS('../cleandata/data_kawempe_clean.rds')
  d6 = readRDS('../cleandata/data_steps_clean.rds')
  load('../results/distribution_fit_all.Rdata') #data for hazard function fits
  coughhistplot = "../results/cough_hist_all.png"
  coughviolinplot = "../results/cough_violin_all.png"
  cumulativeplotfig = "../results/cumulativecough_plot_all.png"
  percplotfig = "../results/perc_plot_all.png"
}
if (cc == 1)
{
  d1 = readRDS('../cleandata/data_china_clean_completecases.rds')
  d2 = readRDS('../cleandata/data_peru_clean_completecases.rds')
  d3 = readRDS('../cleandata/data_gambia_clean_completecases.rds')
  d4 = readRDS('../cleandata/data_cohsonet_clean_completecases.rds')
  d5 = readRDS('../cleandata/data_kawempe_clean_completecases.rds')
  d6 = readRDS('../cleandata/data_steps_clean_completecases.rds')
  load('../results/distribution_fit_completecases.Rdata') #data for hazard function fits
  coughhistplot = "../results/cough_hist_completecases.png"
  coughviolinplot = "../results/cough_violin_completecases.png"
  cumulativeplotfig = "../results/cumulativecough_plot_completecases.png"
  percplotfig = "../results/perc_plot_completecases.png"
}
if (cc == 2)
{
  d1 = readRDS('../cleandata/data_china_clean_imputed.rds')
  d2 = readRDS('../cleandata/data_peru_clean_imputed.rds')
  d3 = readRDS('../cleandata/data_gambia_clean_imputed.rds')
  d4 = readRDS('../cleandata/data_cohsonet_clean_imputed.rds')
  d5 = readRDS('../cleandata/data_kawempe_clean_imputed.rds')
  d6 = readRDS('../cleandata/data_steps_clean_imputed.rds')
  load('../results/distribution_fit_imputed.Rdata') #data for hazard function fits
  coughhistplot = "../results/cough_hist_imputed.png"
  coughviolinplot = "../results/cough_violin_imputed.png"
  cumulativeplotfig = "../results/cumulativecough_plot_imputed.png"
  percplotfig = "../results/perc_plot_imputed.png"
}

#assign data to shorter names for easier coding

studynames=c('China','Peru','The Gambia','U-Cohsonet','U-Kawempe','U-Steps')


##################################################################
#make a new data frame for plotting
#create new variables for plotting (cumulative cough, etc.)
IDvec=c(1:nrow(d1), 1:nrow(d2), 1:nrow(d3), 1:nrow(d4), 1:nrow(d5), 1:nrow(d6) ) #IDs for each study - doesn't correpsond to actual ID from study
Coughvec = c(sort(d1$totalcoughdays,decreasing = TRUE) , sort(d2$totalcoughdays,decreasing = TRUE), sort(d3$totalcoughdays,decreasing = TRUE), sort(d4$totalcoughdays,decreasing = TRUE), sort(d5$totalcoughdays,decreasing = TRUE), sort(d6$totalcoughdays,decreasing = TRUE))
StudyIDvec = c(rep(studynames[1],nrow(d1)) , rep(studynames[2],nrow(d2)), rep(studynames[3],nrow(d3)), rep(studynames[4],nrow(d4)), rep(studynames[5],nrow(d5)), rep(studynames[6],nrow(d6)) )

wbshapevec = as.numeric(c(rep(resmat$wbshape[1],nrow(d1)),rep(resmat$wbshape[2],nrow(d2)),rep(resmat$wbshape[3],nrow(d3)),rep(resmat$wbshape[4],nrow(d4)),rep(resmat$wbshape[5],nrow(d5)),rep(resmat$wbshape[6],nrow(d6)) ))

wbscalevec = as.numeric(c(rep(resmat$wbscale[1],nrow(d1)),rep(resmat$wbscale[2],nrow(d2)),rep(resmat$wbscale[3],nrow(d3)),rep(resmat$wbscale[4],nrow(d4)),rep(resmat$wbscale[5],nrow(d5)),rep(resmat$wbscale[6],nrow(d6)) ))

plot_data = data.frame( PersonID = IDvec, DaysofCough = Coughvec, Study = StudyIDvec, LogDaysofCough = log(Coughvec), wbshape = wbshapevec, wbscale = wbscalevec) 
plot_data <- plot_data %>% group_by(Study) %>% arrange(desc(DaysofCough)) #sort data for each study by descending cough duration
plot_data <- plot_data %>% group_by(Study) %>% mutate(CumDaysofCough = cumsum(DaysofCough)  ) #compute cumulative cough duration for each study
plot_data <- plot_data %>% group_by(Study) %>% mutate(CumFixedCough = cumsum(rep(mean(DaysofCough),n() )) ) #if everyone coughed exactly the same length - note that if you get a weird 'error in n() - this function should not be called directly' message, try to restart R and run this script on a new session. something weird about dplyr/n() - google it on stackoverflow
#plot_data <- plot_data %>% group_by(Study) %>% mutate(CumPoisCough = cumsum(sort(rpois(n(),lambda = ceiling(mean(DaysofCough))),decreasing=TRUE))) #if cough duration was possion distributed
#plot_data <- plot_data %>% group_by(Study) %>% mutate(CumExpCough = cumsum(sort(rexp(n(), rate = 1/mean(DaysofCough)),decreasing=TRUE))) #if cough duration was possion distributed
#plot_data <- plot_data %>% group_by(Study) %>% mutate(CumGeomCough = cumsum(sort(rgeom(n(),prob = 1/mean(DaysofCough)),decreasing=TRUE))) #if cough duration was possion distributed
#plot_data <- plot_data %>% group_by(Study) %>% mutate(CumwbCough = cumsum(sort(rweibull(n(),shape = wbshapevec, scale = wbscalevec),decreasing=TRUE))) #if cough duration was possion distributed
plot_data <- plot_data %>% group_by(Study) %>% mutate(PercDaysofCough = CumDaysofCough / max(CumDaysofCough) * 100) 
plot_data <- plot_data %>% group_by(Study) %>% mutate(PercPatients = PersonID / max(PersonID) * 100 ) 
plot_data$Study <- factor(plot_data$Study, levels = studynames)

###################################################################################
#generate plots
###################################################################################


###################################################################################
#histogram and density plot
p1coughdist <- ggplot(plot_data, aes(x=DaysofCough, color=Study)) + geom_histogram(aes(y=..density..),fill='white') + geom_density( alpha=0) + labs(x = "Days of Cough", y = "Density" , size = 1.5) + facet_wrap(~ Study, nrow = 2)
save_plot(coughhistplot, p1coughdist, base_aspect_ratio = 2.2) #cowplot way of saving

#box/violin plot of cough distribution
p2coughdist <- ggplot(plot_data, aes(x=Study, y=DaysofCough, color=Study)) + geom_violin()  + geom_boxplot(width= .05) + stat_summary(fun.y=mean, geom="point", size=2, color="black") + labs(y = "Days of Cough")
save_plot(coughviolinplot, p2coughdist, base_aspect_ratio = 2.2) #cowplot way of saving



#combined_plots <- plot_grid(p1coughdist,p2coughdist, labels = c("A", "B"), align = "h")
#plot(combined_plots)
#save_plot("../manuscript/results/cough_plot.png", combined_plots, base_aspect_ratio = 3) #cowplot way of saving
#ggsave(filename="../manuscript/results/cough_plot.png",plot=p2coughdist) #ggplot way of saving



###################################################################################
#plot of cumulative cough time as function of persons for Kawempe data

plot_kawempe <- plot_data %>% filter(Study == 'U-Kawempe')
nobs = nrow(plot_kawempe)
maxcough = max(plot_kawempe$CumDaysofCough)

p1 <-  ggplot(plot_kawempe, aes(x=PersonID,y=CumDaysofCough), colour='black' ) + geom_line(size=1.5) 
p2 <- p1 + geom_line( aes(y=CumFixedCough), colour='gray', size=1.5, linetype = 'dotted' )
p3 <- p2 + labs(title = 'U-Kawempe', x = "Number of Patients", y = "Cumulative days of Cough" , size = 1.5)
p4 <- p3 #+ geom_line( aes(y=CumExpCough), colour='blue', size=1.5, linetype = 'dashed' ) + geom_line( aes(y=CumGeomCough), colour='green', size=1.5, linetype = 'dashed' ) + geom_line( aes(y=CumPoisCough), colour='orange', size=1.5, linetype = 'solid' ) 
p6 <- p4 + theme(legend.position="none") #+ scale_colour_manual(values=c("#999999", "#E69F00", "#56B4E9"),  name="Scenario", breaks=c("CumDaysofCough", "CumFixedCough", "CumPoissonCough"), labels=c("Data", "Fixed", "Poisson"))
p7 <- p6 + geom_segment(aes(x = floor(nobs*0.2), y = 1, xend = floor(nobs*0.2), yend = floor(maxcough*0.5) ), colour = "red", linetype="dashed", size=1)
p8 <- p7 + geom_segment(aes(x = floor(nobs*0.5), y = 1, xend = floor(nobs*0.5), yend = floor(maxcough*0.8) ), colour = "red", linetype="dashed", size=1)
p9 <- p8 + geom_segment(aes(x = 1, y = floor(maxcough*0.5), xend = floor(nobs*0.2), yend = floor(maxcough*0.5) ), colour = "red", linetype="dashed", size=1)
p10k <- p9 + geom_segment(aes(x = 1, y = floor(maxcough*0.8), xend = floor(nobs*0.5), yend = floor(maxcough*0.8) ), colour = "red", linetype="dashed", size=1)


###################################################################################
#plot of cumulative cough time as function of persons for Steps data

plot_steps <- plot_data %>% filter(Study == 'U-Steps')
nobs_steps = nrow(plot_steps)
maxcough_steps = max(plot_steps$CumDaysofCough)

p1s <-  ggplot(plot_steps, aes(x=PersonID,y=CumDaysofCough), colour='black' ) + geom_line(size=1.5) 
p2s <- p1s + geom_line( aes(y=CumFixedCough), colour='gray' , size=1.5, linetype = 'dotted')
p3s <- p2s #+ geom_line( aes(y=CumExpCough), colour='blue', size=1.5, linetype = 'dashed' ) + geom_line( aes(y=CumwbCough), colour='green', size=1.5, linetype = 'dashed' ) 
p4s <- p3s + labs(title = 'U-Steps', x = "Number of Patients", y = "Cumulative days of Cough" , size = 1.5)
p6s <- p4s + theme(legend.position="none") 
p7s <- p6s + geom_segment(aes(x = floor(nobs_steps*0.2), y = 1, xend = floor(nobs_steps*0.2), yend = floor(maxcough_steps*0.5) ), colour = "red", linetype="dashed", size=1)
p8s <- p7s + geom_segment(aes(x = floor(nobs_steps*0.5), y = 1, xend = floor(nobs_steps*0.5), yend = floor(maxcough_steps*0.8) ), colour = "red", linetype="dashed", size=1)
p9s <- p8s + geom_segment(aes(x = 1, y = floor(maxcough_steps*0.5), xend = floor(nobs_steps*0.2), yend = floor(maxcough_steps*0.5) ), colour = "red",  linetype="dashed", size=1)
p10s <- p9s + geom_segment(aes(x = 1, y = floor(maxcough_steps*0.8), xend = floor(nobs_steps*0.5), yend = floor(maxcough_steps*0.8) ), colour = "red",  linetype="dashed", size=1)


###################################################################################
#plot of cumulative cough time as function of persons for Cohsonet data

plot_cohsonet <- plot_data %>% filter(Study == 'U-Cohsonet')
nobs_cohsonet = nrow(plot_cohsonet)
maxcough_cohsonet = max(plot_cohsonet$CumDaysofCough)


p1c <-  ggplot(plot_cohsonet, aes(x=PersonID,y=CumDaysofCough), colour='black' ) + geom_line(size=1.5) 
p2c <- p1c + geom_line( aes(y=CumFixedCough), colour='gray' , size=1.5, linetype = 'dotted')
p3c <- p2c #+ geom_line( aes(y=CumExpCough), colour='blue', size=1.5, linetype = 'dashed' ) + geom_line( aes(y=CumGeomCough), colour='green', size=1.5, linetype = 'dashed' ) 
p4c <- p3c + labs(title = 'U-Cohsonet', x = "Number of Patients", y = "Cumulative days of Cough" , size = 1.5)
p6c <- p4c + theme(legend.position="none")
p7c <- p6c + geom_segment(aes(x = floor(nobs_cohsonet*0.2), y = 1, xend = floor(nobs_cohsonet*0.2), yend = floor(maxcough_cohsonet*0.5) ), colour = "red", linetype="dashed", size=1)
p8c <- p7c + geom_segment(aes(x = floor(nobs_cohsonet*0.5), y = 1, xend = floor(nobs_cohsonet*0.5), yend = floor(maxcough_cohsonet*0.8) ), colour = "red", linetype="dashed", size=1)
p9c <- p8c + geom_segment(aes(x = 1, y = floor(maxcough_cohsonet*0.5), xend = floor(nobs_cohsonet*0.2), yend = floor(maxcough_cohsonet*0.5) ), colour = "red",  linetype="dashed", size=1)
p10c <- p9c + geom_segment(aes(x = 1, y = floor(maxcough_cohsonet*0.8), xend = floor(nobs_cohsonet*0.5), yend = floor(maxcough_cohsonet*0.8) ), colour = "red",  linetype="dashed", size=1)

#plot(p10c)


###################################################################################
#plot of cumulative cough time as function of persons for Peru data

plot_peru <- plot_data %>% filter(Study == 'Peru')
nobs_peru = nrow(plot_peru)
maxcough_peru = max(plot_peru$CumDaysofCough)


p1p <-  ggplot(plot_peru, aes(x=PersonID,y=CumDaysofCough), colour='black' ) + geom_line(size=1.5) 
p2p <- p1p + geom_line( aes(y=CumFixedCough), colour='gray' , size=1.5, linetype = 'dotted')
p3p <- p2p #+ geom_line( aes(y=CumExpCough), colour='blue', size=1.5, linetype = 'dashed' ) + geom_line( aes(y=CumGeomCough), colour='green', size=1.5, linetype = 'dashed' ) 
p4p <- p3p + labs(title = 'Peru', x = "Number of Patients", y = "Cumulative days of Cough" , size = 1.5)
p6p <- p4p + theme(legend.position="none")

p7p <- p6p + geom_segment(aes(x = floor(nobs_peru*0.2), y = 1, xend = floor(nobs_peru*0.2), yend = floor(maxcough_peru*0.5) ), colour = "red", linetype="dashed", size=1)
p8p <- p7p + geom_segment(aes(x = floor(nobs_peru*0.5), y = 1, xend = floor(nobs_peru*0.5), yend = floor(maxcough_peru*0.8) ), colour = "red", linetype="dashed", size=1)
p9p <- p8p + geom_segment(aes(x = 1, y = floor(maxcough_peru*0.5), xend = floor(nobs_peru*0.2), yend = floor(maxcough_peru*0.5) ), colour = "red",  linetype="dashed", size=1)
p10p <- p9p + geom_segment(aes(x = 1, y = floor(maxcough_peru*0.8), xend = floor(nobs_peru*0.5), yend = floor(maxcough_peru*0.8) ), colour = "red",  linetype="dashed", size=1)



###################################################################################
#plot of cumulative cough time as function of persons for China data

plot_china <- plot_data %>% filter(Study == 'China')
nobs_china = nrow(plot_china)
maxcough_china = max(plot_china$CumDaysofCough)


p1ch <-  ggplot(plot_china, aes(x=PersonID,y=CumDaysofCough), colour='black' ) + geom_line(size=1.5) 
p2ch <- p1ch + geom_line( aes(y=CumFixedCough), colour='gray' , size=1.5, linetype = 'dotted')
p3ch <- p2ch #+ geom_line( aes(y=CumExpCough), colour='blue', size=1.5, linetype = 'dashed' ) + geom_line( aes(y=CumGeomCough), colour='green', size=1.5, linetype = 'dashed' )
p4ch <- p3ch + labs(title = 'China', x = "Number of Patients", y = "Cumulative days of Cough" , size = 1.5)
p6ch <- p4ch + theme(legend.position="none")

p7ch <- p6ch + geom_segment(aes(x = floor(nobs_china*0.2), y = 1, xend = floor(nobs_china*0.2), yend = floor(maxcough_china*0.5) ), colour = "red", linetype="dashed", size=1)
p8ch <- p7ch + geom_segment(aes(x = floor(nobs_china*0.5), y = 1, xend = floor(nobs_china*0.5), yend = floor(maxcough_china*0.8) ), colour = "red", linetype="dashed", size=1)
p9ch <- p8ch + geom_segment(aes(x = 1, y = floor(maxcough_china*0.5), xend = floor(nobs_china*0.2), yend = floor(maxcough_china*0.5) ), colour = "red",  linetype="dashed", size=1)
p10ch <- p9ch + geom_segment(aes(x = 1, y = floor(maxcough_china*0.8), xend = floor(nobs_china*0.5), yend = floor(maxcough_china*0.8) ), colour = "red",  linetype="dashed", size=1)




###################################################################################
#plot of cumulative cough time as function of persons for Gambia data

plot_gambia <- plot_data %>% filter(Study == 'The Gambia')
nobs_gambia = nrow(plot_gambia)
maxcough_gambia = max(plot_gambia$CumDaysofCough)


p1g <-  ggplot(plot_gambia, aes(x=PersonID,y=CumDaysofCough), colour='black' ) + geom_line(size=1.5) 
p2g <- p1g + geom_line( aes(y=CumFixedCough), colour='gray' , size=1.5, linetype = 'dotted')
p3g <- p2g #+ geom_line( aes(y=CumExpCough), colour='blue', size=1.5, linetype = 'dashed' ) + geom_line( aes(y=CumGeomCough), colour='green', size=1.5, linetype = 'dashed' )
p4g <- p3g + labs(title = 'The Gambia', x = "Number of Patients", y = "Cumulative days of Cough" , size = 1.5)
p6g <- p4g + theme(legend.position="none")

p7g <- p6g + geom_segment(aes(x = floor(nobs_gambia*0.2), y = 1, xend = floor(nobs_gambia*0.2), yend = floor(maxcough_gambia*0.5) ), colour = "red", linetype="dashed", size=1)
p8g <- p7g + geom_segment(aes(x = floor(nobs_gambia*0.5), y = 1, xend = floor(nobs_gambia*0.5), yend = floor(maxcough_gambia*0.8) ), colour = "red", linetype="dashed", size=1)
p9g <- p8g + geom_segment(aes(x = 1, y = floor(maxcough_gambia*0.5), xend = floor(nobs_gambia*0.2), yend = floor(maxcough_gambia*0.5) ), colour = "red",  linetype="dashed", size=1)
p10g <- p9g + geom_segment(aes(x = 1, y = floor(maxcough_gambia*0.8), xend = floor(nobs_gambia*0.5), yend = floor(maxcough_gambia*0.8) ), colour = "red",  linetype="dashed", size=1)


#combined_plots <- plot_grid(p10ch,p10p,p10g,p10c,p10k,p10s, labels = c("A", "B", "C", "D", "E",'F'), align = "v", nrow =2)
combined_plots <- plot_grid(p10ch,p10p,p10g,p10c,p10k,p10s,  align = "v", nrow =2)
plot(combined_plots)
save_plot(cumulativeplotfig, combined_plots, base_aspect_ratio = 3, nrow = 2) #cowplot way of saving


###################################################################################
#plot percent of cumulative cough time as function of persons for all studies

p1c <-  ggplot(plot_data, aes(x=PercPatients, y=PercDaysofCough, colour=Study, linetype=Study) ) + geom_line( size = 1.25) 
p2c <- p1c + labs(x = "Percent of Patients", y = "Percent cumulative days of cough" , size = 1.5) + theme(legend.key.width = unit(3,"line"))

p7c <- p2c + geom_segment(aes(x = 20, y = 0, xend = 20, yend = 50 ), colour = "red", linetype="dashed", size=1)
p8c <- p7c + geom_segment(aes(x = 50, y = 0, xend = 50, yend = 80 ), colour = "red", linetype="dashed", size=1)
p9c <- p8c + geom_segment(aes(x = 0, y = 50, xend = 20, yend = 50 ), colour = "red",  linetype="dashed", size=1)
p10c <- p9c + geom_segment(aes(x = 0, y = 80, xend = 50, yend = 80 ), colour = "red",  linetype="dashed", size=1)

save_plot(percplotfig, p10c, base_aspect_ratio = 1.5) #cowplot way of saving

