############################################################
#R code for TB infection model, including HIV status, children/adult age groups and MDR status
#Used for TB-MAC project
#SA setting
#written by Andreas Handel (ahandel@uga.edu)
############################################################
rm(list=ls()) #this clears the workspace  
library(deSolve)  #loads ODE solver package.  

###################################################################
#starting with function specifications
#one big function describes the ODE model for TB infection 
#in addition to the various "real" compartments, a number of auxilliary compartments are tracked
#parameters are assigned globally
###################################################################
odeequations=function(t,y,p) 
{ 
    #compartment labeling is as follows:
    #first set of letters are with regard to TB and healthcare status:
    #susceptible unprotected (Su), susceptible protected (Sp) - protection is vaccine or IPT or similar 
    #latent drug sensitive unprotected/protected (Lus, Lps), latent unprotected/protected MDR (Lur, Lpr)
    #diseased, undiagnosed (hidden), drug sensitive/MDR (Ihs, Ihr)
    #diseased diagnosed, in bad quality healthcare system - drug sensitive (Ibds), diseased MDR (Ibdr)
    #diseased diagnosed, in good quality healthcare system - drug sensitive (Igds), diseased MDR (Igdr)

    #2nd letter is A for adult, C for child
    #3rd letter is for HIV status, no HIV (n), HIV untreated (u), HIV treated (t)

    #12 TB compartments x 2 age compartments x 3 HIV compartments = 72 compartments
    
    #allows addressing of variables and parameters directly by name.
    #parameters are currently defined globally, so not in p
    with(as.list(y,p),{                               
    
    #compute time-varying ART treatment parameter
    hiv.treat.rate=0; #no ART until 2004
    hiv.treat.frac=0; #for children
    y.ind=floor(t-2004);
    if (y.ind>0 & y.ind<=length(hiv.treat.rate.vec)) {hiv.treat.rate=HIV.treat.switch*hiv.treat.rate.vec[y.ind]; hiv.treat.frac=HIV.treat.switch*art.level[y.ind]/100;  } #ramp-up from 2005 to 2025
    if (y.ind>length(hiv.treat.rate.vec)) {hiv.treat.rate=HIV.treat.switch*hiv.treat.rate.vec[length(hiv.treat.rate.vec)]; hiv.treat.frac=HIV.treat.switch*0.77; } #if we want to run simulation beyond 2025

    frac.good.detect.C.n = frac.good.detect.C.n.base
    frac.good.detect.C.u = frac.good.detect.C.u.base
    frac.good.detect.C.t = frac.good.detect.C.t.base
    frac.good.detect.A.n = frac.good.detect.A.n.base
    frac.good.detect.A.u = frac.good.detect.A.u.base
    frac.good.detect.A.t = frac.good.detect.A.t.base
    frac.undetected = 0.05;

    #altering parameters based on intervention to be modeled
    if (t >= 2016) # year when interventions start
    {

  
    if (int.nr==11 | int.nr==1 | int.nr==7) #called 1a in the document - part of intervention 1, increase proportion of population with access to health care
    {
            #this is modeled as decreasing the fraction of individuals who die prior to being caught by any health system
            #the decrease is modeled by changing the detection rate 
            #starts out at 5%, reduces to 0% 
            if (level.nr<5) 
            {
                t.start=2016; t.end=2021+1; s.start=0.05;  
                frac.undetected = s.start - s.start * level.nr /4 *  min(1,max(0,(t-t.start)/(t.end-t.start)))
            } #end time and end strength of intervention - scaled with level.nr to get 25/50/75/100%
            if (level.nr==5) 
            {
                t.start=2016; t.end=2020+1; s.start=0.05; 
                frac.undetected = s.start - s.start *  min(1,max(0,(t-t.start)/(t.end-t.start)))
            } #advocate choice - should end end of year, therefore the +1

            

      } #end intervention 1a (also used in 1 and 7)

      if (int.nr==12 | int.nr==1 | int.nr==7) #called 1b in the document - part of intervention 1, increase proportion of TB cases accessing high quality TB services
      {
            #Intervention 1: increased access to DOTS, modeled as increased fraction of hosts being moved into the good quality care setting
            #the assumption is that the good quality care setting leads to faster increase in detection rates, 
            if (level.nr<5) {t.start=2016; t.end=2021+1; s.end=(1-0.2)*(level.nr/4); } #end time and end strength of intervention - scaled with level.nr to get 25/50/75/100%
            if (level.nr==5) {t.start=2016; t.end=2020+1; s.end=1-0.2; } #advocate choice - should end end of year, therefore the +1

            frac.good.detect.A.n = 0.2 + pmin(s.end, pmax(0, s.end / (t.end-t.start) * (t-t.start)));  #TB-MAC baseline of 20% accessing good care, should go to 100% by 2021 per country expert
            frac.good.detect.A.u = frac.good.detect.A.n
            frac.good.detect.A.t = frac.good.detect.A.n
            frac.good.detect.C.n = frac.good.detect.A.n
            frac.good.detect.C.u = frac.good.detect.A.u
            frac.good.detect.C.t = frac.good.detect.A.t

       } #end 1b, 1, 7


      if (int.nr==8 | int.nr==2 | int.nr==7) #called 2a in the document - part of intervention 2, only reducing initial default   
      {     
            #for noMDR 
            if (level.nr<5) {t.start=2016; t.end=2021+1; default.levels=(def.frac.base-0.05)*(level.nr/4); } #end time and end strength of intervention - scaled with level.nr to get 25/50/75/100
            if (level.nr==5) {t.start=2016; t.end=2020+1; default.levels=(def.frac.base-0.00001); } #advocate choice of 0, doing almost 0
            def.frac.new = def.frac.base - pmin(default.levels, pmax(0, default.levels / (t.end-t.start) * (t-t.start)))  #starts at base, reduces down to target
      
            #for MDR
            if (level.nr<5) {t.start=2016; t.end=2021+1; default.levels=(def.frac.MDR-0.15)*(level.nr/4); } #end time and end strength of intervention - scaled with level.nr to get 25/50/75/100
            if (level.nr==5) {t.start=2016; t.end=2020+1; default.levels=(def.frac.MDR-0.00001); } #advocate choice
            def.frac.new.MDR = def.frac.MDR - pmin(default.levels, pmax(0, default.levels / (t.end-t.start) * (t-t.start)))  #starts at base, reduces down to target
      
      
              def.frac.Igds.A.n=def.frac.new        #default same in low and high quality tx 
              def.frac.Igdr.A.n=def.frac.new.MDR
              def.frac.Ibds.A.n=def.frac.Igds.A.n / bad.tx.factor 
              def.frac.Ibdr.A.n=def.frac.Igdr.A.n / bad.tx.factor 
              
              def.frac.Igds.A.u=def.frac.Igds.A.n 
              def.frac.Igdr.A.u=def.frac.Igdr.A.n
              def.frac.Ibds.A.u=def.frac.Igds.A.u / bad.tx.factor 
              def.frac.Ibdr.A.u=def.frac.Igdr.A.u / bad.tx.factor 
              
              def.frac.Igds.A.t=def.frac.Igds.A.n 
              def.frac.Igdr.A.t=def.frac.Igdr.A.n
              def.frac.Ibds.A.t=def.frac.Igds.A.t / bad.tx.factor 
              def.frac.Ibdr.A.t=def.frac.Igdr.A.t / bad.tx.factor 
        
              def.frac.Igds.C.n=def.frac.Igds.A.n #kids same as adults 
              def.frac.Igdr.C.n=def.frac.Igdr.A.n
              def.frac.Ibds.C.n=def.frac.Igds.C.n / bad.tx.factor 
              def.frac.Ibdr.C.n=def.frac.Igdr.C.n / bad.tx.factor 
              
              def.frac.Igds.C.u=def.frac.Igds.C.n 
              def.frac.Igdr.C.u=def.frac.Igdr.C.n
              def.frac.Ibds.C.u=def.frac.Igds.C.u / bad.tx.factor 
              def.frac.Ibdr.C.u=def.frac.Igdr.C.u / bad.tx.factor 
              
              def.frac.Igds.C.t=def.frac.Igds.C.n 
              def.frac.Igdr.C.t=def.frac.Igdr.C.u
              def.frac.Ibds.C.t=def.frac.Igds.C.t / bad.tx.factor 
              def.frac.Ibdr.C.t=def.frac.Igdr.C.t / bad.tx.factor 
           
    
      }

      if (int.nr==9 | int.nr==2 | int.nr==7) #called 2b in the document - part of intervention 2, only increase success of nMDR treatment  
      {     
            if (level.nr<5) {t.start=2016; t.end=2021+1;  suc.nMDR.lev=(0.85-suc.Igds.A.n.base)*(level.nr/4); } 
            if (level.nr==5) {t.start=2016; t.end=2020+1; suc.nMDR.lev=(0.85-suc.Igds.A.n.base);  } #advocate choice 
        
            suc.Igds.A.n.base = suc.Igds.A.n.base + pmin(suc.nMDR.lev, pmax(0, suc.nMDR.lev / (t.end-t.start) * (t-t.start)))
            suc.Igds.A.u.base = suc.Igds.A.n.base / hiv.factor
            suc.Igds.A.t.base = suc.Igds.A.n.base

            suc.Igds.C.n.base = suc.Igds.A.n.base
            suc.Igds.C.u.base = suc.Igds.A.u.base
            suc.Igds.C.t.base = suc.Igds.A.t.base
      }

      if (int.nr==10 | int.nr==2 | int.nr==7) #called 2c in the document - part of intervention 2, only increase success of MDR treatment  
      {     
            if (level.nr<5) {t.start=2016; t.end=2025+1;  suc.MDR.lev=(0.67-suc.Igdr.A.n.base)*(level.nr/4);} 
            if (level.nr==5) {t.start=2016; t.end=2020+1;  suc.MDR.lev=(0.75-suc.Igdr.A.n.base); } #advocate choice 
          
            suc.Igdr.A.n.base = suc.Igdr.A.n.base + pmin(suc.MDR.lev, pmax(0, suc.MDR.lev / (t.end-t.start) * (t-t.start)))
            suc.Igdr.A.u.base = suc.Igdr.A.n.base / hiv.factor
            suc.Igdr.A.t.base = suc.Igdr.A.n.base
           
            suc.Igdr.C.n.base = suc.Igdr.A.n.base
            suc.Igdr.C.u.base = suc.Igdr.A.u.base
            suc.Igdr.C.t.base = suc.Igdr.A.t.base
      }

      #Intervention 3 (Xpert) not done for SA 
      #intervention 4 (ACF) implemented in pulse function below 
      #intervention 5 (ACF + IPT) is implemented in pulse function below 
          
   
      if (int.nr==6 | int.nr==7)   
      {
           #Intervention 6,  IPT is implemented as moving HIV+ individuals to the IPT compartment
           #as per post-London, only applies to HIV+ an ART 
           #screening is assumed to be the same as moving those onto prophylaxis
           # should be applied to all HIV+ART, both TB latent and TB susceptible
            if (level.nr<5) 
            {
                t.start=2016; t.end=2019+1; prophy.levels=(0.8-base.HIV.IPT)*(level.nr/4); #assuming 80% of ART can be started in IPT
               #this rates needs to chosen such that specified fraction of TOTAL HIV+ TB latent pop is on IPT - will require some tweaking
               #80% of HIV+ ART LTBI should be on IPT
                prophy.frac= base.HIV.IPT + 1 * pmin(prophy.levels, pmax(0, prophy.levels / (t.end-t.start) * (t-t.start)))  
            } #end time and end strength of intervention - scaled with level.nr to get 25/50/75/100%
            if (level.nr==5) 
            {
                t.start=2016; t.end=2020+1; prophy.levels=(1-base.HIV.IPT); 
                #this rates needs to chosen such that specified fraction of TOTAL HIV+ TB latent pop is on IPT - will require some tweaking
                #100% of HIV+ ART LTBI should be on IPT
                prophy.frac= base.HIV.IPT + 10 * pmin(prophy.levels, pmax(0, prophy.levels / (t.end-t.start) * (t-t.start)))
            } #advocate choice 
            
            prophy.Lus.A.n=0; #only HIV+ on ART
            prophy.Lur.A.n=0; #
            prophy.Lus.A.u = 0; 
            prophy.Lur.A.u = 0; 
            prophy.S.A.t = prophy.frac; #HIV+ ART+ get IPT independent of TB status
            prophy.Lus.A.t = prophy.frac;
            prophy.Lur.A.t = prophy.frac; #ITP has no effect on MDR - but they are still moved into the prophylaxis compartment to correspond to them being screened

            prophy.Lus.C.n = 0;
            prophy.Lur.C.n = 0;
            prophy.Lus.C.u = 0;
            prophy.Lur.C.u = 0;
            prophy.S.C.t = prophy.S.A.t;
            prophy.Lus.C.t = prophy.Lus.A.t;
            prophy.Lur.C.t = prophy.Lur.A.t;
   
      }    
          

    } #finish t>2015 if statement
    
    
    
        detect.C.n.new = detect.C.n.base ;
        detect.C.u.new = detect.C.u.base ;
        detect.C.t.new = detect.C.t.base ;
        detect.A.n.new = detect.A.n.base ;
        detect.A.u.new = detect.A.u.base ;
        detect.A.t.new = detect.A.t.base ;

        #compute detect rates - this is combination of doing 1a and then 1b on top
        detect.C.n = detect.C.n.new * frac.good.detect.C.n + detect.C.n.new * bad.detect.factor * (1 - frac.good.detect.C.n)
        detect.C.u = detect.C.u.new * frac.good.detect.C.u + detect.C.u.new * bad.detect.factor * (1 - frac.good.detect.C.u)
        detect.C.t = detect.C.t.new * frac.good.detect.C.t + detect.C.t.new * bad.detect.factor * (1 - frac.good.detect.C.t)

        detect.A.n = detect.A.n.new * frac.good.detect.A.n + detect.A.n.new * bad.detect.factor * (1 - frac.good.detect.A.n)
        detect.A.u = detect.A.u.new * frac.good.detect.A.u + detect.A.u.new * bad.detect.factor * (1 - frac.good.detect.A.u)
        detect.A.t = detect.A.t.new * frac.good.detect.A.t + detect.A.t.new * bad.detect.factor * (1 - frac.good.detect.A.t)

    
    
        #just for diagnostics  - those should be 5%, i.e. 5% die before entering the diagnosis compartments
        if (1==2)
        {
            base.no.access.Ihs.C.n =  (deathrate + tb.C.n.deathrate ) / (detect.C.n.base + growup + deathrate + tb.C.n.deathrate )
            base.no.access.Ihs.C.u =  (deathrate + tb.C.u.deathrate + hiv.C.u.deathrate) / (detect.C.u.base + growup + deathrate + tb.C.u.deathrate + hiv.C.u.deathrate)
            base.no.access.Ihs.C.t =  (deathrate + tb.C.t.deathrate + hiv.C.t.deathrate) / (detect.C.t.base + growup + deathrate + tb.C.t.deathrate + hiv.C.t.deathrate)
            base.no.access.Ihr.C.n =  (deathrate + mdr.C.n.deathrate ) / (detect.C.n.base + growup + deathrate + mdr.C.n.deathrate )
            base.no.access.Ihr.C.u =  (deathrate + mdr.C.u.deathrate + hiv.C.u.deathrate) / (detect.C.u.base + growup + deathrate + mdr.C.u.deathrate + hiv.C.u.deathrate)
            base.no.access.Ihr.C.t =  (deathrate + mdr.C.t.deathrate + hiv.C.t.deathrate) / (detect.C.t.base + growup + deathrate + mdr.C.t.deathrate + hiv.C.t.deathrate)
            base.no.access.C=c(base.no.access.Ihs.C.n,base.no.access.Ihs.C.u,base.no.access.Ihs.C.t,base.no.access.Ihr.C.n,base.no.access.Ihr.C.u,base.no.access.Ihr.C.t)

            no.access.Ihs.C.n =  (deathrate + tb.C.n.deathrate ) / (detect.C.n + growup + deathrate + tb.C.n.deathrate )
            no.access.Ihs.C.u =  (deathrate + tb.C.u.deathrate + hiv.C.u.deathrate) / (detect.C.u + growup + deathrate + tb.C.u.deathrate + hiv.C.u.deathrate)
            no.access.Ihs.C.t =  (deathrate + tb.C.t.deathrate + hiv.C.t.deathrate) / (detect.C.t + growup + deathrate + tb.C.t.deathrate + hiv.C.t.deathrate)
            no.access.Ihr.C.n =  (deathrate + mdr.C.n.deathrate ) / (detect.C.n + growup + deathrate + mdr.C.n.deathrate )
            no.access.Ihr.C.u =  (deathrate + mdr.C.u.deathrate + hiv.C.u.deathrate) / (detect.C.u + growup + deathrate + mdr.C.u.deathrate + hiv.C.u.deathrate)
            no.access.Ihr.C.t =  (deathrate + mdr.C.t.deathrate + hiv.C.t.deathrate) / (detect.C.t + growup + deathrate + mdr.C.t.deathrate + hiv.C.t.deathrate)
            no.access.C=c(no.access.Ihs.C.n,no.access.Ihs.C.u,no.access.Ihs.C.t,no.access.Ihr.C.n,no.access.Ihr.C.u,no.access.Ihr.C.t)

            base.no.access.Ihs.A.n =  (deathrate + tb.A.n.deathrate ) / (detect.A.n.base + hiv.infect.rate + deathrate + tb.A.n.deathrate )
            base.no.access.Ihs.A.u =  (deathrate + tb.A.u.deathrate + hiv.A.u.deathrate) / (detect.A.u.base + hiv.treat.rate +  deathrate + tb.A.u.deathrate + hiv.A.u.deathrate)
            base.no.access.Ihs.A.t =  (deathrate + tb.A.t.deathrate + hiv.A.t.deathrate) / (detect.A.t.base  +  deathrate + tb.A.t.deathrate + hiv.A.t.deathrate)
            base.no.access.Ihr.A.n =  (deathrate + mdr.A.n.deathrate ) / (detect.A.n.base + hiv.infect.rate +  deathrate + mdr.A.n.deathrate )
            base.no.access.Ihr.A.u =  (deathrate + mdr.A.u.deathrate + hiv.A.u.deathrate) / (detect.A.u.base + hiv.treat.rate +  deathrate + mdr.A.u.deathrate + hiv.A.u.deathrate)
            base.no.access.Ihr.A.t =  (deathrate + mdr.A.t.deathrate + hiv.A.t.deathrate) / (detect.A.t.base +  deathrate + mdr.A.t.deathrate + hiv.A.t.deathrate)
            base.no.access.A=c(base.no.access.Ihs.A.n,base.no.access.Ihs.A.u,base.no.access.Ihs.A.t,base.no.access.Ihr.A.n,base.no.access.Ihr.A.u,base.no.access.Ihr.A.t)

            no.access.Ihs.A.n =  (deathrate + tb.A.n.deathrate ) / (detect.A.n + hiv.infect.rate +  deathrate + tb.A.n.deathrate )
            no.access.Ihs.A.u =  (deathrate + tb.A.u.deathrate + hiv.A.u.deathrate) / (detect.A.u + hiv.treat.rate +  deathrate + tb.A.u.deathrate + hiv.A.u.deathrate)
            no.access.Ihs.A.t =  (deathrate + tb.A.t.deathrate + hiv.A.t.deathrate) / (detect.A.t +  deathrate + tb.A.t.deathrate + hiv.A.t.deathrate)
            no.access.Ihr.A.n =  (deathrate + mdr.A.n.deathrate ) / (detect.A.n + hiv.infect.rate +  deathrate + mdr.A.n.deathrate )
            no.access.Ihr.A.u =  (deathrate + mdr.A.u.deathrate + hiv.A.u.deathrate) / (detect.A.u + hiv.treat.rate +  deathrate + mdr.A.u.deathrate + hiv.A.u.deathrate)
            no.access.Ihr.A.t =  (deathrate + mdr.A.t.deathrate + hiv.A.t.deathrate) / (detect.A.t +  deathrate + mdr.A.t.deathrate + hiv.A.t.deathrate)
            no.access.A=c(no.access.Ihs.A.n,no.access.Ihs.A.u,no.access.Ihs.A.t,no.access.Ihr.A.n,no.access.Ihr.A.u,no.access.Ihr.A.t)
            #browser()
          }
          #end just for diagnostics part

    
  

     #treatment succes is a combination of non-default and success given treatment
     suc.Igds.A.n=(1 - def.frac.Igds.A.n)*suc.Igds.A.n.base
     suc.Igdr.A.n=(1 - def.frac.Igdr.A.n)*suc.Igdr.A.n.base
     suc.Ibds.A.n=(1 - def.frac.Ibds.A.n)*suc.Ibds.A.n.base
     suc.Ibdr.A.n=(1 - def.frac.Ibdr.A.n)*suc.Ibdr.A.n.base
     
     suc.Igds.A.u=(1 - def.frac.Igds.A.u)*suc.Igds.A.u.base
     suc.Igdr.A.u=(1 - def.frac.Igdr.A.u)*suc.Igdr.A.u.base
     suc.Ibds.A.u=(1 - def.frac.Ibds.A.u)*suc.Ibds.A.u.base
     suc.Ibdr.A.u=(1 - def.frac.Ibdr.A.u)*suc.Ibdr.A.u.base
     
     suc.Igds.A.t=(1 - def.frac.Igds.A.t)*suc.Igds.A.t.base
     suc.Igdr.A.t=(1 - def.frac.Igdr.A.t)*suc.Igdr.A.t.base
     suc.Ibds.A.t=(1 - def.frac.Ibds.A.t)*suc.Ibds.A.t.base
     suc.Ibdr.A.t=(1 - def.frac.Ibdr.A.t)*suc.Ibdr.A.t.base
     
     suc.Igds.C.n=(1 - def.frac.Igds.C.n)*suc.Igds.C.n.base
     suc.Igdr.C.n=(1 - def.frac.Igdr.C.n)*suc.Igdr.C.n.base
     suc.Ibds.C.n=(1 - def.frac.Ibds.C.n)*suc.Ibds.C.n.base
     suc.Ibdr.C.n=(1 - def.frac.Ibdr.C.n)*suc.Ibdr.C.n.base
     
     suc.Igds.C.u=(1 - def.frac.Igds.C.u)*suc.Igds.C.u.base
     suc.Igdr.C.u=(1 - def.frac.Igdr.C.u)*suc.Igdr.C.u.base
     suc.Ibds.C.u=(1 - def.frac.Ibds.C.u)*suc.Ibds.C.u.base
     suc.Ibdr.C.u=(1 - def.frac.Ibdr.C.u)*suc.Ibdr.C.u.base
     
     suc.Igds.C.t=(1 - def.frac.Igds.C.t)*suc.Igds.C.t.base
     suc.Igdr.C.t=(1 - def.frac.Igdr.C.t)*suc.Igdr.C.t.base
     suc.Ibds.C.t=(1 - def.frac.Ibds.C.t)*suc.Ibds.C.t.base
     suc.Ibdr.C.t=(1 - def.frac.Ibdr.C.t)*suc.Ibdr.C.t.base
     
     
    
    ###############################################
    #total populations for each age and HIV category
    ###############################################
    C.tot.n = Su.C.n + Sp.C.n + Lus.C.n + Lur.C.n + Lps.C.n + Lpr.C.n + Ihs.C.n + Ihr.C.n + Ibds.C.n + Ibdr.C.n + Igds.C.n + Igdr.C.n;
    C.tot.u = Su.C.u + Sp.C.u + Lus.C.u + Lur.C.u + Lps.C.u + Lpr.C.u + Ihs.C.u + Ihr.C.u + Ibds.C.u + Ibdr.C.u + Igds.C.u + Igdr.C.u;
    C.tot.t = Su.C.t + Sp.C.t + Lus.C.t + Lur.C.t + Lps.C.t + Lpr.C.t + Ihs.C.t + Ihr.C.t + Ibds.C.t + Ibdr.C.t + Igds.C.t + Igdr.C.t;
    C.tot   = C.tot.n + C.tot.u + C.tot.t

    A.tot.n = Su.A.n + Sp.A.n + Lus.A.n + Lur.A.n + Lps.A.n + Lpr.A.n + Ihs.A.n + Ihr.A.n + Ibds.A.n + Ibdr.A.n + Igds.A.n + Igdr.A.n;
    A.tot.u = Su.A.u + Sp.A.u + Lus.A.u + Lur.A.u + Lps.A.u + Lpr.A.u + Ihs.A.u + Ihr.A.u + Ibds.A.u + Ibdr.A.u + Igds.A.u + Igdr.A.u;
    A.tot.t = Su.A.t + Sp.A.t + Lus.A.t + Lur.A.t + Lps.A.t + Lpr.A.t + Ihs.A.t + Ihr.A.t + Ibds.A.t + Ibdr.A.t + Igds.A.t + Igdr.A.t;
    A.tot   = A.tot.n + A.tot.u + A.tot.t
    N.tot=C.tot+A.tot                
                
    ###############################################
    #forces of infection
    ###############################################
    #for transmission we assume frequency dependence, i.e. force is proportional to prevalence of diseased hosts (not numbers/density)
    #treating FoI/prevalence in kids and adults independently (instead of summing it all and dividing by total population)
 
    #forces of infection - nonMDR
    lam.C.s.n = b.hs.C.n*Ihs.C.n + b.bds.C.n*Ibds.C.n + b.gds.C.n*Igds.C.n
    lam.C.s.u = b.hs.C.u*Ihs.C.u + b.bds.C.u*Ibds.C.u + b.gds.C.u*Igds.C.u
    lam.C.s.t = b.hs.C.t*Ihs.C.t + b.bds.C.t*Ibds.C.t + b.gds.C.t*Igds.C.t
    lam.C.s = ( lam.C.s.n  + lam.C.s.u + lam.C.s.t  ) 
 
    lam.A.s.n = b.hs.A.n*Ihs.A.n + b.bds.A.n*Ibds.A.n + b.gds.A.n*Igds.A.n
    lam.A.s.u = b.hs.A.u*Ihs.A.u + b.bds.A.u*Ibds.A.u + b.gds.A.u*Igds.A.u
    lam.A.s.t = b.hs.A.t*Ihs.A.t + b.bds.A.t*Ibds.A.t + b.gds.A.t*Igds.A.t
    lam.A.s = ( lam.A.s.n  + lam.A.s.u + lam.A.s.t  ) 
    
    #force of infection - MDR
    lam.C.r.n = b.hr.C.n*Ihr.C.n + b.bdr.C.n*Ibdr.C.n + b.gdr.C.n*Igdr.C.n
    lam.C.r.u = b.hr.C.u*Ihr.C.u + b.bdr.C.u*Ibdr.C.u + b.gdr.C.u*Igdr.C.u
    lam.C.r.t = b.hr.C.t*Ihr.C.t + b.bdr.C.t*Ibdr.C.t + b.gdr.C.t*Igdr.C.t
    lam.C.r = ( lam.C.r.n  + lam.C.r.u + lam.C.r.t  ) 

    lam.A.r.n = b.hr.A.n*Ihr.A.n + b.bdr.A.n*Ibdr.A.n + b.gdr.A.n*Igdr.A.n
    lam.A.r.u = b.hr.A.u*Ihr.A.u + b.bdr.A.u*Ibdr.A.u + b.gdr.A.u*Igdr.A.u
    lam.A.r.t = b.hr.A.t*Ihr.A.t + b.bdr.A.t*Ibdr.A.t + b.gdr.A.t*Igdr.A.t
    lam.A.r = ( lam.A.r.n  + lam.A.r.u + lam.A.r.t  ) 
    
    f.inf.s=lam.C.s / max(1e-6, C.tot) + lam.A.s / max(1e-6, A.tot)
    f.inf.r=lam.C.r / max(1e-6, C.tot) + lam.A.r / max(1e-6, A.tot)
 
    #f.inf.s=( lam.C.s + lam.A.s ) / max(1e-6, N.tot)
    #f.inf.r=( lam.C.r + lam.A.r ) / max(1e-6, N.tot)
 
    
    ###############################################
    #inflows and outflows for all compartments                                                   
    ###############################################

    #children compartments - non HIV
    #children are currently not assumed to aquire HIV other than through birth, 
    #therefore no change in HIV status (or additional treatment for HIV) occurs after initial assignment to one of the categories at birth   
    #only exception is that kids treated for TB who are HIV positive are also all treated for HIV   
    #assuming disease due to re-infection only for non-MDR (since MDR frequency is low)
  
    dSu.C.n.inflow  = birthrate*(1-hiv.birth.frac) + suc.Ibds.C.n*tx.Ibds.C.n*Ibds.C.n + suc.Igds.C.n*tx.Igds.C.n*Igds.C.n + suc.Ibdr.C.n*tx.Ibdr.C.n*Ibdr.C.n + suc.Igdr.C.n*tx.Igdr.C.n*Igdr.C.n
    dSu.C.n.outflow = ( (f.inf.s + f.inf.r) * pi.Su.C.n  + growup + deathrate + prophy.S.C.n) * Su.C.n      
    dSu.C.n= dSu.C.n.inflow - dSu.C.n.outflow
    
    dSp.C.n.inflow = prophy.S.C.n * Su.C.n  #entering protected compartment through protection of unprotected hosts only
    dSp.C.n.outflow = ( (f.inf.s + f.inf.r) * pi.Sp.C.n  + growup + deathrate) * Sp.C.n  
    dSp.C.n= dSp.C.n.inflow - dSp.C.n.outflow

    dLus.C.n.inflow = (1-ff.Lus.C.n) * f.inf.s* pi.Su.C.n * Su.C.n #slow progressors
    dLus.C.n.outflow = (prog.Lus.C.n  + re.Lus.C.n*ff.Lus.C.n*f.inf.s*pi.Su.C.n  + growup + deathrate + prophy.Lus.C.n) * Lus.C.n #outflow due to progression, re-infection, prophylaxis
    dLus.C.n= dLus.C.n.inflow  -  dLus.C.n.outflow

    dLps.C.n.inflow = (1-ff.Lps.C.n) * f.inf.s* pi.Sp.C.n * Sp.C.n + prophy.Lus.C.n * Lus.C.n #slow progressors, prophylaxis
    dLps.C.n.outflow = (prog.Lps.C.n + re.Lps.C.n*ff.Lps.C.n*f.inf.s*pi.Sp.C.n +  growup + deathrate) * Lps.C.n #outflow due to progression, re-infection
    dLps.C.n= dLps.C.n.inflow  -  dLps.C.n.outflow

    dLur.C.n.inflow = (1-ff.Lur.C.n) * f.inf.r * pi.Su.C.n * Su.C.n #slow progressors
    dLur.C.n.outflow = ( prog.Lur.C.n + re.Lur.C.n*ff.Lur.C.n*f.inf.r* pi.Su.C.n +  growup + deathrate + prophy.Lur.C.n) * Lur.C.n #outflow due to progression, no re-infection, prophylaxis
    dLur.C.n= dLur.C.n.inflow  -  dLur.C.n.outflow

    dLpr.C.n.inflow = (1-ff.Lpr.C.n) * f.inf.r* pi.Sp.C.n * Sp.C.n + prophy.Lur.C.n * Lur.C.n #slow progressors, prophylaxis
    dLpr.C.n.outflow = (prog.Lpr.C.n + re.Lpr.C.n*ff.Lpr.C.n*f.inf.r*pi.Sp.C.n + growup + deathrate) * Lpr.C.n #outflow due to progression, re-infection
    dLpr.C.n= dLpr.C.n.inflow  -  dLpr.C.n.outflow

    dIhs.C.n.inflow = ff.Lus.C.n*f.inf.s*pi.Su.C.n*Su.C.n + prog.Lus.C.n*Lus.C.n + re.Lus.C.n*ff.Lus.C.n*f.inf.s* pi.Su.C.n*Lus.C.n + ff.Lps.C.n*f.inf.s*pi.Sp.C.n*Sp.C.n + prog.Lps.C.n*Lps.C.n + re.Lps.C.n*ff.Lps.C.n*f.inf.s* pi.Sp.C.n*Lps.C.n + (1 - mdrfrac.Ibds.C.n) * (1 - suc.Ibds.C.n) * tx.Ibds.C.n * Ibds.C.n  + (1 - mdrfrac.Igds.C.n) * (1 - suc.Igds.C.n) * tx.Igds.C.n * Igds.C.n 
    dIhs.C.n.outflow = (detect.C.n + growup + deathrate + tb.C.n.deathrate) * Ihs.C.n + detect.C.n * frac.undetected * Ihs.C.n
    dIhs.C.n = dIhs.C.n.inflow  - dIhs.C.n.outflow  
    
    dIhr.C.n.inflow = ff.Lur.C.n*f.inf.r*pi.Su.C.n*Su.C.n + prog.Lur.C.n*Lur.C.n + re.Lur.C.n*ff.Lur.C.n*f.inf.r* pi.Su.C.n*Lur.C.n + ff.Lpr.C.n*f.inf.r*pi.Sp.C.n*Sp.C.n + prog.Lpr.C.n*Lpr.C.n + re.Lpr.C.n*ff.Lpr.C.n*f.inf.r* pi.Sp.C.n*Lpr.C.n   +  mdrfrac.Ibds.C.n * (1 - suc.Ibds.C.n) * tx.Ibds.C.n * Ibds.C.n  +  mdrfrac.Igds.C.n * (1 - suc.Igds.C.n) * tx.Igds.C.n * Igds.C.n + (1 - suc.Ibdr.C.n) * tx.Ibdr.C.n * Ibdr.C.n +  (1 - suc.Igdr.C.n) * tx.Igdr.C.n * Igdr.C.n  + detect.C.n * frac.undetected * Ihr.C.n
    dIhr.C.n.outflow = (detect.C.n + growup + deathrate + mdr.C.n.deathrate) * Ihr.C.n 
    dIhr.C.n = dIhr.C.n.inflow  - dIhr.C.n.outflow  
                                         
    dIbds.C.n.inflow = (1-frac.good.care.C.n)  * detect.C.n * (1-frac.undetected) * Ihs.C.n
    dIbds.C.n.outflow = (growup + deathrate + tb.C.n.deathrate + tx.Ibds.C.n) * Ibds.C.n
    dIbds.C.n = dIbds.C.n.inflow -  dIbds.C.n.outflow        
    
    dIgds.C.n.inflow = frac.good.care.C.n  * detect.C.n *  (1-frac.undetected) * Ihs.C.n
    dIgds.C.n.outflow = (growup + deathrate + tb.C.n.deathrate + tx.Igds.C.n) * Igds.C.n
    dIgds.C.n = dIgds.C.n.inflow -  dIgds.C.n.outflow             
    
    dIbdr.C.n.inflow = (1-frac.good.care.C.n) * detect.C.n * (1-frac.undetected) * Ihr.C.n
    dIbdr.C.n.outflow = (growup + deathrate + mdr.C.n.deathrate + tx.Ibdr.C.n) * Ibdr.C.n
    dIbdr.C.n = dIbdr.C.n.inflow - dIbdr.C.n.outflow
    
    dIgdr.C.n.inflow = frac.good.care.C.n  * detect.C.n * (1-frac.undetected) * Ihr.C.n
    dIgdr.C.n.outflow = (growup + deathrate + mdr.C.n.deathrate + tx.Igdr.C.n) * Igdr.C.n
    dIgdr.C.n = dIgdr.C.n.inflow - dIgdr.C.n.outflow
    
     
    
    #children compartments - HIV untreated
    dSu.C.u.inflow  = birthrate*hiv.birth.frac*(1-hiv.treat.frac) + suc.Ibds.C.u*tx.Ibds.C.u*Ibds.C.u + suc.Igds.C.u*tx.Igds.C.u*Igds.C.u + suc.Ibdr.C.u*tx.Ibdr.C.u*Ibdr.C.u + suc.Igdr.C.u*tx.Igdr.C.u*Igdr.C.u
    dSu.C.u.outflow = ( (f.inf.s + f.inf.r) * pi.Su.C.u  + growup + deathrate + hiv.C.u.deathrate + prophy.S.C.u) * Su.C.u      
    dSu.C.u= dSu.C.u.inflow - dSu.C.u.outflow
    
    dSp.C.u.inflow = prophy.S.C.u * Su.C.u  #entering protected compartment through protection of unprotected hosts only
    dSp.C.u.outflow = ( (f.inf.s + f.inf.r) * pi.Sp.C.u  + growup + deathrate + hiv.C.u.deathrate) * Sp.C.u  
    dSp.C.u= dSp.C.u.inflow - dSp.C.u.outflow
    
    dLus.C.u.inflow = (1-ff.Lus.C.u) * f.inf.s* pi.Su.C.u * Su.C.u #slow progressors
    dLus.C.u.outflow = (prog.Lus.C.u  + re.Lus.C.u * ff.Lus.C.u * f.inf.s* pi.Su.C.u  + growup + deathrate + hiv.C.u.deathrate + prophy.Lus.C.u )* Lus.C.u #outflow due to progression, re-infection, prophylaxis
    dLus.C.u= dLus.C.u.inflow  -  dLus.C.u.outflow

    dLps.C.u.inflow = (1-ff.Lps.C.u) * f.inf.s* pi.Sp.C.u * Sp.C.u + prophy.Lus.C.u * Lus.C.u #slow progressors, prophylaxis
    dLps.C.u.outflow = (prog.Lps.C.u  + re.Lps.C.u * ff.Lps.C.u * f.inf.s* pi.Sp.C.u  + growup + deathrate + hiv.C.u.deathrate )* Lps.C.u #outflow due to progression, re-i
    dLps.C.u= dLps.C.u.inflow  -  dLps.C.u.outflow

    dLur.C.u.inflow = (1-ff.Lur.C.u) * f.inf.r* pi.Su.C.u * Su.C.u #slow progressors
    dLur.C.u.outflow = (prog.Lur.C.u  + re.Lur.C.u * ff.Lur.C.u * f.inf.r* pi.Su.C.u  +  growup + deathrate + hiv.C.u.deathrate + prophy.Lur.C.u )* Lur.C.u 
    dLur.C.u= dLur.C.u.inflow  -  dLur.C.u.outflow

    dLpr.C.u.inflow = (1-ff.Lpr.C.u) * f.inf.r* pi.Sp.C.u * Sp.C.u + prophy.Lur.C.u * Lur.C.u #slow progressors, prophylaxis
    dLpr.C.u.outflow = (prog.Lpr.C.u  + re.Lpr.C.u * ff.Lpr.C.u * f.inf.r* pi.Sp.C.u  +  growup + deathrate + hiv.C.u.deathrate )* Lpr.C.u 
    dLpr.C.u= dLpr.C.u.inflow  -  dLpr.C.u.outflow

    dIhs.C.u.inflow = ff.Lus.C.u*f.inf.s*pi.Su.C.u*Su.C.u + prog.Lus.C.u*Lus.C.u + re.Lus.C.u*ff.Lus.C.u*f.inf.s* pi.Su.C.u*Lus.C.u + ff.Lps.C.u*f.inf.s*pi.Sp.C.u*Sp.C.u + prog.Lps.C.u*Lps.C.u + re.Lps.C.u*ff.Lps.C.u*f.inf.s* pi.Sp.C.u*Lps.C.u + (1 - mdrfrac.Ibds.C.u) * (1 - suc.Ibds.C.u) * tx.Ibds.C.u * Ibds.C.u + (1 - mdrfrac.Igds.C.u) * (1 - suc.Igds.C.u) * tx.Igds.C.u * Igds.C.u  
    dIhs.C.u.outflow = (detect.C.u + growup + deathrate + tb.C.u.deathrate + hiv.C.u.deathrate) * Ihs.C.u  + detect.C.u * frac.undetected * Ihs.C.u
    dIhs.C.u = dIhs.C.u.inflow  - dIhs.C.u.outflow  
    
    dIhr.C.u.inflow = ff.Lur.C.u*f.inf.r*pi.Su.C.u*Su.C.u + prog.Lur.C.u*Lur.C.u + re.Lur.C.u*ff.Lur.C.u*f.inf.r* pi.Su.C.u*Lur.C.u  + ff.Lpr.C.u*f.inf.r*pi.Sp.C.u*Sp.C.u + prog.Lpr.C.u*Lpr.C.u + re.Lpr.C.u*ff.Lpr.C.u*f.inf.r* pi.Sp.C.u*Lpr.C.u +  mdrfrac.Ibds.C.u * (1 - suc.Ibds.C.u) * tx.Ibds.C.u * Ibds.C.u +  (1 - suc.Ibdr.C.u) * tx.Ibdr.C.u * Ibdr.C.u  +  mdrfrac.Igds.C.u * (1 - suc.Igds.C.u) * tx.Igds.C.u * Igds.C.u +  (1 - suc.Igdr.C.u) * tx.Igdr.C.u * Igdr.C.u + detect.C.u * frac.undetected * Ihr.C.u
    dIhr.C.u.outflow = (detect.C.u + growup + deathrate + mdr.C.u.deathrate + hiv.C.u.deathrate) * Ihr.C.u 
    dIhr.C.u = dIhr.C.u.inflow  - dIhr.C.u.outflow  
                                         
    dIbds.C.u.inflow = (1-frac.good.care.C.u)  * detect.C.u * (1-frac.undetected) * Ihs.C.u
    dIbds.C.u.outflow = (growup + deathrate + tb.C.u.deathrate + tx.Ibds.C.u + hiv.C.u.deathrate) * Ibds.C.u
    dIbds.C.u = dIbds.C.u.inflow -  dIbds.C.u.outflow        
    
    dIgds.C.u.inflow = frac.good.care.C.u  * detect.C.u * (1-frac.undetected) * Ihs.C.u
    dIgds.C.u.outflow = (growup + deathrate + tb.C.u.deathrate + tx.Igds.C.u + hiv.C.u.deathrate) * Igds.C.u
    dIgds.C.u = dIgds.C.u.inflow -  dIgds.C.u.outflow             
    
    dIbdr.C.u.inflow = (1-frac.good.care.C.u) * detect.C.u * (1-frac.undetected) * Ihr.C.u
    dIbdr.C.u.outflow = (growup + deathrate + mdr.C.u.deathrate + tx.Ibdr.C.u + hiv.C.u.deathrate) * Ibdr.C.u
    dIbdr.C.u = dIbdr.C.u.inflow - dIbdr.C.u.outflow
    
    dIgdr.C.u.inflow = frac.good.care.C.u  * detect.C.u * (1-frac.undetected) * Ihr.C.u
    dIgdr.C.u.outflow = (growup + deathrate + mdr.C.u.deathrate + tx.Igdr.C.u + hiv.C.u.deathrate) * Igdr.C.u
    dIgdr.C.u = dIgdr.C.u.inflow - dIgdr.C.u.outflow


    #children compartments - HIV treated
    dSu.C.t.inflow  = birthrate*hiv.birth.frac*hiv.treat.frac + suc.Ibds.C.t*tx.Ibds.C.t*Ibds.C.t + suc.Igds.C.t*tx.Igds.C.t*Igds.C.t + suc.Ibdr.C.t*tx.Ibdr.C.t*Ibdr.C.t + suc.Igdr.C.t*tx.Igdr.C.t*Igdr.C.t
    dSu.C.t.outflow = ((f.inf.s + f.inf.r) * pi.Su.C.t  + growup + deathrate + hiv.C.t.deathrate + prophy.S.C.t) * Su.C.t      
    dSu.C.t= dSu.C.t.inflow - dSu.C.t.outflow
    
    dSp.C.t.inflow = prophy.S.C.t * Su.C.t  #entering protected compartment through protection of unprotected hosts only
    dSp.C.t.outflow = ((f.inf.s + f.inf.r) * pi.Sp.C.t  + growup + deathrate + hiv.C.t.deathrate) * Sp.C.t  
    dSp.C.t= dSp.C.t.inflow - dSp.C.t.outflow
    
    dLus.C.t.inflow = (1-ff.Lus.C.t) * f.inf.s* pi.Su.C.t * Su.C.t #slow progressors
    dLus.C.t.outflow = (prog.Lus.C.t  + re.Lus.C.t * ff.Lus.C.t * f.inf.s* pi.Su.C.t  +  growup + deathrate + hiv.C.t.deathrate + prophy.Lus.C.t )* Lus.C.t 
    dLus.C.t= dLus.C.t.inflow  -  dLus.C.t.outflow

    dLps.C.t.inflow = (1-ff.Lps.C.t) * f.inf.s* pi.Sp.C.t * Sp.C.t + prophy.Lus.C.t * Lus.C.t #slow progressors, prophylaxis
    dLps.C.t.outflow = (prog.Lps.C.t  + re.Lps.C.t * ff.Lps.C.t * f.inf.s* pi.Sp.C.t  +  growup + deathrate + hiv.C.t.deathrate )* Lps.C.t #outflow due to progression, re-i
    dLps.C.t= dLps.C.t.inflow  -  dLps.C.t.outflow

    dLur.C.t.inflow = (1-ff.Lur.C.t) * f.inf.r* pi.Su.C.t * Su.C.t #slow progressors
    dLur.C.t.outflow = (prog.Lur.C.t  + re.Lur.C.t * ff.Lur.C.t * f.inf.r* pi.Su.C.t  +  growup + deathrate + hiv.C.t.deathrate + prophy.Lur.C.t )* Lur.C.t 
    dLur.C.t= dLur.C.t.inflow  -  dLur.C.t.outflow

    dLpr.C.t.inflow = (1-ff.Lpr.C.t) * f.inf.r* pi.Sp.C.t * Sp.C.t + prophy.Lur.C.t * Lur.C.t #slow progressors, prophylaxis
    dLpr.C.t.outflow = (prog.Lpr.C.t  + re.Lpr.C.t * ff.Lpr.C.t * f.inf.r* pi.Sp.C.t  +  growup + deathrate + hiv.C.t.deathrate  )* Lpr.C.t 
    dLpr.C.t= dLpr.C.t.inflow  -  dLpr.C.t.outflow

    dIhs.C.t.inflow = ff.Lus.C.t*f.inf.s*pi.Su.C.t*Su.C.t + prog.Lus.C.t*Lus.C.t + re.Lus.C.t*ff.Lus.C.t*f.inf.s* pi.Su.C.t*Lus.C.t + ff.Lps.C.t*f.inf.s*pi.Sp.C.t*Sp.C.t + prog.Lps.C.t*Lps.C.t + re.Lps.C.t*ff.Lps.C.t*f.inf.s* pi.Sp.C.t*Lps.C.t  + (1 - mdrfrac.Ibds.C.t) * (1 - suc.Ibds.C.t) * tx.Ibds.C.t * Ibds.C.t  + (1 - mdrfrac.Igds.C.t) * (1 - suc.Igds.C.t) * tx.Igds.C.t * Igds.C.t 
    dIhs.C.t.outflow = (detect.C.t + growup + deathrate + tb.C.t.deathrate + hiv.C.t.deathrate) * Ihs.C.t +  detect.C.t * frac.undetected * Ihs.C.t
    dIhs.C.t = dIhs.C.t.inflow  - dIhs.C.t.outflow  
    
    dIhr.C.t.inflow = ff.Lur.C.t*f.inf.r*pi.Su.C.t*Su.C.t + prog.Lur.C.t*Lur.C.t + re.Lur.C.t*ff.Lur.C.t*f.inf.r* pi.Su.C.t*Lur.C.t + ff.Lpr.C.t*f.inf.r*pi.Sp.C.t*Sp.C.t + prog.Lpr.C.t*Lpr.C.t + re.Lpr.C.t*ff.Lpr.C.t*f.inf.r* pi.Sp.C.t*Lpr.C.t  +  mdrfrac.Ibds.C.t*(1 - suc.Ibds.C.t)*tx.Ibds.C.t*Ibds.C.t +  (1 - suc.Ibdr.C.t) * tx.Ibdr.C.t * Ibdr.C.t  +  mdrfrac.Igds.C.t * (1 - suc.Igds.C.t) * tx.Igds.C.t * Igds.C.t +  (1 - suc.Igdr.C.t) * tx.Igdr.C.t * Igdr.C.t +  detect.C.t * frac.undetected * Ihr.C.t
    dIhr.C.t.outflow = (detect.C.t + growup + deathrate + mdr.C.t.deathrate + hiv.C.t.deathrate) * Ihr.C.t 
    dIhr.C.t = dIhr.C.t.inflow  - dIhr.C.t.outflow  
                                         
    dIbds.C.t.inflow = (1-frac.good.care.C.t)  *  detect.C.t * (1-frac.undetected) * Ihs.C.t
    dIbds.C.t.outflow = (growup + deathrate + tb.C.t.deathrate + tx.Ibds.C.t + hiv.C.t.deathrate) * Ibds.C.t
    dIbds.C.t = dIbds.C.t.inflow -  dIbds.C.t.outflow        
    
    dIgds.C.t.inflow = frac.good.care.C.t * detect.C.t * (1-frac.undetected) * Ihs.C.t
    dIgds.C.t.outflow = (growup + deathrate + tb.C.t.deathrate + tx.Igds.C.t + hiv.C.t.deathrate) * Igds.C.t
    dIgds.C.t = dIgds.C.t.inflow -  dIgds.C.t.outflow             
    
    dIbdr.C.t.inflow = (1-frac.good.care.C.t)  * detect.C.t * (1-frac.undetected) * Ihr.C.t
    dIbdr.C.t.outflow = (growup + deathrate + mdr.C.t.deathrate + tx.Ibdr.C.t + hiv.C.t.deathrate) * Ibdr.C.t
    dIbdr.C.t = dIbdr.C.t.inflow - dIbdr.C.t.outflow
    
    dIgdr.C.t.inflow = frac.good.care.C.t  * detect.C.t * (1-frac.undetected) * Ihr.C.t
    dIgdr.C.t.outflow = (growup + deathrate + mdr.C.t.deathrate + tx.Igdr.C.t + hiv.C.t.deathrate) * Igdr.C.t
    dIgdr.C.t = dIgdr.C.t.inflow - dIgdr.C.t.outflow
    

                               
    #equations for adults                                               
    #adult compartments - non HIV
    #HIV and subsequent ART treatment occur at a fixed rate per year, no HIV infection process is modeled
    dSu.A.n.inflow  = growup * Su.C.n + suc.Ibds.A.n*tx.Ibds.A.n*Ibds.A.n + suc.Igds.A.n*tx.Igds.A.n*Igds.A.n + suc.Ibdr.A.n*tx.Ibdr.A.n *Ibdr.A.n + suc.Igdr.A.n*tx.Igdr.A.n*Igdr.A.n
    dSu.A.n.outflow = ((f.inf.s + f.inf.r) * pi.Su.A.n + hiv.infect.rate + deathrate + prophy.S.A.n) * Su.A.n      
    dSu.A.n= dSu.A.n.inflow - dSu.A.n.outflow
    
    dSp.A.n.inflow = growup * Sp.C.n + prophy.S.A.n * Su.A.n  #entering protected compartment through protection of unprotected hosts only and growing up of protected hosts
    dSp.A.n.outflow = ( (f.inf.s + f.inf.r) * pi.Sp.A.n + hiv.infect.rate + deathrate) * Sp.A.n  
    dSp.A.n= dSp.A.n.inflow - dSp.A.n.outflow
    
    dLus.A.n.inflow =growup * Lus.C.n + (1-ff.Lus.A.n) * f.inf.s* pi.Su.A.n * Su.A.n #slow progressors
    dLus.A.n.outflow = (prog.Lus.A.n  + re.Lus.A.n * ff.Lus.A.n * f.inf.s* pi.Su.A.n  + hiv.infect.rate + deathrate + prophy.Lus.A.n )* Lus.A.n 
    dLus.A.n= dLus.A.n.inflow  -  dLus.A.n.outflow

    dLps.A.n.inflow =growup * Lps.C.n + (1-ff.Lps.A.n) * f.inf.s* pi.Sp.A.n * Sp.A.n + prophy.Lus.A.n * Lus.A.n #slow progressors, prophylaxis
    dLps.A.n.outflow = (prog.Lps.A.n  + re.Lps.A.n * ff.Lps.A.n * f.inf.s* pi.Sp.A.n  + hiv.infect.rate + deathrate )* Lps.A.n 
    dLps.A.n= dLps.A.n.inflow  -  dLps.A.n.outflow

    dLur.A.n.inflow =growup * Lur.C.n + (1-ff.Lur.A.n) * f.inf.r* pi.Su.A.n * Su.A.n #slow progressors
    dLur.A.n.outflow = (prog.Lur.A.n  + re.Lur.A.n * ff.Lur.A.n * f.inf.r* pi.Su.A.n  + hiv.infect.rate + deathrate + prophy.Lur.A.n )* Lur.A.n
    dLur.A.n= dLur.A.n.inflow  -  dLur.A.n.outflow

    dLpr.A.n.inflow =growup * Lpr.C.n + (1-ff.Lpr.A.n) * f.inf.r* pi.Sp.A.n * Sp.A.n + prophy.Lur.A.n * Lur.A.n #slow progressors, prophylaxis
    dLpr.A.n.outflow = (prog.Lpr.A.n  + re.Lpr.A.n * ff.Lpr.A.n * f.inf.r* pi.Sp.A.n  + hiv.infect.rate + deathrate )* Lpr.A.n
    dLpr.A.n= dLpr.A.n.inflow  -  dLpr.A.n.outflow

    dIhs.A.n.inflow = growup*Ihs.C.n + ff.Lus.A.n*f.inf.s*pi.Su.A.n*Su.A.n + prog.Lus.A.n*Lus.A.n + re.Lus.A.n*ff.Lus.A.n*f.inf.s*pi.Su.A.n*Lus.A.n + ff.Lps.A.n*f.inf.s*pi.Sp.A.n*Sp.A.n + prog.Lps.A.n*Lps.A.n + re.Lps.A.n*ff.Lps.A.n*f.inf.s* pi.Sp.A.n*Lps.A.n  + (1 - mdrfrac.Ibds.A.n)*(1 - suc.Ibds.A.n)*tx.Ibds.A.n*Ibds.A.n + (1 - mdrfrac.Igds.A.n)*(1 - suc.Igds.A.n)*tx.Igds.A.n*Igds.A.n + detect.A.n * frac.undetected * Ihs.A.n
    dIhs.A.n.outflow = (detect.A.n + hiv.infect.rate + deathrate + tb.A.n.deathrate) * Ihs.A.n
    dIhs.A.n = dIhs.A.n.inflow  - dIhs.A.n.outflow  

    dIhr.A.n.inflow = growup*Ihr.C.n + ff.Lur.A.n*f.inf.r*pi.Su.A.n*Su.A.n + prog.Lur.A.n*Lur.A.n + re.Lur.A.n*ff.Lur.A.n*f.inf.r*pi.Su.A.n*Lur.A.n + ff.Lpr.A.n*f.inf.r*pi.Sp.A.n*Sp.A.n + prog.Lpr.A.n*Lpr.A.n + re.Lpr.A.n*ff.Lpr.A.n*f.inf.r* pi.Sp.A.n*Lpr.A.n   +  mdrfrac.Ibds.A.n*(1 - suc.Ibds.A.n) * tx.Ibds.A.n * Ibds.A.n  + mdrfrac.Igds.A.n * (1 - suc.Igds.A.n) * tx.Igds.A.n * Igds.A.n + (1 - suc.Igdr.A.n) * tx.Igdr.A.n * Igdr.A.n +  (1 - suc.Ibdr.A.n) * tx.Ibdr.A.n * Ibdr.A.n + detect.A.n * frac.undetected * Ihr.A.n
    dIhr.A.n.outflow = (detect.A.n + hiv.infect.rate + deathrate + mdr.A.n.deathrate) * Ihr.A.n
    dIhr.A.n = dIhr.A.n.inflow  - dIhr.A.n.outflow  
                                         
    dIbds.A.n.inflow = growup * Ibds.C.n + (1-frac.good.care.A.n) * detect.A.n * (1-frac.undetected) * Ihs.A.n
    dIbds.A.n.outflow = (hiv.infect.rate + deathrate + tb.A.n.deathrate + tx.Ibds.A.n) * Ibds.A.n
    dIbds.A.n = dIbds.A.n.inflow -  dIbds.A.n.outflow        
    
    dIgds.A.n.inflow = growup * Igds.C.n + frac.good.care.A.n * detect.A.n * (1-frac.undetected) * Ihs.A.n
    dIgds.A.n.outflow = (hiv.infect.rate + deathrate + tb.A.n.deathrate + tx.Igds.A.n) * Igds.A.n
    dIgds.A.n = dIgds.A.n.inflow -  dIgds.A.n.outflow             
    
    dIbdr.A.n.inflow = growup * Ibdr.C.n + (1-frac.good.care.A.n)  * detect.A.n * (1-frac.undetected) * Ihr.A.n
    dIbdr.A.n.outflow = (hiv.infect.rate + deathrate + mdr.A.n.deathrate + tx.Ibdr.A.n) * Ibdr.A.n
    dIbdr.A.n = dIbdr.A.n.inflow - dIbdr.A.n.outflow
    
    dIgdr.A.n.inflow = growup * Igdr.C.n + frac.good.care.A.n  * detect.A.n * (1-frac.undetected) * Ihr.A.n
    dIgdr.A.n.outflow = (hiv.infect.rate + deathrate + mdr.A.n.deathrate + tx.Igdr.A.n) * Igdr.A.n
    dIgdr.A.n = dIgdr.A.n.inflow - dIgdr.A.n.outflow




              
    #adult compartments - HIV untreated
    dSu.A.u.inflow  = growup*Su.C.u + hiv.infect.rate * Su.A.n +  suc.Ibds.A.u*tx.Ibds.A.u*Ibds.A.u + suc.Igds.A.u*tx.Igds.A.u*Igds.A.u + suc.Ibdr.A.u*tx.Ibdr.A.u*Ibdr.A.u + suc.Igdr.A.u*tx.Igdr.A.u*Igdr.A.u
    dSu.A.u.outflow = ( (f.inf.s + f.inf.r) * pi.Su.A.u  + hiv.treat.rate + deathrate + hiv.A.u.deathrate + prophy.S.A.u) * Su.A.u
    dSu.A.u= dSu.A.u.inflow - dSu.A.u.outflow
    
    dSp.A.u.inflow = growup * Sp.C.u + hiv.infect.rate * Sp.A.n + prophy.S.A.u * Su.A.u  
    dSp.A.u.outflow = ( (f.inf.s + f.inf.r) * pi.Sp.A.u + hiv.treat.rate + deathrate + hiv.A.u.deathrate) * Sp.A.u
    dSp.A.u= dSp.A.u.inflow - dSp.A.u.outflow
    
    dLus.A.u.inflow =growup * Lus.C.u + (1-ff.Lus.A.u) * f.inf.s* pi.Su.A.u * Su.A.u + hiv.infect.rate * Lus.A.n  #slow progressors
    dLus.A.u.outflow = (prog.Lus.A.u  + re.Lus.A.u * ff.Lus.A.u * f.inf.s* pi.Su.A.u  + hiv.treat.rate + deathrate + hiv.A.u.deathrate + prophy.Lus.A.u )* Lus.A.u 
    dLus.A.u= dLus.A.u.inflow  -  dLus.A.u.outflow

    dLps.A.u.inflow =growup * Lps.C.u + (1-ff.Lps.A.u) * f.inf.s* pi.Sp.A.u * Sp.A.u + prophy.Lus.A.u * Lus.A.u + hiv.infect.rate * Lps.A.n #slow progressors, prophylaxis
    dLps.A.u.outflow = (prog.Lps.A.u  + re.Lps.A.u * ff.Lps.A.u * f.inf.s* pi.Sp.A.u  + hiv.treat.rate + deathrate + hiv.A.u.deathrate )* Lps.A.u 
    dLps.A.u= dLps.A.u.inflow  -  dLps.A.u.outflow

    dLur.A.u.inflow =growup * Lur.C.u + (1-ff.Lur.A.u)*f.inf.r*pi.Su.A.u*Su.A.u + hiv.infect.rate * Lur.A.n #slow progressors
    dLur.A.u.outflow = (prog.Lur.A.u  + re.Lur.A.u*ff.Lur.A.u*f.inf.r*pi.Su.A.u  + hiv.treat.rate + deathrate + hiv.A.u.deathrate + prophy.Lur.A.u )* Lur.A.u
    dLur.A.u= dLur.A.u.inflow  -  dLur.A.u.outflow

    dLpr.A.u.inflow =growup * Lpr.C.u + (1-ff.Lpr.A.u) * f.inf.r* pi.Sp.A.u * Sp.A.u + prophy.Lur.A.u * Lur.A.u + hiv.infect.rate * Lpr.A.n #slow progressors, prophylaxis
    dLpr.A.u.outflow = (prog.Lpr.A.u  + re.Lpr.A.u * ff.Lpr.A.u * f.inf.r* pi.Sp.A.u  + hiv.treat.rate + deathrate + hiv.A.u.deathrate )* Lpr.A.u
    dLpr.A.u= dLpr.A.u.inflow  -  dLpr.A.u.outflow

    dIhs.A.u.inflow = growup * Ihs.C.u + ff.Lus.A.u*f.inf.s*pi.Su.A.u*Su.A.u + ff.Lps.A.u*f.inf.s*pi.Sp.A.u*Sp.A.u + (prog.Lus.A.u+ re.Lus.A.u*ff.Lus.A.u*f.inf.s*pi.Su.A.u)*Lus.A.u  + (prog.Lps.A.u + re.Lps.A.u*ff.Lps.A.u*f.inf.s*pi.Sp.A.u)*Lps.A.u  + (1 - mdrfrac.Ibds.A.u) * (1 - suc.Ibds.A.u) * tx.Ibds.A.u * Ibds.A.u  +  (1 - mdrfrac.Igds.A.u) * (1 - suc.Igds.A.u) * tx.Igds.A.u * Igds.A.u + hiv.infect.rate * Ihs.A.n  +  detect.A.u * frac.undetected * Ihs.A.u
    dIhs.A.u.outflow = (detect.A.u + hiv.treat.rate + deathrate + hiv.A.u.deathrate + tb.A.u.deathrate) * Ihs.A.u
    dIhs.A.u = dIhs.A.u.inflow  - dIhs.A.u.outflow  
    
    dIhr.A.u.inflow = growup * Ihr.C.u + ff.Lur.A.u*f.inf.r*pi.Su.A.u*Su.A.u + prog.Lur.A.u*Lur.A.u + re.Lur.A.u*ff.Lur.A.u*f.inf.r* pi.Su.A.u*Lur.A.u + ff.Lpr.A.u*f.inf.r*pi.Sp.A.u*Sp.A.u + prog.Lpr.A.u*Lpr.A.u + re.Lpr.A.u*ff.Lpr.A.u*f.inf.r* pi.Sp.A.u*Lpr.A.u + mdrfrac.Ibds.A.u * (1 - suc.Ibds.A.u) * tx.Ibds.A.u * Ibds.A.u +  (1 - suc.Ibdr.A.u) * tx.Ibdr.A.u * Ibdr.A.u + mdrfrac.Igds.A.u * (1 - suc.Igds.A.u) * tx.Igds.A.u * Igds.A.u + (1 - suc.Igdr.A.u) * tx.Igdr.A.u * Igdr.A.u + hiv.infect.rate * Ihr.A.n +  detect.A.u * frac.undetected * Ihr.A.u
    dIhr.A.u.outflow = (detect.A.u + hiv.treat.rate + deathrate + hiv.A.u.deathrate + mdr.A.u.deathrate) * Ihr.A.u
    dIhr.A.u = dIhr.A.u.inflow  - dIhr.A.u.outflow  
                                         
    dIbds.A.u.inflow  = growup * Ibds.C.u + (1-frac.good.care.A.u) * detect.A.u * (1-frac.undetected) * Ihs.A.u + hiv.infect.rate * Ibds.A.n
    dIbds.A.u.outflow = (hiv.treat.rate + deathrate + hiv.A.u.deathrate + tb.A.u.deathrate + tx.Ibds.A.u) * Ibds.A.u
    dIbds.A.u = dIbds.A.u.inflow -  dIbds.A.u.outflow        
    
    dIgds.A.u.inflow  = growup * Igds.C.u + frac.good.care.A.u* detect.A.u * (1-frac.undetected) * Ihs.A.u   + hiv.infect.rate * Igds.A.n
    dIgds.A.u.outflow = (hiv.treat.rate + deathrate + hiv.A.u.deathrate + tb.A.u.deathrate + tx.Igds.A.u) * Igds.A.u
    dIgds.A.u = dIgds.A.u.inflow - dIgds.A.u.outflow             
    
    dIbdr.A.u.inflow  = growup * Ibdr.C.u + (1-frac.good.care.A.u) * detect.A.u * (1-frac.undetected) * Ihr.A.u + hiv.infect.rate * Ibdr.A.n
    dIbdr.A.u.outflow = (hiv.treat.rate + deathrate + hiv.A.u.deathrate + mdr.A.u.deathrate + tx.Ibdr.A.u) * Ibdr.A.u
    dIbdr.A.u = dIbdr.A.u.inflow - dIbdr.A.u.outflow
    
    dIgdr.A.u.inflow  = growup * Igdr.C.u +  frac.good.care.A.u  * detect.A.u * (1-frac.undetected) * Ihr.A.u   + hiv.infect.rate * Igdr.A.n
    dIgdr.A.u.outflow = (hiv.treat.rate + deathrate + hiv.A.u.deathrate + mdr.A.u.deathrate + tx.Igdr.A.u) * Igdr.A.u
    dIgdr.A.u = dIgdr.A.u.inflow - dIgdr.A.u.outflow



    #adult compartments - HIV treated
    dSu.A.t.inflow  = growup*Su.C.t + hiv.treat.rate*Su.A.u + suc.Ibds.A.t*tx.Ibds.A.t*Ibds.A.t + suc.Igds.A.t*tx.Igds.A.t*Igds.A.t + suc.Ibdr.A.t*tx.Ibdr.A.t*Ibdr.A.t + suc.Igdr.A.t*tx.Igdr.A.t*Igdr.A.t
    dSu.A.t.outflow = ((f.inf.s + f.inf.r) * pi.Su.A.t  + deathrate + hiv.A.t.deathrate + prophy.S.A.t) * Su.A.t      
    dSu.A.t= dSu.A.t.inflow - dSu.A.t.outflow
                         
    dSp.A.t.inflow = growup * Sp.C.t + hiv.treat.rate*Sp.A.u + prophy.S.A.t * Su.A.t  #entering through protection of unprotected hosts only and growing up of protected hosts
    dSp.A.t.outflow = ((f.inf.s + f.inf.r) * pi.Sp.A.t  +  deathrate + hiv.A.t.deathrate) * Sp.A.t  
    dSp.A.t= dSp.A.t.inflow - dSp.A.t.outflow
    
    dLus.A.t.inflow = growup * Lus.C.t + (1-ff.Lus.A.t) * f.inf.s* pi.Su.A.t * Su.A.t + hiv.treat.rate*Lus.A.u  #slow progressors
    dLus.A.t.outflow = (prog.Lus.A.t  + re.Lus.A.t * ff.Lus.A.t * f.inf.s* pi.Su.A.t  +  deathrate + hiv.A.t.deathrate + prophy.Lus.A.t )* Lus.A.t 
    dLus.A.t= dLus.A.t.inflow  -  dLus.A.t.outflow

    dLps.A.t.inflow = growup * Lps.C.t + (1-ff.Lps.A.t) * f.inf.s* pi.Sp.A.t * Sp.A.t + prophy.Lus.A.t * Lus.A.t + hiv.treat.rate*Lps.A.u #slow progressors, prophylaxis
    dLps.A.t.outflow = (prog.Lps.A.t  + re.Lps.A.t * ff.Lps.A.t * f.inf.s * pi.Sp.A.t  +  deathrate + hiv.A.t.deathrate)* Lps.A.t
    dLps.A.t= dLps.A.t.inflow  -  dLps.A.t.outflow

    dLur.A.t.inflow = growup * Lur.C.t + (1-ff.Lur.A.t) * f.inf.r* pi.Su.A.t * Su.A.t + hiv.treat.rate*Lur.A.u #slow progressors
    dLur.A.t.outflow = (prog.Lur.A.t  + re.Lur.A.t * ff.Lur.A.t * f.inf.r* pi.Su.A.t  +  deathrate + hiv.A.t.deathrate + prophy.Lur.A.t )* Lur.A.t
    dLur.A.t= dLur.A.t.inflow  -  dLur.A.t.outflow

    dLpr.A.t.inflow = growup * Lpr.C.t + (1-ff.Lpr.A.t) * f.inf.r* pi.Sp.A.t * Sp.A.t + prophy.Lur.A.t * Lur.A.t + hiv.treat.rate*Lpr.A.u #slow progressors, prophylaxis
    dLpr.A.t.outflow = (prog.Lpr.A.t  + re.Lpr.A.t * ff.Lpr.A.t * f.inf.r* pi.Sp.A.t  +  deathrate + hiv.A.t.deathrate )* Lpr.A.t 
    dLpr.A.t= dLpr.A.t.inflow  -  dLpr.A.t.outflow

    dIhs.A.t.inflow = growup * Ihs.C.t + ff.Lus.A.t*f.inf.s*pi.Su.A.t*Su.A.t + prog.Lus.A.t*Lus.A.t + re.Lus.A.t*ff.Lus.A.t*f.inf.s* pi.Su.A.t*Lus.A.t + ff.Lps.A.t*f.inf.s*pi.Sp.A.t*Sp.A.t + prog.Lps.A.t*Lps.A.t + re.Lps.A.t*ff.Lps.A.t*f.inf.s* pi.Sp.A.t*Lps.A.t + (1 - mdrfrac.Ibds.A.t) * (1 - suc.Ibds.A.t) * tx.Ibds.A.t * Ibds.A.t  + (1 - mdrfrac.Igds.A.t) * (1 - suc.Igds.A.t) * tx.Igds.A.t * Igds.A.t + hiv.treat.rate*Ihs.A.u   +  detect.A.t * frac.undetected * Ihs.A.t
    dIhs.A.t.outflow = (detect.A.t + deathrate + hiv.A.t.deathrate + tb.A.t.deathrate) * Ihs.A.t
    dIhs.A.t = dIhs.A.t.inflow  - dIhs.A.t.outflow  
    
    dIhr.A.t.inflow = growup * Ihr.C.t + ff.Lur.A.t*f.inf.r*pi.Su.A.t*Su.A.t + prog.Lur.A.t*Lur.A.t + re.Lur.A.t*ff.Lur.A.t*f.inf.r* pi.Su.A.t*Lur.A.t  + ff.Lpr.A.t*f.inf.r*pi.Sp.A.t*Sp.A.t + prog.Lpr.A.t*Lpr.A.t + re.Lpr.A.t*ff.Lpr.A.t*f.inf.r* pi.Sp.A.t*Lpr.A.t  +  mdrfrac.Ibds.A.t * (1 - suc.Ibds.A.t)*tx.Ibds.A.t*Ibds.A.t  +  mdrfrac.Igds.A.t *(1 - suc.Igds.A.t)*tx.Igds.A.t*Igds.A.t + (1 - suc.Ibdr.A.t) * tx.Ibdr.A.t * Ibdr.A.t + (1 - suc.Igdr.A.t)*tx.Igdr.A.t*Igdr.A.t  + hiv.treat.rate * Ihr.A.u  +  detect.A.t * frac.undetected * Ihr.A.t
    dIhr.A.t.outflow = (detect.A.t + deathrate + hiv.A.t.deathrate + mdr.A.t.deathrate) * Ihr.A.t
    dIhr.A.t = dIhr.A.t.inflow  - dIhr.A.t.outflow  
                                         
    dIbds.A.t.inflow = growup * Ibds.C.t + (1-frac.good.care.A.t)  * detect.A.t * (1- frac.undetected) * Ihs.A.t + hiv.treat.rate * Ibds.A.u
    dIbds.A.t.outflow = ( deathrate + hiv.A.t.deathrate + tb.A.t.deathrate + tx.Ibds.A.t) * Ibds.A.t
    dIbds.A.t = dIbds.A.t.inflow -  dIbds.A.t.outflow        
    
    dIgds.A.t.inflow = growup * Igds.C.t + frac.good.care.A.t  * detect.A.t * (1- frac.undetected) * Ihs.A.t  + hiv.treat.rate * Igds.A.u
    dIgds.A.t.outflow = ( deathrate + hiv.A.t.deathrate + tb.A.t.deathrate + tx.Igds.A.t) * Igds.A.t
    dIgds.A.t = dIgds.A.t.inflow -  dIgds.A.t.outflow             
    
    dIbdr.A.t.inflow = growup * Ibdr.C.t + (1-frac.good.care.A.t)  * detect.A.t * (1- frac.undetected) * Ihr.A.t + hiv.treat.rate * Ibdr.A.u
    dIbdr.A.t.outflow = ( deathrate + hiv.A.t.deathrate + mdr.A.t.deathrate + tx.Ibdr.A.t) * Ibdr.A.t
    dIbdr.A.t = dIbdr.A.t.inflow - dIbdr.A.t.outflow
    
    dIgdr.A.t.inflow = growup * Igdr.C.t + frac.good.care.A.t  * detect.A.t * (1- frac.undetected) * Ihr.A.t + hiv.treat.rate * Igdr.A.u
    dIgdr.A.t.outflow = ( deathrate + hiv.A.t.deathrate + mdr.A.t.deathrate + tx.Igdr.A.t) * Igdr.A.t
    dIgdr.A.t = dIgdr.A.t.inflow - dIgdr.A.t.outflow
  
   
    #collect entries for all TB states for adult and children, HIV no/untreated/treated
    dC.n=c(dSu.C.n, dSp.C.n, dLus.C.n, dLur.C.n, dLps.C.n, dLpr.C.n, dIhs.C.n, dIhr.C.n, dIbds.C.n, dIbdr.C.n, dIgds.C.n, dIgdr.C.n)
    dC.u=c(dSu.C.u, dSp.C.u, dLus.C.u, dLur.C.u, dLps.C.u, dLpr.C.u, dIhs.C.u, dIhr.C.u, dIbds.C.u, dIbdr.C.u, dIgds.C.u, dIgdr.C.u)
    dC.t=c(dSu.C.t, dSp.C.t, dLus.C.t, dLur.C.t, dLps.C.t, dLpr.C.t, dIhs.C.t, dIhr.C.t, dIbds.C.t, dIbdr.C.t, dIgds.C.t, dIgdr.C.t)

    dA.n=c(dSu.A.n, dSp.A.n, dLus.A.n, dLur.A.n, dLps.A.n, dLpr.A.n, dIhs.A.n, dIhr.A.n, dIbds.A.n, dIbdr.A.n, dIgds.A.n, dIgdr.A.n)
    dA.u=c(dSu.A.u, dSp.A.u, dLus.A.u, dLur.A.u, dLps.A.u, dLpr.A.u, dIhs.A.u, dIhr.A.u, dIbds.A.u, dIbdr.A.u, dIgds.A.u, dIgdr.A.u)
    dA.t=c(dSu.A.t, dSp.A.t, dLus.A.t, dLur.A.t, dLps.A.t, dLpr.A.t, dIhs.A.t, dIhr.A.t, dIbds.A.t, dIbdr.A.t, dIgds.A.t, dIgdr.A.t)



    #also track additional states as auxilliary variables for incidence of TB, notification, and TB mortality
    #all kinds of auxiliary states for children

    #non-HIV states
    dIhs.C.n.inc = dIhs.C.n.inflow   #new TB incidence in each category
    dIhr.C.n.inc = dIhr.C.n.inflow  
    dIbds.C.n.inc = dIbds.C.n.inflow
    dIbdr.C.n.inc = dIbdr.C.n.inflow
    dIgds.C.n.inc = dIgds.C.n.inflow
    dIgdr.C.n.inc = dIgdr.C.n.inflow

    dIhs.C.n.death = tb.C.n.deathrate * Ihs.C.n #new TB deaths in each category
    dIhr.C.n.death = mdr.C.n.deathrate * Ihr.C.n
    dIbds.C.n.death = tb.C.n.deathrate * Ibds.C.n
    dIbdr.C.n.death = mdr.C.n.deathrate * Ibdr.C.n
    dIgds.C.n.death = tb.C.n.deathrate * Igds.C.n
    dIgdr.C.n.death = mdr.C.n.deathrate * Igdr.C.n

    #HIV no ART states
    dIhs.C.u.inc = dIhs.C.u.inflow   #new TB incidence in each category
    dIhr.C.u.inc = dIhr.C.u.inflow
    dIbds.C.u.inc = dIbds.C.u.inflow
    dIbdr.C.u.inc = dIbdr.C.u.inflow
    dIgds.C.u.inc = dIgds.C.u.inflow
    dIgdr.C.u.inc = dIgdr.C.u.inflow

    dIhs.C.u.death = tb.C.u.deathrate * Ihs.C.u #new TB deaths in each category
    dIhr.C.u.death = mdr.C.u.deathrate * Ihr.C.u
    dIbds.C.u.death = tb.C.u.deathrate * Ibds.C.u
    dIbdr.C.u.death = mdr.C.u.deathrate * Ibdr.C.u
    dIgds.C.u.death = tb.C.u.deathrate * Igds.C.u
    dIgdr.C.u.death = mdr.C.u.deathrate * Igdr.C.u

    #HIV ART states
    dIhs.C.t.inc = dIhs.C.t.inflow   #new TB incidence in each category
    dIhr.C.t.inc = dIhr.C.t.inflow
    dIbds.C.t.inc = dIbds.C.t.inflow
    dIbdr.C.t.inc = dIbdr.C.t.inflow
    dIgds.C.t.inc = dIgds.C.t.inflow
    dIgdr.C.t.inc = dIgdr.C.t.inflow

    dIhs.C.t.death = tb.C.t.deathrate * Ihs.C.t #new TB deaths in each category
    dIhr.C.t.death = mdr.C.t.deathrate * Ihr.C.t
    dIbds.C.t.death = tb.C.t.deathrate * Ibds.C.t
    dIbdr.C.t.death = mdr.C.t.deathrate * Ibdr.C.t
    dIgds.C.t.death = tb.C.t.deathrate * Igds.C.t
    dIgdr.C.t.death = mdr.C.t.deathrate * Igdr.C.t

    #children combined auxilliary variables of incidence and death

    dAux.C.n.inc=c(dIhs.C.n.inc,dIhr.C.n.inc,dIbds.C.n.inc,dIbdr.C.n.inc,dIgds.C.n.inc,dIgdr.C.n.inc)  #all TB incidences for non-HIV
    dAux.C.u.inc=c(dIhs.C.u.inc,dIhr.C.u.inc,dIbds.C.u.inc,dIbdr.C.u.inc,dIgds.C.u.inc,dIgdr.C.u.inc)  #all TB incidences for HIV no ART
    dAux.C.t.inc=c(dIhs.C.t.inc,dIhr.C.t.inc,dIbds.C.t.inc,dIbdr.C.t.inc,dIgds.C.t.inc,dIgdr.C.t.inc)  #all TB incidences for HIV on ART

    dAux.C.n.death=c(dIhs.C.n.death,dIhr.C.n.death,dIbds.C.n.death,dIbdr.C.n.death,dIgds.C.n.death,dIgdr.C.n.death) #all TB deaths for non-HIV
    dAux.C.u.death=c(dIhs.C.u.death,dIhr.C.u.death,dIbds.C.u.death,dIbdr.C.u.death,dIgds.C.u.death,dIgdr.C.u.death) #all TB deaths for HIV no ART
    dAux.C.t.death=c(dIhs.C.t.death,dIhr.C.t.death,dIbds.C.t.death,dIbdr.C.t.death,dIgds.C.t.death,dIgdr.C.t.death) #all TB deaths for HIV on ART

    dAux.C.inc=c(dAux.C.n.inc,dAux.C.u.inc,dAux.C.t.inc) #all TB incidences combined (6 x 3)
    dAux.C.death=c(dAux.C.n.death,dAux.C.u.death,dAux.C.t.death) #all new TB deaths combined (6 x 3)

    #all kinds of auxiliary states for adults

    #non-HIV states
    dIhs.A.n.inc = dIhs.A.n.inflow   #new TB incidence in each category
    dIhr.A.n.inc = dIhr.A.n.inflow
    dIbds.A.n.inc = dIbds.A.n.inflow
    dIbdr.A.n.inc = dIbdr.A.n.inflow
    dIgds.A.n.inc = dIgds.A.n.inflow
    dIgdr.A.n.inc = dIgdr.A.n.inflow

    dIhs.A.n.death = tb.A.n.deathrate * Ihs.A.n #new TB deaths in each category
    dIhr.A.n.death = mdr.A.n.deathrate * Ihr.A.n
    dIbds.A.n.death = tb.A.n.deathrate * Ibds.A.n
    dIbdr.A.n.death = mdr.A.n.deathrate * Ibdr.A.n
    dIgds.A.n.death = tb.A.n.deathrate * Igds.A.n
    dIgdr.A.n.death = mdr.A.n.deathrate * Igdr.A.n

    #HIV no ART states
    dIhs.A.u.inc = dIhs.A.u.inflow   #new TB incidence in each category
    dIhr.A.u.inc = dIhr.A.u.inflow
    dIbds.A.u.inc = dIbds.A.u.inflow
    dIbdr.A.u.inc = dIbdr.A.u.inflow
    dIgds.A.u.inc = dIgds.A.u.inflow
    dIgdr.A.u.inc = dIgdr.A.u.inflow

    dIhs.A.u.death = tb.A.u.deathrate * Ihs.A.u #new TB deaths in each category
    dIhr.A.u.death = mdr.A.u.deathrate * Ihr.A.u
    dIbds.A.u.death = tb.A.u.deathrate * Ibds.A.u
    dIbdr.A.u.death = mdr.A.u.deathrate * Ibdr.A.u
    dIgds.A.u.death = tb.A.u.deathrate * Igds.A.u
    dIgdr.A.u.death = mdr.A.u.deathrate * Igdr.A.u

    #HIV ART states
    dIhs.A.t.inc = dIhs.A.t.inflow   #new TB incidence in each category
    dIhr.A.t.inc = dIhr.A.t.inflow
    dIbds.A.t.inc = dIbds.A.t.inflow
    dIbdr.A.t.inc = dIbdr.A.t.inflow
    dIgds.A.t.inc = dIgds.A.t.inflow
    dIgdr.A.t.inc = dIgdr.A.t.inflow

    dIhs.A.t.death = tb.A.t.deathrate * Ihs.A.t #new TB deaths in each category
    dIhr.A.t.death = mdr.A.t.deathrate * Ihr.A.t
    dIbds.A.t.death = tb.A.t.deathrate * Ibds.A.t
    dIbdr.A.t.death = mdr.A.t.deathrate * Ibdr.A.t
    dIgds.A.t.death = tb.A.t.deathrate * Igds.A.t
    dIgdr.A.t.death = mdr.A.t.deathrate * Igdr.A.t


    #adult combined auxilliary variables of incidence and death

    dAux.A.n.inc=c(dIhs.A.n.inc,dIhr.A.n.inc,dIbds.A.n.inc,dIbdr.A.n.inc,dIgds.A.n.inc,dIgdr.A.n.inc)  #all TB incidences for non-HIV
    dAux.A.u.inc=c(dIhs.A.u.inc,dIhr.A.u.inc,dIbds.A.u.inc,dIbdr.A.u.inc,dIgds.A.u.inc,dIgdr.A.u.inc)  #all TB incidences for HIV no ART
    dAux.A.t.inc=c(dIhs.A.t.inc,dIhr.A.t.inc,dIbds.A.t.inc,dIbdr.A.t.inc,dIgds.A.t.inc,dIgdr.A.t.inc)  #all TB incidences for HIV on ART

    dAux.A.n.death=c(dIhs.A.n.death,dIhr.A.n.death,dIbds.A.n.death,dIbdr.A.n.death,dIgds.A.n.death,dIgdr.A.n.death) #all TB deaths for non-HIV
    dAux.A.u.death=c(dIhs.A.u.death,dIhr.A.u.death,dIbds.A.u.death,dIbdr.A.u.death,dIgds.A.u.death,dIgdr.A.u.death) #all TB deaths for HIV no ART
    dAux.A.t.death=c(dIhs.A.t.death,dIhr.A.t.death,dIbds.A.t.death,dIbdr.A.t.death,dIgds.A.t.death,dIgdr.A.t.death) #all TB deaths for HIV on ART

    dAux.A.inc=c(dAux.A.n.inc,dAux.A.u.inc,dAux.A.t.inc) #all TB incidences combined (6 x 3)
    dAux.A.death=c(dAux.A.n.death,dAux.A.u.death,dAux.A.t.death) #all new TB deaths combined (6 x 3)


    #auxilliary variables to track numbers treated for TB and MDR in either high quality or low quality setting (i.e. outflow from detected compartments due to treatment)
    #don't count intial default for treating
    #dtx.Ibds.A = (1 - def.frac.Ibds.A.n) * tx.Ibds.A.n * Ibds.A.n + (1 - def.frac.Ibds.A.u) * tx.Ibds.A.u * Ibds.A.u + (1 - def.frac.Ibds.A.t) * tx.Ibds.A.t * Ibds.A.t
    #dtx.Ibdr.A = (1 - def.frac.Ibdr.A.n) * tx.Ibdr.A.n * Ibdr.A.n + (1 - def.frac.Ibdr.A.u) * tx.Ibdr.A.u * Ibdr.A.u + (1 - def.frac.Ibdr.A.t) * tx.Ibdr.A.t * Ibdr.A.t
    #dtx.Igds.A = (1 - def.frac.Igds.A.n) * tx.Igds.A.n * Igds.A.n + (1 - def.frac.Igds.A.u) * tx.Igds.A.u * Igds.A.u + (1 - def.frac.Igds.A.t) * tx.Igds.A.t * Igds.A.t
    #dtx.Igdr.A = (1 - def.frac.Igdr.A.n) * tx.Igdr.A.n * Igdr.A.n + (1 - def.frac.Igdr.A.u) * tx.Igdr.A.u * Igdr.A.u + (1 - def.frac.Igdr.A.t) * tx.Igdr.A.t * Igdr.A.t

    #dtx.Ibds.C = (1 - def.frac.Ibds.C.n) * tx.Ibds.C.n * Ibds.C.n + (1 - def.frac.Ibds.C.u) * tx.Ibds.C.u * Ibds.C.u + (1 - def.frac.Ibds.C.t) * tx.Ibds.C.t * Ibds.C.t
    #dtx.Ibdr.C = (1 - def.frac.Ibdr.C.n) * tx.Ibdr.C.n * Ibdr.C.n + (1 - def.frac.Ibdr.C.u) * tx.Ibdr.C.u * Ibdr.C.u + (1 - def.frac.Ibdr.C.t) * tx.Ibdr.C.t * Ibdr.C.t
    #dtx.Igds.C = (1 - def.frac.Igds.C.n) * tx.Igds.C.n * Igds.C.n + (1 - def.frac.Igds.C.u) * tx.Igds.C.u * Igds.C.u + (1 - def.frac.Igds.C.t) * tx.Igds.C.t * Igds.C.t
    #dtx.Igdr.C = (1 - def.frac.Igdr.C.n) * tx.Igdr.C.n * Igdr.C.n + (1 - def.frac.Igdr.C.u) * tx.Igdr.C.u * Igdr.C.u + (1 - def.frac.Igdr.C.t) * tx.Igdr.C.t * Igdr.C.t

    dtx.Ibds.A =  tx.Ibds.A.n * Ibds.A.n +  tx.Ibds.A.u * Ibds.A.u +  tx.Ibds.A.t * Ibds.A.t
    dtx.Igds.A =  tx.Igds.A.n * Igds.A.n +  tx.Igds.A.u * Igds.A.u +  tx.Igds.A.t * Igds.A.t
    dtx.Ibdr.A = (1 - def.frac.Ibdr.A.n) * tx.Ibdr.A.n * Ibdr.A.n + (1 - def.frac.Ibdr.A.u) * tx.Ibdr.A.u * Ibdr.A.u + (1 - def.frac.Ibdr.A.t) * tx.Ibdr.A.t * Ibdr.A.t
    dtx.Igdr.A = (1 - def.frac.Igdr.A.n) * tx.Igdr.A.n * Igdr.A.n + (1 - def.frac.Igdr.A.u) * tx.Igdr.A.u * Igdr.A.u + (1 - def.frac.Igdr.A.t) * tx.Igdr.A.t * Igdr.A.t

    dtx.Ibds.C =  tx.Ibds.C.n * Ibds.C.n +  tx.Ibds.C.u * Ibds.C.u +  tx.Ibds.C.t * Ibds.C.t
    dtx.Ibdr.C =  tx.Ibdr.C.n * Ibdr.C.n +  tx.Ibdr.C.u * Ibdr.C.u +  tx.Ibdr.C.t * Ibdr.C.t
    dtx.Igds.C = (1 - def.frac.Igds.C.n) * tx.Igds.C.n * Igds.C.n + (1 - def.frac.Igds.C.u) * tx.Igds.C.u * Igds.C.u + (1 - def.frac.Igds.C.t) * tx.Igds.C.t * Igds.C.t
    dtx.Igdr.C = (1 - def.frac.Igdr.C.n) * tx.Igdr.C.n * Igdr.C.n + (1 - def.frac.Igdr.C.u) * tx.Igdr.C.u * Igdr.C.u + (1 - def.frac.Igdr.C.t) * tx.Igdr.C.t * Igdr.C.t

    #if (t>2015) {browser() }

    dtx.all= c(dtx.Ibds.C,dtx.Ibdr.C,dtx.Igds.C,dtx.Igdr.C, dtx.Ibds.A,dtx.Ibdr.A,dtx.Igds.A,dtx.Igdr.A)
 
 
    #further auxilliary variables to track new infections (not cases)
    dnewInf.C = (f.inf.s + f.inf.r) * (pi.Su.C.n * Su.C.n + pi.Su.C.u * Su.C.u + pi.Su.C.t * Su.C.t  +  pi.Sp.C.n * Sp.C.n + pi.Sp.C.t * Sp.C.u + pi.Sp.C.t * Sp.C.t)
    dnewInf.A = (f.inf.s + f.inf.r) * (pi.Su.A.n * Su.A.n + pi.Su.A.u * Su.A.u + pi.Su.A.t * Su.A.t  +  pi.Sp.A.n * Sp.A.n + pi.Sp.A.t * Sp.A.u + pi.Sp.A.t * Sp.A.t)

    #auxilliary variables to track new fast progressors
    dAux.recent.TB.inc.A = ff.Lus.A.n*f.inf.s*pi.Su.A.n*Su.A.n  + re.Lus.A.n*ff.Lus.A.n*f.inf.s* pi.Su.A.n*Lus.A.n + ff.Lps.A.n*f.inf.s*pi.Sp.A.n*Sp.A.n  + re.Lps.A.n*ff.Lps.A.n*f.inf.s* pi.Sp.A.n*Lps.A.n + ff.Lur.A.n*f.inf.r*pi.Su.A.n*Su.A.n  + re.Lur.A.n*ff.Lur.A.n*f.inf.r* pi.Su.A.n*Lur.A.n + ff.Lpr.A.n*f.inf.r*pi.Sp.A.n*Sp.A.n  + re.Lpr.A.n*ff.Lpr.A.n*f.inf.r* pi.Sp.A.n*Lpr.A.n + ff.Lus.A.u*f.inf.s*pi.Su.A.u*Su.A.u  + re.Lus.A.u*ff.Lus.A.u*f.inf.s* pi.Su.A.u*Lus.A.u                    + ff.Lps.A.u*f.inf.s*pi.Sp.A.u*Sp.A.u  + re.Lps.A.u*ff.Lps.A.u*f.inf.s* pi.Sp.A.u*Lps.A.u +  ff.Lur.A.u*f.inf.r*pi.Su.A.u*Su.A.u  + re.Lur.A.u*ff.Lur.A.u*f.inf.r* pi.Su.A.u*Lur.A.u + ff.Lpr.A.u*f.inf.r*pi.Sp.A.u*Sp.A.u + re.Lpr.A.u*ff.Lpr.A.u*f.inf.r* pi.Sp.A.u*Lpr.A.u + ff.Lus.A.t*f.inf.s*pi.Su.A.t*Su.A.t + re.Lus.A.t*ff.Lus.A.t*f.inf.s* pi.Su.A.t*Lus.A.t + ff.Lps.A.t*f.inf.s*pi.Sp.A.t*Sp.A.t  + re.Lps.A.t*ff.Lps.A.t*f.inf.s* pi.Sp.A.t*Lps.A.t +  ff.Lur.A.t*f.inf.r*pi.Su.A.t*Su.A.t  + re.Lur.A.t*ff.Lur.A.t*f.inf.r* pi.Su.A.t*Lur.A.t  + ff.Lpr.A.t*f.inf.r*pi.Sp.A.t*Sp.A.t  + re.Lpr.A.t*ff.Lpr.A.t*f.inf.r* pi.Sp.A.t*Lpr.A.t
                                    
        dAux.recent.TB.inc.C = ff.Lus.C.n*f.inf.s*pi.Su.C.n*Su.C.n  + re.Lus.C.n*ff.Lus.C.n*f.inf.s* pi.Su.C.n*Lus.C.n + ff.Lps.C.n*f.inf.s*pi.Sp.C.n*Sp.C.n  + re.Lps.C.n*ff.Lps.C.n*f.inf.s* pi.Sp.C.n*Lps.C.n + ff.Lur.C.n*f.inf.r*pi.Su.C.n*Su.C.n  + re.Lur.C.n*ff.Lur.C.n*f.inf.r* pi.Su.C.n*Lur.C.n + ff.Lpr.C.n*f.inf.r*pi.Sp.C.n*Sp.C.n  + re.Lpr.C.n*ff.Lpr.C.n*f.inf.r* pi.Sp.C.n*Lpr.C.n + ff.Lus.C.u*f.inf.s*pi.Su.C.u*Su.C.u  + re.Lus.C.u*ff.Lus.C.u*f.inf.s* pi.Su.C.u*Lus.C.u                    + ff.Lps.C.u*f.inf.s*pi.Sp.C.u*Sp.C.u  + re.Lps.C.u*ff.Lps.C.u*f.inf.s* pi.Sp.C.u*Lps.C.u +  ff.Lur.C.u*f.inf.r*pi.Su.C.u*Su.C.u  + re.Lur.C.u*ff.Lur.C.u*f.inf.r* pi.Su.C.u*Lur.C.u + ff.Lpr.C.u*f.inf.r*pi.Sp.C.u*Sp.C.u + re.Lpr.C.u*ff.Lpr.C.u*f.inf.r* pi.Sp.C.u*Lpr.C.u + ff.Lus.C.t*f.inf.s*pi.Su.C.t*Su.C.t + re.Lus.C.t*ff.Lus.C.t*f.inf.s* pi.Su.C.t*Lus.C.t + ff.Lps.C.t*f.inf.s*pi.Sp.C.t*Sp.C.t  + re.Lps.C.t*ff.Lps.C.t*f.inf.s* pi.Sp.C.t*Lps.C.t +  ff.Lur.C.t*f.inf.r*pi.Su.C.t*Su.C.t  + re.Lur.C.t*ff.Lur.C.t*f.inf.r* pi.Su.C.t*Lur.C.t  + ff.Lpr.C.t*f.inf.r*pi.Sp.C.t*Sp.C.t  + re.Lpr.C.t*ff.Lpr.C.t*f.inf.r* pi.Sp.C.t*Lpr.C.t


     #auxilliary variables for all-cause death
     C.n.all.death= deathrate   *(Su.C.n+Sp.C.n+Lus.C.n+Lur.C.n+Lps.C.n+Lpr.C.n+Ihs.C.n+Ihr.C.n+Ibds.C.n+Igds.C.n+Ibdr.C.n+Igdr.C.n)+tb.C.n.deathrate*(Ihs.C.n+Ibds.C.n+Igds.C.n)+mdr.C.n.deathrate*(Ihr.C.n+Ibdr.C.n+Igdr.C.n)
     C.u.all.death=(deathrate+hiv.C.u.deathrate)*(Su.C.u+Sp.C.u+Lus.C.u+Lur.C.u+Lps.C.u+Lpr.C.u+Ihs.C.u+Ihr.C.u+Ibds.C.u+Igds.C.u+Ibdr.C.u+Igdr.C.u)+tb.C.u.deathrate*(Ihs.C.u+Ibds.C.u+Igds.C.u)+mdr.C.u.deathrate*(Ihr.C.u+Ibdr.C.u+Igdr.C.u)
     C.t.all.death=(deathrate+hiv.C.t.deathrate)*(Su.C.t+Sp.C.t+Lus.C.t+Lur.C.t+Lps.C.t+Lpr.C.t+Ihs.C.t+Ihr.C.t+Ibds.C.t+Igds.C.t+Ibdr.C.t+Igdr.C.t)+tb.C.t.deathrate*(Ihs.C.t+Ibds.C.t+Igds.C.t)+mdr.C.t.deathrate*(Ihr.C.t+Ibdr.C.t+Igdr.C.t)
     A.n.all.death= deathrate   *(Su.A.n+Sp.A.n+Lus.A.n+Lur.A.n+Lps.A.n+Lpr.A.n+Ihs.A.n+Ihr.A.n+Ibds.A.n+Igds.A.n+Ibdr.A.n+Igdr.A.n)+tb.A.n.deathrate*(Ihs.A.n+Ibds.A.n+Igds.A.n)+mdr.A.n.deathrate*(Ihr.A.n+Ibdr.A.n+Igdr.A.n)
     A.u.all.death=(deathrate+hiv.A.u.deathrate)*(Su.A.u+Sp.A.u+Lus.A.u+Lur.A.u+Lps.A.u+Lpr.A.u+Ihs.A.u+Ihr.A.u+Ibds.A.u+Igds.A.u+Ibdr.A.u+Igdr.A.u)+tb.A.u.deathrate*(Ihs.A.u+Ibds.A.u+Igds.A.u)+mdr.A.u.deathrate*(Ihr.A.u+Ibdr.A.u+Igdr.A.u)
     A.t.all.death=(deathrate+hiv.A.t.deathrate)*(Su.A.t+Sp.A.t+Lus.A.t+Lur.A.t+Lps.A.t+Lpr.A.t+Ihs.A.t+Ihr.A.t+Ibds.A.t+Igds.A.t+Ibdr.A.t+Igdr.A.t)+tb.A.t.deathrate*(Ihs.A.t+Ibds.A.t+Igds.A.t)+mdr.A.t.deathrate*(Ihr.A.t+Ibdr.A.t+Igdr.A.t)

     dAux.C.all.death=C.n.all.death+C.u.all.death+C.t.all.death
     dAux.A.all.death=A.n.all.death+A.u.all.death+A.t.all.death

    #auxilliary variables to track numbers diagnosed by passive case-finding
    dAux.diag.C= detect.C.n * (Ihs.C.n + Ihr.C.n) +  detect.C.u * (Ihs.C.u + Ihr.C.u) +  detect.C.t * (Ihs.C.t + Ihr.C.t) 
    dAux.diag.A= detect.A.n * (Ihs.A.n + Ihr.A.n) +  detect.A.u * (Ihs.A.u + Ihr.A.u) +  detect.A.t * (Ihs.A.t + Ihr.A.t) 

    #auxilliary variable for screening through ACF tracking
    dAux.ACF.C=0; #only changed inside the ACF function
    dAux.ACF.A=0;
                                            
    #auxilliary variable for ART starts - independent of TB status
    dAux.ART.inc.C = birthrate*hiv.birth.frac*hiv.treat.frac
    dAux.ART.inc.A = hiv.treat.rate * (Su.A.u + Sp.A.u + Lus.A.u + Lur.A.u + Lps.A.u + Lpr.A.u + Ihs.A.u + Ihr.A.u + Igds.A.u + Igdr.A.u + Ibds.A.u + Ibdr.A.u)
    #auxilliary variable for ART starts in TBd, HIV+ adults - needed to compute TB_diagnoses_IPT value
    dAux.ART.TBd.inc.A = hiv.treat.rate * ( Ihs.A.u + Ihr.A.u + Igds.A.u + Igdr.A.u + Ibds.A.u + Ibdr.A.u)

                                                                                                                                                               
    #auxilliary variables        for new IPT in HIV neg LTBI
    #auxilliary variables for number IPT screened in nHIV  LTBI
    Aux.IPT.nHIV.C = prophy.Lus.C.n * Lus.C.n + prophy.Lur.C.n * Lur.C.n
    Aux.IPT.nHIV.A = prophy.Lus.A.n * Lus.A.n + prophy.Lur.A.n * Lur.A.n

    
    #auxilliary variables for number IPT screened in HIV positive LTBI or susceptible
    Aux.IPT.HIV.C = prophy.Lus.C.u * Lus.C.u + prophy.Lur.C.u * Lur.C.u + prophy.Lus.C.t * Lus.C.t + prophy.Lur.C.t * Lur.C.t + prophy.S.C.t * Su.C.t
    Aux.IPT.HIV.A = prophy.Lus.A.u * Lus.A.u + prophy.Lur.A.u * Lur.A.u + prophy.Lus.A.t * Lus.A.t + prophy.Lur.A.t * Lur.A.t + prophy.S.A.t * Su.A.t

    #all variables, those describing the dynamics and all kinds of auxilliary variables are combined
    dAll=c(dC.n,dC.u,dC.t,dA.n,dA.u,dA.t,dAux.C.inc,dAux.C.death,dAux.A.inc,dAux.A.death,dtx.all,dnewInf.C,dnewInf.A,dAux.recent.TB.inc.C,dAux.recent.TB.inc.A,dAux.C.all.death,dAux.A.all.death,dAux.diag.C,dAux.diag.A,dAux.ACF.C,dAux.ACF.A,dAux.ART.inc.C,dAux.ART.inc.A,Aux.IPT.nHIV.C,Aux.IPT.nHIV.A,Aux.IPT.HIV.C,Aux.IPT.HIV.A,0,0,dAux.ART.TBd.inc.A)

    list(dAll) #return object as list
    
    }) #close with statement

} 
###################################################################
#end function specifying the ODEs
###################################################################


###################################################################  
#function specifying events that happen during ODE integration, 
#namely ACF reducing undetected cases
###################################################################
eventfun <- function(t, y, p)
{
   #compute time-varying ART treatment parameter
    hiv.treat.rate=0; #no ART until 2004
    hiv.treat.frac=0; #for children
    y.ind=floor(t-2004);
    if (y.ind>0 & y.ind<=length(hiv.treat.rate.vec)) {hiv.treat.rate=HIV.treat.switch*hiv.treat.rate.vec[y.ind]; hiv.treat.frac=HIV.treat.switch*art.level[y.ind]/100;  } #ramp-up from 2005 to 2025
    if (y.ind>length(hiv.treat.rate.vec)) {hiv.treat.rate=HIV.treat.switch*hiv.treat.rate.vec[length(hiv.treat.rate.vec)]; hiv.treat.frac=HIV.treat.switch*0.77; } #if we want to run simulation beyond 2025

    frac.good.detect.C.n = frac.good.detect.C.n.base
    frac.good.detect.C.u = frac.good.detect.C.u.base
    frac.good.detect.C.t = frac.good.detect.C.t.base
    frac.good.detect.A.n = frac.good.detect.A.n.base
    frac.good.detect.A.u = frac.good.detect.A.u.base
    frac.good.detect.A.t = frac.good.detect.A.t.base
    frac.undetected = 0.05;
    

#altering parameters based on intervention to be modeled - need to redo here so i can compute duration of infection
    if (t >= 2016) # year when interventions start
    {

        if (int.nr==11 | int.nr==1 | int.nr==7) #called 1a in the document - part of intervention 1, increase proportion of population with access to health care
        {
            #this is modeled as decreasing the fraction of individuals who die prior to being caught by any health system
            #the decrease is modeled by changing the detection rate 
            #starts out at 5%, reduces to 0% 
            if (level.nr<5) 
            {
                t.start=2016; t.end=2021+1; s.start=0.05;  
                frac.undetected = s.start - s.start * level.nr /4 *  min(1,max(0,(t-t.start)/(t.end-t.start)))
            } #end time and end strength of intervention - scaled with level.nr to get 25/50/75/100%
            if (level.nr==5) 
            {
                t.start=2016; t.end=2020+1; s.start=0.05; 
                frac.undetected = s.start - s.start *  min(1,max(0,(t-t.start)/(t.end-t.start)))
            } #advocate choice - should end end of year, therefore the +1

        } #end intervention 1a (also used in 1 and 7)

      if (int.nr==12 | int.nr==1 | int.nr==7) #called 1b in the document - part of intervention 1, increase proportion of TB cases accessing high quality TB services
      {
            #Intervention 1: increased access to DOTS, modeled as increased fraction of hosts being moved into the good quality care setting
            #the assumption is that the good quality care setting leads to faster increase in detection rates,
            if (level.nr<5) {t.start=2016; t.end=2021+1; s.end=(1-0.2)*(level.nr/4); } #end time and end strength of intervention - scaled with level.nr to get 25/50/75/100%
            if (level.nr==5) {t.start=2016; t.end=2020+1; s.end=1-0.2; } #advocate choice - should end end of year, therefore the +1

            frac.good.detect.A.n = 0.2 + pmin(s.end, pmax(0, s.end / (t.end-t.start) * (t-t.start)));  #TB-MAC baseline of 20% accessing good care, should go to 100% by 2021 per country expert
            frac.good.detect.A.u = frac.good.detect.A.n
            frac.good.detect.A.t = frac.good.detect.A.n
            frac.good.detect.C.n = frac.good.detect.A.n
            frac.good.detect.C.u = frac.good.detect.A.u
            frac.good.detect.C.t = frac.good.detect.A.t

     } #end 1b, 1, 7


    } #finish the loop that recomputes rates


        detect.C.n.new = detect.C.n.base ;
        detect.C.u.new = detect.C.u.base ;
        detect.C.t.new = detect.C.t.base ;
        detect.A.n.new = detect.A.n.base ;
        detect.A.u.new = detect.A.u.base ;
        detect.A.t.new = detect.A.t.base ;

        #compute detect rates - this is combination of doing 1a and then 1b on top
        detect.C.n = detect.C.n.new * frac.good.detect.C.n + detect.C.n.new * bad.detect.factor * (1 - frac.good.detect.C.n)
        detect.C.u = detect.C.u.new * frac.good.detect.C.u + detect.C.u.new * bad.detect.factor * (1 - frac.good.detect.C.u)
        detect.C.t = detect.C.t.new * frac.good.detect.C.t + detect.C.t.new * bad.detect.factor * (1 - frac.good.detect.C.t)

        detect.A.n = detect.A.n.new * frac.good.detect.A.n + detect.A.n.new * bad.detect.factor * (1 - frac.good.detect.A.n)
        detect.A.u = detect.A.u.new * frac.good.detect.A.u + detect.A.u.new * bad.detect.factor * (1 - frac.good.detect.A.u)
        detect.A.t = detect.A.t.new * frac.good.detect.A.t + detect.A.t.new * bad.detect.factor * (1 - frac.good.detect.A.t)



 #allows addressing of variables and parameters directly by name.
    #parameters are currently defined globally, so not in p
   
    
dur.children = (y['Ihs.C.n'] / (detect.C.n + growup + deathrate + tb.C.n.deathrate) + y['Ihr.C.n'] / (detect.C.n + growup + deathrate + mdr.C.n.deathrate ) + y['Ibds.C.n'] / (growup + deathrate + tb.C.n.deathrate + tx.Ibds.C.n ) + y['Igds.C.n'] / (growup + deathrate + tb.C.n.deathrate + tx.Igds.C.n )  + y['Ibdr.C.n'] / (growup + deathrate + mdr.C.n.deathrate + tx.Ibdr.C.n )  + y['Igdr.C.n'] / (growup + deathrate + mdr.C.n.deathrate + tx.Igdr.C.n)  + y['Ihs.C.u'] / (detect.C.u + growup + deathrate + tb.C.u.deathrate + hiv.C.u.deathrate) + y['Ihr.C.u'] / (detect.C.u + growup + deathrate + mdr.C.u.deathrate + hiv.C.u.deathrate) + y['Ibds.C.u'] / (growup + deathrate + tb.C.u.deathrate + tx.Ibds.C.u + hiv.C.u.deathrate) + y['Igds.C.u'] / (growup + deathrate + tb.C.u.deathrate + tx.Igds.C.u + hiv.C.u.deathrate)  + y['Ibdr.C.u'] / (growup + deathrate + mdr.C.u.deathrate + tx.Ibdr.C.u + hiv.C.u.deathrate)  + y['Igdr.C.u'] / (growup + deathrate + mdr.C.u.deathrate + tx.Igdr.C.u + hiv.C.u.deathrate)  +   y['Ihs.C.t'] / (detect.C.t + growup + deathrate + tb.C.t.deathrate + hiv.C.t.deathrate) + y['Ihr.C.t']  / (detect.C.t + growup + deathrate + mdr.C.t.deathrate + hiv.C.t.deathrate) + y['Ibds.C.t'] / (growup + deathrate + tb.C.t.deathrate + tx.Ibds.C.t + hiv.C.t.deathrate) +  y['Igds.C.t'] / (growup + deathrate + tb.C.t.deathrate + tx.Igds.C.t + hiv.C.t.deathrate)  + y['Ibdr.C.t'] / (growup + deathrate + mdr.C.t.deathrate + tx.Ibdr.C.t + hiv.C.t.deathrate)  + y['Igdr.C.t'] / (growup + deathrate + mdr.C.t.deathrate + tx.Igdr.C.t + hiv.C.t.deathrate) ) / sum(y[c(7:12,19:24,31:36)])

    dur.adult = (y['Ihs.A.n'] / (detect.A.n + hiv.infect.rate + deathrate + tb.A.n.deathrate) + y['Ihr.A.n'] / (detect.A.n + hiv.infect.rate + deathrate + mdr.A.n.deathrate) + y['Ibds.A.n'] / (hiv.infect.rate + deathrate + tb.A.n.deathrate + tx.Ibds.A.n) + y['Igds.A.n'] / (hiv.infect.rate + deathrate + tb.A.n.deathrate + tx.Igds.A.n) + y['Ibdr.A.n'] / (hiv.infect.rate + deathrate + mdr.A.n.deathrate + tx.Ibdr.A.n) + y['Igdr.A.n'] / (hiv.infect.rate + deathrate + mdr.A.n.deathrate + tx.Igdr.A.n) + y['Ihs.A.u'] / (detect.A.u + hiv.treat.rate + deathrate + hiv.A.u.deathrate + tb.A.u.deathrate)  + y['Ihr.A.u'] / (detect.A.u + hiv.treat.rate + deathrate + hiv.A.u.deathrate + mdr.A.u.deathrate) + y['Ibds.A.u'] / (hiv.treat.rate + deathrate + hiv.A.u.deathrate + tb.A.u.deathrate + tx.Ibds.A.u)  + y['Igds.A.u'] / (hiv.treat.rate + deathrate + hiv.A.u.deathrate + tb.A.u.deathrate + tx.Igds.A.u) + y['Ibdr.A.u'] / (hiv.treat.rate + deathrate + hiv.A.u.deathrate + mdr.A.u.deathrate + tx.Ibdr.A.u) + y['Igdr.A.u'] / (hiv.treat.rate + deathrate + hiv.A.u.deathrate + mdr.A.u.deathrate + tx.Igdr.A.u) + y['Ihs.A.t'] / (detect.A.t + deathrate + hiv.A.t.deathrate + tb.A.t.deathrate) + y['Ihr.A.t'] / (detect.A.t + deathrate + hiv.A.t.deathrate + mdr.A.t.deathrate) + y['Ibds.A.t'] / ( deathrate + hiv.A.t.deathrate + tb.A.t.deathrate + tx.Ibds.A.t) + y['Igds.A.t'] / ( deathrate + hiv.A.t.deathrate + tb.A.t.deathrate + tx.Igds.A.t) + y['Ibdr.A.t'] / ( deathrate + hiv.A.t.deathrate + mdr.A.t.deathrate + tx.Ibdr.A.t) +  y['Igdr.A.t'] / ( deathrate + hiv.A.t.deathrate + mdr.A.t.deathrate + tx.Igdr.A.t) ) / sum(y[c(7:12,19:24,31:36)+36])

    #event function to keep track of duration of infectious period for every run
    y['dur.adult']= dur.adult
    y['dur.children']= dur.children

    doit=0;
  
    if (int.nr==4 | int.nr==5 | int.nr==7)    
    {
    #country expert says no ACF
    #advocate says 50% coverage at roughly 90% sensitivity bi-annually
    #starts in 2015, scale-up to 2020, stop in 2025
    alpha.base=0;
    t.start=2016; t.full=2020; t.end=2025;
    if (level.nr==5 & t>=t.start & t<=t.end) {alpha.base=(0.5*0.9-0.0) *  min(1, max(0, (t-t.start) / (t.full-t.start)));    doit=1; } #advocate choice 

    #base is how much per year, this is divided into small chuncks to approximate continuous
    alpha=alpha.base*time.step*2; #factor of 2 since advocate suggests 50% bi-annually 

    if (doit==1) #ACF only - done for int 4,5, and 7
    {
    
    #move a fraction of hosts from undetected to detected
    #assuming that everyone detected by ACF moves into the good quality care category
    y['Igds.C.n'] = y['Igds.C.n'] + alpha * y['Ihs.C.n']; y['Ihs.C.n'] = y['Ihs.C.n'] - alpha * y['Ihs.C.n'];   
    y['Igds.C.u'] = y['Igds.C.u'] + alpha * y['Ihs.C.u']; y['Ihs.C.u'] = y['Ihs.C.u'] - alpha * y['Ihs.C.u'];   
    y['Igds.C.t'] = y['Igds.C.t'] + alpha * y['Ihs.C.t']; y['Ihs.C.t'] = y['Ihs.C.t'] - alpha * y['Ihs.C.t'];   
    
    y['Igdr.C.n'] = y['Igdr.C.n'] + alpha * y['Ihr.C.n']; y['Ihr.C.n'] = y['Ihr.C.n'] - alpha * y['Ihr.C.n'];   
    y['Igdr.C.u'] = y['Igdr.C.u'] + alpha * y['Ihr.C.u']; y['Ihr.C.u'] = y['Ihr.C.u'] - alpha * y['Ihr.C.u'];   
    y['Igdr.C.t'] = y['Igdr.C.t'] + alpha * y['Ihr.C.t']; y['Ihr.C.t'] = y['Ihr.C.t'] - alpha * y['Ihr.C.t'];   
    
    y['Igds.A.n'] = y['Igds.A.n'] + alpha * y['Ihs.A.n']; y['Ihs.A.n'] = y['Ihs.A.n'] - alpha * y['Ihs.A.n'];   
    y['Igds.A.u'] = y['Igds.A.u'] + alpha * y['Ihs.A.u']; y['Ihs.A.u'] = y['Ihs.A.u'] - alpha * y['Ihs.A.u'];   
    y['Igds.A.t'] = y['Igds.A.t'] + alpha * y['Ihs.A.t']; y['Ihs.A.t'] = y['Ihs.A.t'] - alpha * y['Ihs.A.t'];   
    
    y['Igdr.A.n'] = y['Igdr.A.n'] + alpha * y['Ihr.A.n']; y['Ihr.A.n'] = y['Ihr.A.n'] - alpha * y['Ihr.A.n'];   
    y['Igdr.A.u'] = y['Igdr.A.u'] + alpha * y['Ihr.A.u']; y['Ihr.A.u'] = y['Ihr.A.u'] - alpha * y['Ihr.A.u'];   
    y['Igdr.A.t'] = y['Igdr.A.t'] + alpha * y['Ihr.A.t']; y['Ihr.A.t'] = y['Ihr.A.t'] - alpha * y['Ihr.A.t'];   

    y['Aux.ACF.A']=y['Aux.ACF.A'] + alpha * (y['Ihs.A.n']+y['Ihs.A.u']+y['Ihs.A.t']+y['Ihr.A.n']+y['Ihr.A.u']+y['Ihr.A.t']) #auxilliary variables to keep track of total ACF
    y['Aux.ACF.C']=y['Aux.ACF.C'] + alpha * (y['Ihs.C.n']+y['Ihs.C.u']+y['Ihs.C.t']+y['Ihr.C.n']+y['Ihr.C.u']+y['Ihr.C.t'])
    }

    if (doit==1 & (int.nr==5 | int.nr==7)) #ACF and IPT for latent, done for int. 5 and 7
    {
    #move a fraction of latent TB (80% of ACF screened) to IPT compartments
    #exclude individuals on ART
    #effect of IPT is specified in the main script
    # 80% of screened are diagnosed, 82% of those finish IPT, IPT is effective in 80% of those
    alp2 = 0.8*0.82*0.8*alpha * min(1, max(0, (t-t.start) / (t.full-t.start))) #last part is scale-up
    y['Lus.C.n'] = y['Lus.C.n'] - alp2 * y['Lus.C.n']; y['Lps.C.n'] = y['Lps.C.n'] + alp2 * y['Lus.C.n'];   
    y['Lus.C.u'] = y['Lus.C.u'] - alp2 * y['Lus.C.u']; y['Lps.C.u'] = y['Lps.C.u'] + alp2 * y['Lus.C.u'];   
    y['Lur.C.n'] = y['Lur.C.n'] - alp2 * y['Lur.C.n']; y['Lpr.C.n'] = y['Lpr.C.n'] + alp2 * y['Lur.C.n'];   
    y['Lur.C.u'] = y['Lur.C.u'] - alp2 * y['Lur.C.u']; y['Lpr.C.u'] = y['Lpr.C.u'] + alp2 * y['Lur.C.u'];   
  
    y['Lus.A.n'] = y['Lus.A.n'] - alp2 * y['Lus.A.n']; y['Lps.A.n'] = y['Lps.A.n'] + alp2 * y['Lus.A.n'];   
    y['Lus.A.u'] = y['Lus.A.u'] - alp2 * y['Lus.A.u']; y['Lps.A.u'] = y['Lps.A.u'] + alp2 * y['Lus.A.u'];   
    y['Lur.A.n'] = y['Lur.A.n'] - alp2 * y['Lur.A.n']; y['Lpr.A.n'] = y['Lpr.A.n'] + alp2 * y['Lur.A.n'];   
    y['Lur.A.u'] = y['Lur.A.u'] - alp2 * y['Lur.A.u']; y['Lpr.A.u'] = y['Lpr.A.u'] + alp2 * y['Lur.A.u'];   
    }   

    } #close statements for interventions 4,5, and 7


    #browser()
   
    return(y)
}    



###################################################################
#finished with the functions
###################################################################


###################################################################
###################################################################
#main program
###################################################################
###################################################################

ploton=1;

tols=1e-8; startyear=1500;

time.step=0.1;
endyear=2036; #go a year further than required to compute annual incidence for last year
timevec=c(seq(startyear,1990,by=10),seq(1991,endyear,by=time.step)); #this creates a vector of times for which integration is evaluated (from 0 to 1000 years in steps of 0.1)
HIV.switch=1; #turns off HIV, both as births in children and new infections in adults
HIV.death.switch=1; #turn excess death on or off
HIV.treat.switch=1;
TB.switch=1; #turns off all TB
TB.death.switch=1; #turn excess death on or off
MDR.switch=1; #turns off MDR
Adult.switch=1; #turns adults on and off by preventing growing up

###########################
#starting main simulation loops
#need to define parameters inside loop since they need to be re-initialized for each run, otherwise they would change values
###########################

#intervention type. 0 is baseline, skipping intervention 3 which is ACF, 8-10 are called 2a,b,c in the TM-MAC documents, 11-12 are called 1a and 1b in TB-MAC documents
intvec=c(0,11,12,1,8:10,2,4:7);
#intvec=c(10,2);

epi.res.all=NULL; #initiate data frames that will contain all results
daly1.all=NULL;                 
daly2.all=NULL
daly3.all=NULL
econ.res.all=NULL


for (int.nr in intvec) #loop over different interventions, 0 is no intervention (i.e. baseline)
  {  
    
   plot.years=seq(2000,2035,by=time.step);
   if (int.nr==0) {int.levels=1; reportyears=2000:endyear;} #only 1 level for baseline
   
   if (int.nr>0) {int.levels=1:5; reportyears=2016:endyear;} # 4 country expert levels and 1 advocate level for all interventions

   if (int.nr== 4 | int.nr==5 ) {int.levels=5; reportyears=2016:endyear;} # only advocate level for interventions 4 and 5

   intervention.names=c('0','1','2','3','4','5','6','7','2a','2b','2c','1a','1b')
   scenario.names=c('cty_25','cty_50','cty_75','cty_100','adv')
   if (int.nr==0) {scenario.names=c('base_case');}
  
     
   for (level.nr in int.levels) #outer loop - every intervention is done 5 times, at 25/50/75/100% country expert and for advocate value
   {  

     
     print(sprintf('starting intervention %s at level %s',intervention.names[int.nr+1],scenario.names[level.nr])); 
     

      ###################################################################
      #parameters for model
      #all rates are in units of 1/year
      ###################################################################
      
      #labeling is as follows:
      #first set of letters are with regard to TB and healthcare status:
      #susceptible unprotected (Su), susceptible protected (Sp) - protection is vaccine or IPT or similar
      #latent drug sensitive unprotected/protected (Lus, Lps), latent unprotected/protected MDR (Lur, Lpr)
      #diseased, undiagnosed (hidden), drug sensitive/MDR (Ihs, Ihr)
      #diseased diagnosed, in bad quality healthcare system - drug sensitive (Ibds), diseased MDR (Ibdr)
      #diseased diagnosed, in good quality healthcare system - drug sensitive (Igds), diseased MDR (Igdr)
      #s = TB drug sensitive (nonMDR), r = TB drug resistant (MDR)
      #h = hidden (not yet observed/detected/reported) TB, d = detected/reported TB
      #g = good quality treatment, b = bad quality treatment
      
      #2nd letter is A for adult, C for child
      #3rd letter is for HIV status, no HIV (n), HIV untreated (u), HIV treated (t)
      
      #12 TB compartments x 2 age compartments x 3 HIV compartments = 72 compartments
      
      
      ###################################################################
      #demographic parameters
      #birth, death and maturation rates
      #includes disease-specific excess death rates
      ###################################################################
      Pop.size=52386000; #population size of RSA - Worldbank/ TB-MAC 
      Adult.size=0.71*Pop.size; #fraction of adults in RSA - TB-MAC
      Children.size=0.29*Pop.size;  #fraction of children in RSA - TB-MAC

      birthrate=23.3/1000 * Pop.size;   #annual births per year (crude birth rate) 22/1000 from Worldbank  (18.94/1000 from CIA)
      hiv.birth.frac=HIV.switch * 0.06;  #fraction of children born with HIV (3% HIV prevalence among children according to UNAIDS, so need to up this rate a bit)
      hiv.treat.frac=0.0;   #fraction of children with HIV on ART - starts at 0, will be dialed up together with adult treatment inside ODE
      growup=Adult.switch*1/15;        #rate at which children convert to adults - average duration of childhood 15 years
      deathrate=1/100;   #lifespan in years (excluding deaths due to TB and HIV, therefore should be higher than overall population lifespan)
      #deathrate=1/45.5;   #for the given birth rate and population size, without excess death lifespan should be 45.5 years to stay at equilibrium
      
      #excess death rates due to HIV - assumed to be indepedent of TB status (but TB mortality is influenced by HIV status)
      hiv.A.u.deathrate=HIV.death.switch * 1/10; #lifespan for untreated HIV, adults  (10 y for Uganda model), 10y Bacaer SA, 0.11 Dowdy 2008
      hiv.A.t.deathrate=HIV.death.switch * 1/20; #lifespan for treated HIV, adults (20 y for Uganda model)
      hiv.C.u.deathrate=HIV.death.switch * 1/10; #lifespan for untreated HIV, children
      hiv.C.t.deathrate=HIV.death.switch * 1/20; #
      
      #excess death rates due to TB disease - depends on HIV and MDR status
      #death rates for adults
      tb.A.n.deathrate=TB.death.switch * 1/8; # 1/lifespan without HIV and no MDR  - (1/3 for Uganda model, 1/4 Bacaer SA, 0.17 in Dowdy 2008 PNAS)
      tb.A.u.deathrate=TB.death.switch * 2/4; # 1/y lifespan with untreated HIV  - (4/3 for Uganda model, 1.6 Bacaer SA, , 0.82 in Dowdy 2008 PNAS)
      tb.A.t.deathrate= (tb.A.n.deathrate+tb.A.u.deathrate)/2; #lifespan with treated HIV - same as nHIV in Uganda model
      #tb.A.t.deathrate= tb.A.n.deathrate; #lifespan with treated HIV - same as nHIV in Uganda model
      mdr.A.n.deathrate=tb.A.n.deathrate; #death rate for MDR
      mdr.A.u.deathrate=tb.A.u.deathrate; #death rate for MDR
      mdr.A.t.deathrate=tb.A.t.deathrate; #death rate for MDR
      
      #excess death rates for children due to TB disease
      child.reduction=1; #Newton 08 Lancet ID states higher risk of death, but unclear in general so assume the same
      tb.C.n.deathrate=child.reduction*tb.A.n.deathrate
      tb.C.u.deathrate=child.reduction*tb.A.u.deathrate
      tb.C.t.deathrate=child.reduction*tb.A.t.deathrate
      mdr.C.n.deathrate=child.reduction*mdr.A.n.deathrate
      mdr.C.u.deathrate=child.reduction*mdr.A.u.deathrate
      mdr.C.t.deathrate=child.reduction*mdr.A.t.deathrate
      
      
      ###################################################################
      #TB transmission parameters
      ###################################################################
      #levels of infectiousness for hosts with disease in different categories
      #transmission is implemented as frequency/prevalence dependent, i.e. force of infection scales with #inf/total pop.
      
      mdr.red=0.8; #reduction of transmission for MDR compared to nMDR - Morcillo 2014
      hiv.red=0.7; #reduction of transmission for HIV+  nART comparted to nHIV (0.8 for Uganda model, 0.3 in Dowdy 2008, 0.66 in Bacaer 08)
      art.red=0.9; #reduction of transmission of HIV+ on ART compared to nonHIV
      kids.trans.red=0.4; #children are assumed to be less infectious - Curtis 1999 NEJM and references therein
      
      #adults, no HIV, hidden/diagnosed and noMDR/MDR 
      b.hs.A.n=10   #hidden, nMDR  #15 in Uganda model, 8 in Dowdy 2008, 11.4 in Bacaer 08
      b.hr.A.n=MDR.switch*mdr.red*b.hs.A.n #hidden, MDR  #assuming MDR TB is less transmissible
      b.bds.A.n=b.hs.A.n #detected by bad care, nMDR  #diagnosis makes no difference to transmissibilty
      b.bdr.A.n=MDR.switch*mdr.red*b.hs.A.n #detected by good care, MDR 
      b.gds.A.n=b.hs.A.n #detected by good care, nMDR
      b.gdr.A.n=MDR.switch*mdr.red*b.hs.A.n #detected by good care, MDR 
      
      #adults, with HIV non-treated, hidden/diagnosed and noMDR/MDR 
      b.hs.A.u=hiv.red * b.hs.A.n #HIV infected are less infectious
      b.hr.A.u=hiv.red * b.hr.A.n 
      b.bds.A.u=hiv.red * b.bds.A.n 
      b.bdr.A.u=hiv.red * b.bdr.A.n  
      b.gds.A.u=hiv.red * b.gds.A.n 
      b.gdr.A.u=hiv.red * b.gdr.A.n 
      
      #adults, with HIV treated, hidden/diagnosed and noMDR/MDR 
      b.hs.A.t=art.red * b.hs.A.n #HIV infected on ART are as transmissible as HIV+ (i.e. reduced)
      b.hr.A.t=art.red * b.hr.A.n  #hidden, MDR
      b.bds.A.t=art.red * b.bds.A.n #detected by bad care, nMDR
      b.bdr.A.t=art.red * b.bdr.A.n #detected by good care, MDR 
      b.gds.A.t=art.red * b.gds.A.n #detected by bad care, nMDR
      b.gdr.A.t=art.red * b.bdr.A.n #detected by good care, MDR 
      
      #children, no HIV, undiagnosed/diagnosed and noMDR/MDR 
      b.hs.C.n=kids.trans.red * b.hs.A.n   #children have reduced infectiousness compared to adults
      b.hr.C.n=kids.trans.red * b.hr.A.n  
      b.bds.C.n=kids.trans.red * b.bds.A.n  
      b.bdr.C.n=kids.trans.red * b.bdr.A.n 
      b.gds.C.n=kids.trans.red * b.gds.A.n
      b.gdr.C.n=kids.trans.red * b.gdr.A.n
      
      #children, with HIV non-treated, hidden/diagnosed and noMDR/MDR 
      b.hs.C.u=kids.trans.red * b.hs.A.u   #children have reduced infectiousness compared to adults
      b.hr.C.u=kids.trans.red * b.hr.A.u  
      b.bds.C.u=kids.trans.red * b.bds.A.u  
      b.bdr.C.u=kids.trans.red * b.bdr.A.u 
      b.gds.C.u=kids.trans.red * b.gds.A.u
      b.gdr.C.u=kids.trans.red * b.gdr.A.u
      
      #children, with HIV treated, hidden/diagnosed and noMDR/MDR 
      b.hs.C.t=kids.trans.red * b.hs.A.t   #children have reduced infectiousness compared to adults
      b.hr.C.t=kids.trans.red * b.hr.A.t  
      b.bds.C.t=kids.trans.red * b.bds.A.t  
      b.bdr.C.t=kids.trans.red * b.bdr.A.t 
      b.gds.C.t=kids.trans.red * b.gds.A.t
      b.gdr.C.t=kids.trans.red * b.gdr.A.t
                                                      
      ###################################################################
      #probability of TB infection for each type of host
      ###################################################################
      #depends on age group and HIV status
      #Keep at 1 for now, need to re-check
      pi.Su.A.n=1
      pi.Sp.A.n=1
      pi.Su.A.u=1
      pi.Sp.A.u=1
      pi.Su.A.t=1
      pi.Sp.A.t=1
      
      pi.Su.C.n=1
      pi.Sp.C.n=1
      pi.Su.C.u=1
      pi.Sp.C.u=1
      pi.Su.C.t=1
      pi.Sp.C.t=1
      
      
      ###################################################################
      #rate of slow progression to disease
      #unit of 1/year
      ###################################################################
      #depends on age group, HIV status and MDR/noMDR infection
        
      prog.prot.red.noART=0; #reduction of progression due to IPT - TB-MAC estimate, assumed that progression only occurs through reinfection
      prog.prot.red.ART= 0.65 #reduction by 35%

      prog.mdr.red=1; #MDR progression rate relative to nMDR  
      
      prog.Lus.A.n = 0.0005 #0.001 for Uganda model, 0.0003 Bacaer 2008, 0.001 in Dowdy 2008
      prog.Lur.A.n = prog.mdr.red * prog.Lus.A.n #MDR has slower progression
      prog.Lps.A.n = prog.prot.red.noART * prog.Lus.A.n #protection reduces slow progression
      prog.Lpr.A.n = prog.Lur.A.n  #protection (IPT) assumed to not work for MDR
      prog.Lus.A.u = 0.05 #HIV+ 0.08 = Bacaer 2008, 0.034 Uganda, 0.04 in Dowdy 2008
      prog.Lur.A.u = prog.mdr.red * prog.Lus.A.u #MDR has slower progression
      prog.Lps.A.u = prog.prot.red.noART * prog.Lus.A.u #protection reduces slow progression
      prog.Lpr.A.u = prog.Lur.A.u
      prog.Lus.A.t = 25 * prog.Lus.A.n # between nHIV and HIV nART
      #prog.Lus.A.t = (prog.Lus.A.n + prog.Lus.A.u) / 2 # between nHIV and HIV nART 
      prog.Lur.A.t = prog.mdr.red * prog.Lus.A.t
      prog.Lps.A.t = prog.prot.red.ART * prog.Lus.A.t
      prog.Lpr.A.t = prog.Lur.A.t
      
      #no data for kids, assume same as for adults
      prog.Lus.C.n = prog.Lus.A.n
      prog.Lur.C.n = prog.Lur.A.n
      prog.Lps.C.n = prog.Lps.A.n
      prog.Lpr.C.n = prog.Lpr.A.n
      prog.Lus.C.u = prog.Lus.A.u
      prog.Lur.C.u = prog.Lur.A.u
      prog.Lps.C.u = prog.Lps.A.u
      prog.Lpr.C.u = prog.Lpr.A.u
      prog.Lus.C.t = prog.Lus.A.t
      prog.Lur.C.t = prog.Lur.A.t
      prog.Lps.C.t = prog.Lps.A.t
      prog.Lpr.C.t = prog.Lpr.A.t
                           
      
      ###################################################################
      #fraction of hosts that "immediately" (fast progression) develop disease
      ###################################################################
      #depends on age group, HIV status and MDR/noMDR
      
      ff.mdr.red=1; #reduction for MDR
      
      ff.prot.red.noART=0; #factor implementing reduction of fast progression due to IPT (no fast progression assumed for IPT intervention #5)
      ff.prot.red.ART= 0.65; #factor implementing reduction of fast progression due to IPT (35% overall effect assumed for IPT intervention #6)
      
      ff.Lus.A.n = 0.05 #0.053 Uganda model, 0.11 Bacaer 2008, Dowdy 2013 has 0.08-0.2, 0.14 in Dowdy 2008
      ff.Lur.A.n = ff.mdr.red * ff.Lus.A.n #MDR  progression
      ff.Lps.A.n = ff.prot.red.noART * ff.Lus.A.n #protection reduces slow progression
      ff.Lpr.A.n = ff.Lur.A.n #protection (IPT) assumed to not work for MDR
      ff.Lus.A.u = 0.2  #0.186 Uganda model, 0.3 Bacaer 2008, Dowdy 2013 has 0.2 - 1, 0.22 in Dowdy 2008
      ff.Lur.A.u = ff.mdr.red * ff.Lus.A.u #MDR  progression
      ff.Lps.A.u = ff.prot.red.noART * ff.Lus.A.u #protection reduces slow progression
      ff.Lpr.A.u = ff.Lur.A.u
      #ff.Lus.A.t = ff.art.red * ff.Lus.A.n #same as no-HIV values
      ff.Lus.A.t = ( ff.Lus.A.n + ff.Lus.A.u)/2 #same as no-HIV values
      ff.Lur.A.t = ff.mdr.red * ff.Lus.A.t
      ff.Lps.A.t = ff.prot.red.ART * ff.Lus.A.t
      ff.Lpr.A.t = ff.Lur.A.t
      
      #no real data for kids
      #assume some reduction in fast progression
      ff.kid.red=1;
      
      ff.Lus.C.n = ff.kid.red * ff.Lus.A.n
      ff.Lur.C.n = ff.kid.red * ff.Lur.A.n
      ff.Lps.C.n = ff.kid.red * ff.Lps.A.n
      ff.Lpr.C.n = ff.kid.red * ff.Lpr.A.n
      ff.Lus.C.u = ff.kid.red * ff.Lus.A.u
      ff.Lur.C.u = ff.kid.red * ff.Lur.A.u
      ff.Lps.C.u = ff.kid.red * ff.Lps.A.u
      ff.Lpr.C.u = ff.kid.red * ff.Lpr.A.u
      ff.Lus.C.t = ff.kid.red * ff.Lus.A.t
      ff.Lur.C.t = ff.kid.red * ff.Lur.A.t
      ff.Lps.C.t = ff.kid.red * ff.Lps.A.t
      ff.Lpr.C.t = ff.kid.red * ff.Lpr.A.t    
      
      ###################################################################
      #reduction of susceptibility toward fast progression upon re-infection
      ###################################################################
      #depends on age group, HIV status and MDR/noMDR
      #since MDR is relatively rare and to keep things a bit simpler, we do not consider re-infection for MDR
      
      re.prot.red.noART=1; #reduction of reinfection risk due to protection (e.g. IPT) - assumed no effect for reinfection, only works on progression
      re.prot.red.ART=0.65; 
      
      re.Lus.A.n = 0.5   #0.5 for Uganda model, 0.7 Bacaer SA
      re.Lps.A.n = re.prot.red.noART * re.Lus.A.n
      re.Lur.A.n = 0 #no reinfection for MDR
      re.Lpr.A.n = re.Lur.A.n #IPT assumed to not work for MDR
      
      re.Lus.A.u = 0.7     #0.75 HIV+ Uganda model
      re.Lps.A.u = re.prot.red.noART * re.Lus.A.u
      re.Lur.A.u = 0
      re.Lpr.A.u = re.Lur.A.u
      
      re.Lus.A.t = re.Lus.A.n #same as no HIV
      re.Lps.A.t = re.prot.red.ART * re.Lus.A.t
      re.Lur.A.t = 0
      re.Lpr.A.t = re.Lur.A.t
      
      #no data on children, assume same as adults
      re.Lus.C.n = re.Lus.A.n
      re.Lps.C.n = re.Lps.A.n
      re.Lur.C.n = re.Lur.A.n
      re.Lpr.C.n = re.Lpr.A.n
      
      re.Lus.C.u = re.Lus.A.u
      re.Lps.C.u = re.Lps.A.u
      re.Lur.C.u = re.Lur.A.u
      re.Lpr.C.u = re.Lpr.A.u
      
      re.Lus.C.t = re.Lus.A.t
      re.Lps.C.t = re.Lps.A.t
      re.Lur.C.t = re.Lur.A.t
      re.Lpr.C.t = re.Lpr.A.t
      
                     
      ###################################################################
      #HIV parameters
      ###################################################################
      
      #annual rate of aquiring HIV - transmission is not modeled
      #is assumed to be zero for <15 and the same for all adults, independent of TB status
      hiv.infect.rate=HIV.switch*0.021   #annual rate of getting infected with HIV
      #hiv.treat.rate=0.003   #annual rate of receiving ART
      art.year=c(2004:2025) #no ART before 2004
      art.level=c(1,	2,	4,	6,	7,	8,	13,	23,	35,	42,	55,	61,	67,	69,	70,	71,	72,	73,	74,	75,	76,	77)
      hiv.treat.rate.vec.04_14=c(0.01, 0.02, 0.05, 0.07, 0.09, 0.12, 0.16, 0.23, 0.25, 0.26, 0.27)
      hiv.treat.rate.vec.15_25=c(0.28, rep(0.3,10))
      hiv.treat.rate.vec=c(hiv.treat.rate.vec.04_14,hiv.treat.rate.vec.15_25)

        
      ###################################################################
      #healthcare parameters below
      ###################################################################
      
      ###################################################################
      #rates of detection  (i.e. lag between disease and 'being caught' by the health system
      #units of 1/year
      ###################################################################
      #depends on age group and HIV status (as proxy for health care access), not MDR status
      #TB-MAC states that everyone seeks care before dying. If true that nobody falls through the cracks, this should be infinity.
      #The 0% failure to seek health before death is unreasonable. Setting it to a large number but not too high to allow some death before healthcare seeking
      detect.A.n.base= 12 / 6 #12 / X months until detection  - (treatment rate of 1/3 in Uganda model, i.e. 3 years until treatment. Dowdy 2008 has 3 months)
      detect.A.u.base=detect.A.n.base
      detect.A.t.base=detect.A.u.base #faster if one already gets treated for HIV
      
      detect.C.n.base=detect.A.n.base
      detect.C.u.base=detect.A.u.base
      detect.C.t.base=detect.A.t.base
      
      frac.good.detect.C.n.base=0.2  #TB-MAC 20% of good detection
      frac.good.detect.C.u.base=0.2
      frac.good.detect.C.t.base=0.2
      frac.good.detect.A.n.base=0.2
      frac.good.detect.A.u.base=0.2
      frac.good.detect.A.t.base=0.2
      
      bad.detect.factor= 1 / 2 #value of 0.5 gives 100% improvement for 1b as specified in TB MAC document for 1b
  
      
    
      ###################################################################
      #fraction of those detected entering the good healthcare system
      ###################################################################
      frac.good.care.A.n = 1;  #assuming for SA that poor care only applies to diagnosis
      frac.good.care.A.u = frac.good.care.A.n;
      frac.good.care.A.t = frac.good.care.A.n;
      
      frac.good.care.C.n = frac.good.care.A.n
      frac.good.care.C.u = frac.good.care.A.u
      frac.good.care.C.t = frac.good.care.A.t
       
       
      ###################################################################
      #fraction initial defaulters
      ###################################################################
      
      bad.tx.factor = 1.0 #factor reducing fraction of success in low quality treatment group. 
      #post diagnosis is the same between low and high quality treatment regimens, per TB-MAC 
       
      def.frac.base=0.17; #fraction of hosts that default - TB-MAC value

      def.frac.MDR=0.3;
       
      def.frac.Igds.A.n=def.frac.base        #default same in low and high quality tx 
      def.frac.Igdr.A.n=def.frac.MDR
      def.frac.Ibds.A.n=def.frac.Igds.A.n / bad.tx.factor 
      def.frac.Ibdr.A.n=def.frac.Igds.A.n / bad.tx.factor 
      
      def.frac.Igds.A.u=def.frac.Igds.A.n 
      def.frac.Igdr.A.u=def.frac.Igdr.A.n
      def.frac.Ibds.A.u=def.frac.Igds.A.u / bad.tx.factor 
      def.frac.Ibdr.A.u=def.frac.Igdr.A.u / bad.tx.factor
      
      def.frac.Igds.A.t=def.frac.Igds.A.n 
      def.frac.Igdr.A.t=def.frac.Igds.A.t
      def.frac.Ibds.A.t=def.frac.Igds.A.t / bad.tx.factor 
      def.frac.Ibdr.A.t=def.frac.Igdr.A.t / bad.tx.factor

      def.frac.Igds.C.n=def.frac.Igds.A.n #kids same as adults 
      def.frac.Igdr.C.n=def.frac.Igdr.A.n
      def.frac.Ibds.C.n=def.frac.Igds.C.n / bad.tx.factor 
      def.frac.Ibdr.C.n=def.frac.Igdr.C.n / bad.tx.factor
      
      def.frac.Igds.C.u=def.frac.Igds.C.n 
      def.frac.Igdr.C.u=def.frac.Igdr.C.n
      def.frac.Ibds.C.u=def.frac.Igds.C.u / bad.tx.factor 
      def.frac.Ibdr.C.u=def.frac.Igdr.C.u / bad.tx.factor
      
      def.frac.Igds.C.t=def.frac.Igds.C.n 
      def.frac.Igdr.C.t=def.frac.Igdr.C.n
      def.frac.Ibds.C.t=def.frac.Igds.C.t / bad.tx.factor 
      def.frac.Ibdr.C.t=def.frac.Igdr.C.t / bad.tx.factor
      
      
       
      ###################################################################
      #rates of treatment (i.e. time between diagnosis and cure 
      #successful treatment leads to return to susceptible class
      #unsuccessful treatment leads to return to infectious undiagnosed
      #rate in units of 1/year
      ###################################################################
      #depends on age group, HIV status and MDR status

      tx.Igds.A.n = 12 / 1 # 12 / X months between diagnosis and treatment
      tx.Igdr.A.n = tx.Igds.A.n #initial default same for MDR
      tx.Ibds.A.n = tx.Igds.A.n / bad.tx.factor; #reduced treatment in bad sector
      tx.Ibdr.A.n = tx.Ibds.A.n
      tx.Igds.A.u = tx.Igds.A.n;
      tx.Igdr.A.u = tx.Igds.A.u #same for MDR
      tx.Ibds.A.u = tx.Igds.A.u / bad.tx.factor
      tx.Ibdr.A.u = tx.Ibds.A.u
      tx.Igds.A.t = tx.Igds.A.n
      tx.Igdr.A.t = tx.Igds.A.t
      tx.Ibds.A.t = tx.Igds.A.t / bad.tx.factor
      tx.Ibdr.A.t = tx.Ibds.A.t
      
      tx.Igds.C.n = tx.Igds.A.n
      tx.Igdr.C.n = tx.Igds.C.n
      tx.Ibds.C.n = tx.Igds.C.n / bad.tx.factor #assume children are treated at same rate as adults
      tx.Ibdr.C.n = tx.Ibds.C.n
      tx.Igds.C.u = tx.Igds.A.u
      tx.Igdr.C.u = tx.Igds.C.u
      tx.Ibds.C.u = tx.Igds.C.u / bad.tx.factor
      tx.Ibdr.C.u = tx.Ibds.C.u
      tx.Igds.C.t = tx.Igds.A.t
      tx.Igdr.C.t = tx.Igds.C.t
      tx.Ibds.C.t = tx.Igds.C.t / bad.tx.factor
      tx.Ibdr.C.t = tx.Ibds.C.t
      
      
      ###################################################################
      #fraction of successful treatments, given start of treatment (total success is computed in routine as based on non-default * success once tx is started 
      #successful treatment returns individuals back to susceptible
      ###################################################################
      #depends on age group, HIV status and MDR status
      hiv.factor = 1 #factor reducing fraction of success for HIV+ untreated individuals
      
      suc.Igds.A.n.base = 0.76 #76% success - TB-MAC data
      suc.Igdr.A.n.base = 0.5 #MDR TB - TB-MAC data
      suc.Ibds.A.n.base = suc.Igds.A.n.base / bad.tx.factor
      suc.Ibdr.A.n.base = suc.Igdr.A.n.base / bad.tx.factor
      suc.Ibds.A.u.base = suc.Ibds.A.n.base / hiv.factor
      suc.Ibdr.A.u.base = suc.Ibdr.A.n.base / hiv.factor
      suc.Igds.A.u.base = suc.Igds.A.n.base / hiv.factor
      suc.Igdr.A.u.base = suc.Igdr.A.n.base / hiv.factor
      suc.Ibds.A.t.base = suc.Ibds.A.n.base   #assume like HIV negative
      suc.Ibdr.A.t.base = suc.Ibdr.A.n.base
      suc.Igds.A.t.base = suc.Igds.A.n.base
      suc.Igdr.A.t.base = suc.Igdr.A.n.base
      
      suc.Ibds.C.n.base = suc.Ibds.A.n.base #assume children are same as adults
      suc.Ibdr.C.n.base = suc.Ibdr.A.n.base
      suc.Igds.C.n.base = suc.Igds.A.n.base
      suc.Igdr.C.n.base = suc.Igdr.A.n.base
      suc.Ibds.C.u.base = suc.Ibds.A.u.base
      suc.Ibdr.C.u.base = suc.Ibdr.A.u.base
      suc.Igds.C.u.base = suc.Igds.A.u.base
      suc.Igdr.C.u.base = suc.Igdr.A.u.base
      suc.Ibds.C.t.base = suc.Ibds.A.t.base
      suc.Ibdr.C.t.base = suc.Ibdr.A.t.base
      suc.Igds.C.t.base = suc.Igds.A.t.base
      suc.Igdr.C.t.base = suc.Igdr.A.t.base
      
      ###################################################################
      #rate at which hosts are moved on prophylaxis/protection (e.g. IPT)
      ###################################################################
     

      base.HIV.IPT = 0.05; #5% of HIV+ TB latent on ART get IPT at baseline

      prophy.S.A.n = 0; #prophylaxis among susceptibles
      prophy.Lus.A.n = 0; #note that IPT can/should be applied to MDR, but has no effect
      prophy.Lur.A.n = 0;

      prophy.S.A.u = 0; 
      prophy.Lus.A.u = 0;
      prophy.Lur.A.u = 0; 

      prophy.S.A.t = 0.02; #5% of HIV+ ART get IPT regardless of TB status
      prophy.Lus.A.t = 0.02; #5% of HIV+ TB latent on ART should be on IPT at baseline in 2012
      prophy.Lur.A.t = prophy.Lus.A.t; #IPT has no impact on MDR - but needs to be included for screening
 
      prophy.S.C.n = 0; 
      prophy.Lus.C.n = 0;
      prophy.Lur.C.n = 0;
      
      prophy.S.C.u = 0;
      prophy.Lus.C.u = 0;
      prophy.Lur.C.u = 0;
      
      prophy.S.C.t = prophy.S.A.t;
      prophy.Lus.C.t = prophy.Lus.A.t;
      prophy.Lur.C.t = prophy.Lur.A.t;
       
      
      ###################################################################
      #fraction of MDR emergence among those being unsuccessfully treated 
      #those move into the resistant compartments
      ###################################################################
      hiv.res.factor = 1.5 #increased emergence in HIV positive
      mdrfrac.Igds.A.n = MDR.switch*0.01  #no data available
      mdrfrac.Ibds.A.n = mdrfrac.Igds.A.n * bad.tx.factor #worse resistance emergence in bad treatment category
      mdrfrac.Igds.A.u = mdrfrac.Igds.A.n * hiv.res.factor #increased resistance emergence in HIV positive
      mdrfrac.Ibds.A.u = mdrfrac.Igds.A.u * bad.tx.factor
      mdrfrac.Ibds.A.t = mdrfrac.Ibds.A.n
      mdrfrac.Igds.A.t = mdrfrac.Igds.A.n
      
      mdrfrac.Ibds.C.n = mdrfrac.Ibds.A.n #assume children same as adults
      mdrfrac.Igds.C.n = mdrfrac.Igds.A.n
      mdrfrac.Ibds.C.u = mdrfrac.Ibds.A.u
      mdrfrac.Igds.C.u = mdrfrac.Igds.A.u
      mdrfrac.Ibds.C.t = mdrfrac.Ibds.A.t
      mdrfrac.Igds.C.t = mdrfrac.Igds.A.t
      
      
      ##########################
      #TB MAC Targets - required all are 2012 unless otherwise specified
      #used below in plots for comparison
      ##########################
      TBMAC.PopSize.adult=36824*1000 #adults only
      TBMAC.PopSize.all.mean=52386*1000
      TBMAC.PopSize.all.low=52230*1000 
      TBMAC.PopSize.all.high=52541*1000 
      
      TBMAC.TB.Inc.all.mean=900    #all per 100K
      TBMAC.TB.Inc.all.low=832
      TBMAC.TB.Inc.all.high=990
      
      TBMAC.TB.Inc.adult.mean=1117    #all per 100K adults
      TBMAC.TB.Inc.adult.low=1002
      TBMAC.TB.Inc.adult.high=1259
      
      TBMAC.TB.Inc.decline.mean=0.03 #annual decline (3% percent)
      TBMAC.TB.Inc.decline.low=0.02 #annual decline
      TBMAC.TB.Inc.decline.high=0.05 #annual decline
      
      dec.slope=-TBMAC.TB.Inc.all.mean*TBMAC.TB.Inc.decline.mean
      dec.offset.all=(TBMAC.TB.Inc.all.mean - dec.slope * 2012)
      dec.offset.adult=(TBMAC.TB.Inc.adult.mean - dec.slope * 2012)
      
      TBMAC.TB.Inc.all.vec=dec.slope*plot.years + dec.offset.all  #trend line - only mean, too hard to do all min/max combinations
      TBMAC.TB.Inc.adult.vec=dec.slope*plot.years + dec.offset.adult
      
      TBMAC.TB.Death.adult.mean=220    #all per 100K adults
      TBMAC.TB.Death.adult.low=179
      TBMAC.TB.Death.adult.high=270
      TBMAC.TB.Death.all.mean=179    #all per 100K
      TBMAC.TB.Death.all.low=149
      TBMAC.TB.Death.all.high=212
      
      ##########################
      #TB MAC Targets - recommended or other benchmarks
      ##########################
      TBMAC.TB.Not.all.mean=667;
      TBMAC.TB.Not.all.low=600;
      TBMAC.TB.Not.all.high=734;
      
      TBMAC.HIV.TB.prev.mean=63 #percent
      TBMAC.HIV.TB.prev.low=57 #percent
      TBMAC.HIV.TB.prev.high=69 #percent
      
      TBMAC.HIV.prev.adult.mean=15 #percent
      TBMAC.HIV.prev.adult.low=14 #percent
      TBMAC.HIV.prev.adult.high=16 #percent
      
      #art.year=c(2004:2025) #no ART before 2004 - already defined further up in the code
      #art.level=c(1,	2,	4,	6,	7,	8,	13,	23,	35,	42,	55,	61,	67,	69,	70,	71,	72,	73,	74,	75,	76,	77)
      
      TBMAC.HIV.TB.death.mean=74 #percent
      TBMAC.HIV.TB.death.low=54 #percent
      TBMAC.HIV.TB.death.high=95 #percent

      #non-TB MAC targets
      GTB.TB.Prev.all.mean=857 
      GTB.TB.Prev.all.low=305
      GTB.TB.Prev.all.high=1680

      UNAIDS.HIV.Prev.C=0.03 #prevalence of HIV among children in SA
      
      
      ###################################################################
      #defining initial conditions
      ###################################################################
      
      #initial conditions of variables
      Y0.C.n=c(Su.C.n=Children.size*(1-hiv.birth.frac)+(1-Adult.switch)*Adult.size,Sp.C.n=0,Lus.C.n=TB.switch*TBMAC.TB.Inc.adult.mean/100000*Children.size,Lur.C.n=TB.switch*MDR.switch*1e-2*TBMAC.TB.Inc.adult.mean/100000*Children.size,Lps.C.n=0,Lpr.C.n=0,Ihs.C.n=0,Ihr.C.n=0,Ibds.C.n=0,Ibdr.C.n=0,Igds.C.n=0,Igdr.C.n=0)
      Y0.C.u=c(Su.C.u=Children.size*hiv.birth.frac, Sp.C.u=0,Lus.C.u=0,Lur.C.u=0,Lps.C.u=0,Lpr.C.u=0,Ihs.C.u=0,Ihr.C.u=0,Ibds.C.u=0,Ibdr.C.u=0,Igds.C.u=0,Igdr.C.u=0)
      Y0.C.t=c(Su.C.t=0,Sp.C.t=0,Lus.C.t=0,Lur.C.t=0,Lps.C.t=0,Lpr.C.t=0,Ihs.C.t=0,Ihr.C.t=0,Ibds.C.t=0,Ibdr.C.t=0,Igds.C.t=0,Igdr.C.t=0)
      Y0.A.n=c(Su.A.n=Adult.switch*Adult.size,Sp.A.n=0,Lus.A.n=0,Lur.A.n=0,Lps.A.n=0,Lpr.A.n=0,Ihs.A.n=Adult.switch*TB.switch*TBMAC.TB.Inc.adult.mean/100000*Adult.size,Ihr.A.n=MDR.switch*1e-2*Adult.switch*TB.switch*TBMAC.TB.Inc.adult.mean/100000*Adult.size,Ibds.A.n=0,Ibdr.A.n=0,Igds.A.n=0,Igdr.A.n=0)
      Y0.A.u=c(Su.A.u=0,Sp.A.u=0,Lus.A.u=0,Lur.A.u=0,Lps.A.u=0,Lpr.A.u=0,Ihs.A.u=0,Ihr.A.u=0,Ibds.A.u=0,Ibdr.A.u=0,Igds.A.u=0,Igdr.A.u=0)
      Y0.A.t=c(Su.A.t=0,Sp.A.t=0,Lus.A.t=0,Lur.A.t=0,Lps.A.t=0,Lpr.A.t=0,Ihs.A.t=0,Ihr.A.t=0,Ibds.A.t=0,Ibdr.A.t=0,Igds.A.t=0,Igdr.A.t=0)
      
      #initial conditions of auxilliary variables for incidence and death
      Y0.Aux.C.n.inc=c(dIhs.C.n.inc=0,dIhr.C.n.inc=0,dIbds.C.n.inc=0,dIbdr.C.n.inc=0,dIgds.C.n.inc=0,dIgdr.C.n.inc=0)  #all TB incidences for non-HIV
      Y0.Aux.C.u.inc=c(dIhs.C.u.inc=0,dIhr.C.u.inc=0,dIbds.C.u.inc=0,dIbdr.C.u.inc=0,dIgds.C.u.inc=0,dIgdr.C.u.inc=0)  #all TB incidences for HIV no ART
      Y0.Aux.C.t.inc=c(dIhs.C.t.inc=0,dIhr.C.t.inc=0,dIbds.C.t.inc=0,dIbdr.C.t.inc=0,dIgds.C.t.inc=0,dIgdr.C.t.inc=0)  #all TB incidences for HIV on ART
      Y0.Aux.C.n.death=c(dIhs.C.n.death=0,dIhr.C.n.death=0,dIbds.C.n.death=0,dIbdr.C.n.death=0,dIgds.C.n.death=0,dIgdr.C.n.death=0) #all TB deaths for non-HIV
      Y0.Aux.C.u.death=c(dIhs.C.u.death=0,dIhr.C.u.death=0,dIbds.C.u.death=0,dIbdr.C.u.death=0,dIgds.C.u.death=0,dIgdr.C.u.death=0) #all TB deaths for HIV no ART
      Y0.Aux.C.t.death=c(dIhs.C.t.death=0,dIhr.C.t.death=0,dIbds.C.t.death=0,dIbdr.C.t.death=0,dIgds.C.t.death=0,dIgdr.C.t.death=0) #all TB deaths for HIV on ART
      Y0.Aux.C.inc=c(Y0.Aux.C.n.inc,Y0.Aux.C.u.inc,Y0.Aux.C.t.inc) #all TB incidences combined (6 x 3)
      Y0.Aux.C.death=c(Y0.Aux.C.n.death,Y0.Aux.C.u.death,Y0.Aux.C.t.death) #all new TB deaths combined (6 x 3)
    
      Y0.Aux.A.n.inc=c(dIhs.A.n.inc=0,dIhr.A.n.inc=0,dIbds.A.n.inc=0,dIbdr.A.n.inc=0,dIgds.A.n.inc=0,dIgdr.A.n.inc=0)  #all TB incidences for non-HIV
      Y0.Aux.A.u.inc=c(dIhs.A.u.inc=0,dIhr.A.u.inc=0,dIbds.A.u.inc=0,dIbdr.A.u.inc=0,dIgds.A.u.inc=0,dIgdr.A.u.inc=0)  #all TB incidences for HIV no ART
      Y0.Aux.A.t.inc=c(dIhs.A.t.inc=0,dIhr.A.t.inc=0,dIbds.A.t.inc=0,dIbdr.A.t.inc=0,dIgds.A.t.inc=0,dIgdr.A.t.inc=0)  #all TB incidences for HIV on ART
      Y0.Aux.A.n.death=c(dIhs.A.n.death=0,dIhr.A.n.death=0,dIbds.A.n.death=0,dIbdr.A.n.death=0,dIgds.A.n.death=0,dIgdr.A.n.death=0) #all TB deaths for non-HIV
      Y0.Aux.A.u.death=c(dIhs.A.u.death=0,dIhr.A.u.death=0,dIbds.A.u.death=0,dIbdr.A.u.death=0,dIgds.A.u.death=0,dIgdr.A.u.death=0) #all TB deaths for HIV no ART
      Y0.Aux.A.t.death=c(dIhs.A.t.death=0,dIhr.A.t.death=0,dIbds.A.t.death=0,dIbdr.A.t.death=0,dIgds.A.t.death=0,dIgdr.A.t.death=0) #all TB deaths for HIV on ART
      Y0.Aux.A.inc=c(Y0.Aux.A.n.inc,Y0.Aux.A.u.inc,Y0.Aux.A.t.inc) #all TB incidences combined (6 x 3)
      Y0.Aux.A.death=c(Y0.Aux.A.n.death,Y0.Aux.A.u.death,Y0.Aux.A.t.death) #all new TB deaths combined (6 x 3)
    
      #auxilliary variables for treatment
      Y0.aux.tx = c(dtx.Ibds.C=0,dtx.Ibdr.C=0,dtx.Igds.C=0,dtx.Igdr.C=0, dtx.Ibds.A=0,dtx.Ibdr.A=0,dtx.Igds.A=0,dtx.Igdr.A=0)
   
      #further auxilliary variables to track new infections (not cases)
      Y0.aux.newInf = c(dnewInf.C=0,dnewInf.A=0)  
    
      #further auxilliary variables to track cases due to recent infections (fast progressors)
      Y0.aux.recent = c(dAux.recent.TB.inc.C=0,dAux.recent.TB.inc.A=0)
        
      Y0.all.death = c(dAux.C.all.death=0,dAux.A.all.death=0)
        
      Y0.aux.diag=c(dAux.diag.C=0,dAux.diag.A=0,Aux.ACF.C=0,Aux.ACF.A=0)
        
      Y0.aux.ART=c(dAux.ART.inc.C=0,dAux.ART.inc.A=0)
        
      Y0.aux.IPT=c(Aux.IPT.nHIV.C=0,Aux.IPT.nHIV.A=0,Aux.IPT.HIV.C=0,Aux.IPT.HIV.A=0)
        
      Y0.Aux.All=c(Y0.Aux.C.inc,Y0.Aux.C.death,Y0.Aux.A.inc,Y0.Aux.A.death,Y0.aux.tx,Y0.aux.newInf,Y0.aux.recent,Y0.all.death, Y0.aux.diag, Y0.aux.ART,Y0.aux.IPT, dur.adult=0, dur.children=0, dAux.ART.TBd.inc.A=0)
  
      #all initial conditions, variables and auxilliary variables
      Y0.All=c(Y0.C.n,Y0.C.u,Y0.C.t,Y0.A.n,Y0.A.u,Y0.A.t, Y0.Aux.All)
      
        
      ######################################################
      #call ode-solver to integrate ODEs. 
      ######################################################
     
      #times at which stuff happens
      #events are used both annually to keep track of average duration of infection and others, 
      #and to implement ACF - to mimick continuous process, do it several times a year 
      eventtimes=seq(2000,2035,by=time.step); 
      sol=ode(Y0.All,timevec,odeequations,method="lsoda",parms=NULL, events = list(func = eventfun, time = eventtimes),rtol=tols,atol=tols);
      
      ######################################################
      #extract results from solutions
      ######################################################
       
      ######################################################
      #extract cumulative incidences from auxilliary variables and use them to compute annual incidences
      ######################################################
          
      #cumulative incidence of new cases 
      all.C.inc.cum=sol[,"dIhs.C.n.inc"]+sol[,"dIhr.C.n.inc"]+sol[,"dIhs.C.u.inc"]+sol[,"dIhr.C.u.inc"]+sol[,"dIhs.C.t.inc"]+sol[,"dIhr.C.t.inc"] 
      all.A.inc.cum=sol[,"dIhs.A.n.inc"]+sol[,"dIhr.A.n.inc"]+sol[,"dIhs.A.u.inc"]+sol[,"dIhr.A.u.inc"]+sol[,"dIhs.A.t.inc"]+sol[,"dIhr.A.t.inc"] 
      
      #cumulative incidence of new TB cases with HIV
      all.C.HIV.inc.cum=sol[,"dIhs.C.u.inc"]+sol[,"dIhr.C.u.inc"]+sol[,"dIhs.C.t.inc"]+sol[,"dIhr.C.t.inc"] 
      all.A.HIV.inc.cum=sol[,"dIhs.A.u.inc"]+sol[,"dIhr.A.u.inc"]+sol[,"dIhs.A.t.inc"]+sol[,"dIhr.A.t.inc"] 
      
      #cumulative incidence of new cases with MDR
      all.MDR.inc.cum=sol[,"dIhr.C.n.inc"]+sol[,"dIhr.C.u.inc"]+sol[,"dIhr.C.t.inc"]+sol[,"dIhr.A.n.inc"]+sol[,"dIhr.A.u.inc"]+sol[,"dIhr.A.t.inc"]
     
      #all cumulative TB deaths (independent of detection status)
      TB.death.C.cum=sol[,"dIhs.C.n.death"]+sol[,"dIhr.C.n.death"] + sol[,"dIbds.C.n.death"]+sol[,"dIbdr.C.n.death"]+ sol[,"dIgds.C.n.death"]+sol[,"dIgdr.C.n.death"]+ +sol[,"dIhs.C.u.death"]+sol[,"dIhr.C.u.death"] + sol[,"dIbds.C.u.death"]+sol[,"dIbdr.C.u.death"]+ sol[,"dIgds.C.u.death"]+sol[,"dIgdr.C.u.death"] +sol[,"dIhs.C.t.death"]+sol[,"dIhr.C.t.death"] + sol[,"dIbds.C.t.death"]+sol[,"dIbdr.C.t.death"]+ sol[,"dIgds.C.t.death"]+sol[,"dIgdr.C.t.death"]
  
       TB.death.A.cum=sol[,"dIhs.A.n.death"]+sol[,"dIhr.A.n.death"]+ sol[,"dIbds.A.n.death"]+sol[,"dIbdr.A.n.death"]+ sol[,"dIgds.A.n.death"]+sol[,"dIgdr.A.n.death"] +sol[,"dIhs.A.u.death"]+sol[,"dIhr.A.u.death"]+ sol[,"dIbds.A.u.death"]+sol[,"dIbdr.A.u.death"]+ sol[,"dIgds.A.u.death"]+sol[,"dIgdr.A.u.death"] +sol[,"dIhs.A.t.death"]+sol[,"dIhr.A.t.death"] + sol[,"dIbds.A.t.death"]+sol[,"dIbdr.A.t.death"]+ sol[,"dIgds.A.t.death"]+sol[,"dIgdr.A.t.death"]
  
      #all cumulative TB deaths among HIV- (corresponds to WHO data classification)
      all.C.nHIV.death.cum=sol[,"dIhs.C.n.death"]+sol[,"dIhr.C.n.death"] + sol[,"dIbds.C.n.death"]+sol[,"dIbdr.C.n.death"]+ sol[,"dIgds.C.n.death"]+sol[,"dIgdr.C.n.death"]
      all.A.nHIV.death.cum=sol[,"dIhs.A.n.death"]+sol[,"dIhr.A.n.death"] + sol[,"dIbds.A.n.death"]+sol[,"dIbdr.A.n.death"]+ sol[,"dIgds.A.n.death"]+sol[,"dIgdr.A.n.death"]
                                   
      #cumulative TB deaths among HIV positive (independent of detection status)
      all.C.HIV.death.cum= sol[,"dIhs.C.u.death"]+sol[,"dIhr.C.u.death"]+sol[,"dIhs.C.t.death"]+sol[,"dIhr.C.t.death"] + sol[,"dIbds.C.u.death"]+sol[,"dIbdr.C.u.death"]+ sol[,"dIgds.C.u.death"]+sol[,"dIgdr.C.u.death"] + sol[,"dIbds.C.t.death"]+sol[,"dIbdr.C.t.death"]+ sol[,"dIgds.C.t.death"]+sol[,"dIgdr.C.t.death"]
      all.A.HIV.death.cum= sol[,"dIhs.A.u.death"]+sol[,"dIhr.A.u.death"]+sol[,"dIhs.A.t.death"]+sol[,"dIhr.A.t.death"] + sol[,"dIbds.A.u.death"]+sol[,"dIbdr.A.u.death"]+ sol[,"dIgds.A.u.death"]+sol[,"dIgdr.A.u.death"] + sol[,"dIbds.A.t.death"]+sol[,"dIbdr.A.t.death"]+ sol[,"dIgds.A.t.death"]+sol[,"dIgdr.A.t.death"]
  
      #cumulative deaths due to all causes
      dAux.C.all.death.cum=sol[,"dAux.C.all.death"]
      dAux.A.all.death.cum=sol[,"dAux.A.all.death"]

      #cumulative TB/MDR treated
      all.tx.C.s.cum=sol[,'dtx.Ibds.C']+sol[,'dtx.Igds.C']
      all.tx.C.r.cum=sol[,'dtx.Ibdr.C']+sol[,'dtx.Igdr.C']
      all.tx.A.s.cum=sol[,'dtx.Ibds.A']+sol[,'dtx.Igds.A']
      all.tx.A.r.cum=sol[,'dtx.Ibdr.A']+sol[,'dtx.Igdr.A']
  
      #cumulative incidence of new TB infections (not cases)
      newInf.C.cum=sol[,'dnewInf.C']
      newInf.A.cum=sol[,'dnewInf.A']
      
      #cumulate incidence of TB disease due to recent infection
      recentDis.C.cum=sol[,'dAux.recent.TB.inc.C']
      recentDis.A.cum=sol[,'dAux.recent.TB.inc.A']
      
      #cumulative incidence of individuals screened each year through passive case finding
      passive.diagnoses.C.cum=sol[,'dAux.diag.C']
      passive.diagnoses.A.cum=sol[,'dAux.diag.A']
      
      #cumulative incidence of individuals screened each year through active case finding
      Aux.ACF.C.cum=sol[,'Aux.ACF.C']
      Aux.ACF.A.cum=sol[,'Aux.ACF.A']
      
      #cumulative cases started on ART - independent of TB status
      Aux.ART.inc.C.cum=sol[,'dAux.ART.inc.C']
      Aux.ART.inc.A.cum=sol[,'dAux.ART.inc.A']
      #cumulative cases started on ART - TB disease status (only applies to adults) - needed to compute TB cases caught by IPT screening
      Aux.ART.TBd.inc.A.cum=sol[,'dAux.ART.TBd.inc.A']
      



      #cumulative nHIV LTBI cases on IPT
      Aux.IPT.nHIV.C.cum=sol[,'Aux.IPT.nHIV.C']
      Aux.IPT.nHIV.A.cum=sol[,'Aux.IPT.nHIV.A']
      
      #cumulative HIV LTBI cases that are moved onto IPT in the model (i.e. screened and IPT is started)
      Aux.IPT.HIV.C.cum=sol[,'Aux.IPT.HIV.C']
      Aux.IPT.HIV.A.cum=sol[,'Aux.IPT.HIV.A']

      #from cumulative incidences returned by the ode solver, extract annual rates by computing differences between years
      
      #all.A.inc=rep(0,length(reportyears)-1)
      all.A.inc=rep(0,length(plot.years))
      all.A.HIV.inc=all.A.inc;
      TB.death.A=all.A.inc;
      all.A.HIV.death=all.A.inc;

      all.A.not=all.A.inc;
      all.C.inc=all.A.inc;

      all.C.HIV.inc=all.A.inc;
      TB.death.C=all.A.inc;
      all.C.not=all.A.inc;
      all.C.HIV.death=all.A.inc;
    
      all.A.nHIV.death=all.A.inc;
      all.C.nHIV.death=all.A.inc;
      
      all.MDR.inc=all.A.inc;
      
      all.C.tx.s=all.A.inc;
      all.C.tx.r=all.A.inc;
      all.A.tx.s=all.A.inc;
      all.A.tx.r=all.A.inc;
      
      newInf.C=all.A.inc #new infections
      newInf.A=all.A.inc
      
      recentDis.C=all.A.inc #disease due to recent infections
      recentDis.A=all.A.inc
     
      Aux.ACF.A=all.A.inc
      Aux.ACF.C=all.A.inc
       
      passive.diagnoses.C=all.A.inc
      passive.diagnoses.A=all.A.inc
       
      Aux.ART.inc.C=all.A.inc
      Aux.ART.inc.A=all.A.inc
      Aux.ART.TBd.inc.A=all.A.inc


      All.annual.death.A=all.A.inc
      All.annual.death.C=all.A.inc

      Aux.IPT.nHIV.C.inc=all.A.inc
      Aux.IPT.nHIV.A.inc=all.A.inc
      
      Aux.IPT.HIV.C.inc=all.A.inc
      Aux.IPT.HIV.A.inc=all.A.inc
     
       
      ct=1;
      #compute incidence by subtraction
      
      #for (yct in reportyears[-length(reportyears)])
      for (yct in plot.years)
      {
        all.A.inc[ct]=all.A.inc.cum[which(sol[,"time"]==yct+1)]-all.A.inc.cum[which(sol[,"time"]==yct)] #cumulative incidence difference between 2 years gives annual incidence
        all.A.HIV.inc[ct]=all.A.HIV.inc.cum[which(sol[,"time"]==yct+1)]-all.A.HIV.inc.cum[which(sol[,"time"]==yct)] 
        TB.death.A[ct]=TB.death.A.cum[which(sol[,"time"]==yct+1)]-TB.death.A.cum[which(sol[,"time"]==yct)] 
        all.A.HIV.death[ct]=all.A.HIV.death.cum[which(sol[,"time"]==yct+1)]-all.A.HIV.death.cum[which(sol[,"time"]==yct)] 
        #all.A.not[ct]=all.A.not.cum[which(sol[,"time"]==yct+1)]-all.A.not.cum[which(sol[,"time"]==yct)] 
        
        all.C.inc[ct]=all.C.inc.cum[which(sol[,"time"]==yct+1)]-all.C.inc.cum[which(sol[,"time"]==yct)] 
        all.C.HIV.inc[ct]=all.C.HIV.inc.cum[which(sol[,"time"]==yct+1)]-all.C.HIV.inc.cum[which(sol[,"time"]==yct)] 
        TB.death.C[ct]=TB.death.C.cum[which(sol[,"time"]==yct+1)]-TB.death.C.cum[which(sol[,"time"]==yct)]
        all.C.HIV.death[ct]=all.C.HIV.death.cum[which(sol[,"time"]==yct+1)]-all.C.HIV.death.cum[which(sol[,"time"]==yct)]
        #all.C.not[ct]=all.C.not.cum[which(sol[,"time"]==yct+1)]-all.C.not.cum[which(sol[,"time"]==yct)]
      
        all.A.nHIV.death[ct]=all.A.nHIV.death.cum[which(sol[,"time"]==yct+1)]-all.A.nHIV.death.cum[which(sol[,"time"]==yct)] 
        all.C.nHIV.death[ct]=all.C.nHIV.death.cum[which(sol[,"time"]==yct+1)]-all.C.nHIV.death.cum[which(sol[,"time"]==yct)]

        All.annual.death.A[ct]=dAux.A.all.death.cum[which(sol[,"time"]==yct+1)]-dAux.A.all.death.cum[which(sol[,"time"]==yct)]
        All.annual.death.C[ct]=dAux.C.all.death.cum[which(sol[,"time"]==yct+1)]-dAux.C.all.death.cum[which(sol[,"time"]==yct)]

        passive.diagnoses.C[ct]=passive.diagnoses.C.cum[which(sol[,"time"]==yct+1)]-passive.diagnoses.C.cum[which(sol[,"time"]==yct)]
        passive.diagnoses.A[ct]=passive.diagnoses.A.cum[which(sol[,"time"]==yct+1)]-passive.diagnoses.A.cum[which(sol[,"time"]==yct)]
      
        Aux.ACF.C[ct]=Aux.ACF.C.cum[which(sol[,"time"]==yct+1)]-Aux.ACF.C.cum[which(sol[,"time"]==yct)]
        Aux.ACF.A[ct]=Aux.ACF.A.cum[which(sol[,"time"]==yct+1)]-Aux.ACF.A.cum[which(sol[,"time"]==yct)]
      
        Aux.ART.inc.A[ct]=Aux.ART.inc.A.cum[which(sol[,"time"]==yct+1)]-Aux.ART.inc.A.cum[which(sol[,"time"]==yct)]
        Aux.ART.inc.C[ct]=Aux.ART.inc.C.cum[which(sol[,"time"]==yct+1)]-Aux.ART.inc.C.cum[which(sol[,"time"]==yct)]
        Aux.ART.TBd.inc.A[ct]=Aux.ART.TBd.inc.A.cum[which(sol[,"time"]==yct+1)]-Aux.ART.TBd.inc.A.cum[which(sol[,"time"]==yct)]
        
        Aux.IPT.nHIV.C.inc[ct]=Aux.IPT.nHIV.C.cum[which(sol[,"time"]==yct+1)]-Aux.IPT.nHIV.C.cum[which(sol[,"time"]==yct)]
        Aux.IPT.nHIV.A.inc[ct]=Aux.IPT.nHIV.A.cum[which(sol[,"time"]==yct+1)]-Aux.IPT.nHIV.A.cum[which(sol[,"time"]==yct)]
       
        Aux.IPT.HIV.C.inc[ct]=Aux.IPT.HIV.C.cum[which(sol[,"time"]==yct+1)]-Aux.IPT.HIV.C.cum[which(sol[,"time"]==yct)]
        Aux.IPT.HIV.A.inc[ct]=Aux.IPT.HIV.A.cum[which(sol[,"time"]==yct+1)]-Aux.IPT.HIV.A.cum[which(sol[,"time"]==yct)]
                
        all.MDR.inc[ct]=all.MDR.inc.cum[which(sol[,"time"]==yct+1)]-all.MDR.inc.cum[which(sol[,"time"]==yct)]
         
        all.C.tx.s[ct]=all.tx.C.s.cum[which(sol[,"time"]==yct+1)]-all.tx.C.s.cum[which(sol[,"time"]==yct)]
        all.C.tx.r[ct]=all.tx.C.r.cum[which(sol[,"time"]==yct+1)]-all.tx.C.r.cum[which(sol[,"time"]==yct)]
        all.A.tx.s[ct]=all.tx.A.s.cum[which(sol[,"time"]==yct+1)]-all.tx.A.s.cum[which(sol[,"time"]==yct)]
        all.A.tx.r[ct]=all.tx.A.r.cum[which(sol[,"time"]==yct+1)]-all.tx.A.r.cum[which(sol[,"time"]==yct)]
        
        newInf.C[ct]=newInf.C.cum[which(sol[,"time"]==yct+1)]-newInf.C.cum[which(sol[,"time"]==yct)]
        newInf.A[ct]=newInf.A.cum[which(sol[,"time"]==yct+1)]-newInf.A.cum[which(sol[,"time"]==yct)]
      
        recentDis.C[ct]=recentDis.C.cum[which(sol[,"time"]==yct+1)]-recentDis.C.cum[which(sol[,"time"]==yct)]
        recentDis.A[ct]=recentDis.A.cum[which(sol[,"time"]==yct+1)]-recentDis.A.cum[which(sol[,"time"]==yct)]
        
        ct=ct+1;
      }
      

      #now reduce data source to only those years we need - we want mid-point for each year
      #sol2=sol[match(reportyears[-length(reportyears)],sol[,1]),] #only keep results which will be reported 
   
      #keep everything, easier for plotting, filter below for reporting
      sol2=sol 
     
      #total populations 
      all.C=rowSums(sol2[,(1:36)+1])
      all.A=rowSums(sol2[,(37:72)+1])
      all.pop=all.C+all.A;
      
      
      ######################################################
      #lots of different prevalences extracted directly from ODE time-series
      ######################################################
       
      #all TB latent hosts yes/no HIV, yes/no MDR 
      TBlat.nHIV.nMDR.prev.C=sol2[,"Lus.C.n"]+sol2[,"Lps.C.n"]      
      TBlat.HIV.nMDR.prev.C =sol2[,"Lus.C.u"]+sol2[,"Lps.C.u"]+sol2[,"Lus.C.t"]+sol2[,"Lps.C.t"]
      TBlat.nHIV.MDR.prev.C =sol2[,"Lur.C.n"]+sol2[,"Lpr.C.n"]
      TBlat.HIV.MDR.prev.C  =sol2[,"Lur.C.u"]+sol2[,"Lpr.C.u"]+sol2[,"Lur.C.t"]+sol2[,"Lpr.C.t"]
      
      TBlat.nHIV.nMDR.prev.A=sol2[,"Lus.A.n"]+sol2[,"Lps.A.n"]      
      TBlat.HIV.nMDR.prev.A =sol2[,"Lus.A.u"]+sol2[,"Lps.A.u"]+sol2[,"Lus.A.t"]+sol2[,"Lps.A.t"]
      TBlat.nHIV.MDR.prev.A =sol2[,"Lur.A.n"]+sol2[,"Lpr.A.n"]
      TBlat.HIV.MDR.prev.A  =sol2[,"Lur.A.u"]+sol2[,"Lpr.A.u"]+sol2[,"Lur.A.t"]+sol2[,"Lpr.A.t"]

      TBlat.HIV.ART.nMDR.prev.C =sol2[,"Lus.C.t"]+sol2[,"Lps.C.t"]
      TBlat.HIV.ART.MDR.prev.C  =sol2[,"Lur.C.t"]+sol2[,"Lpr.C.t"]
      TBlat.HIV.ART.nMDR.prev.A =sol2[,"Lus.A.t"]+sol2[,"Lps.A.t"]
      TBlat.HIV.ART.MDR.prev.A  =sol2[,"Lur.A.t"]+sol2[,"Lpr.A.t"]
      
      #HIV+ ART+ sus or lat  
      all.HIV.ART.prev.C = sol2[,"Su.C.t"] + sol2[,"Sp.C.t"] + sol2[,"Lus.C.t"] + sol2[,"Lps.C.t"] + sol2[,"Lur.C.t"] + sol2[,"Lpr.C.t"]
      all.HIV.ART.prev.A = sol2[,"Su.A.t"] + sol2[,"Sp.A.t"] + sol2[,"Lus.A.t"] + sol2[,"Lps.A.t"] + sol2[,"Lur.A.t"] + sol2[,"Lpr.A.t"]
      

      #all TB latent infection (excluding disease) prevalence MDR and not, HIV and not
      all.C.TBlat.prev= TBlat.nHIV.nMDR.prev.C+TBlat.HIV.nMDR.prev.C+TBlat.nHIV.MDR.prev.C+TBlat.HIV.MDR.prev.C
      all.A.TBlat.prev= TBlat.nHIV.nMDR.prev.A+TBlat.HIV.nMDR.prev.A+TBlat.nHIV.MDR.prev.A+TBlat.HIV.MDR.prev.A
  
      #MDR TB latent infection (excluding disease)  HIV and not
      all.C.MDRlat.prev=TBlat.nHIV.MDR.prev.C+TBlat.HIV.MDR.prev.C
      all.A.MDRlat.prev=TBlat.nHIV.MDR.prev.A+TBlat.HIV.MDR.prev.A
          
      #TB disease prevalence among those not detected, MDR and not, HIV and not
      all.C.TB.h.prev=sol2[,"Ihs.C.n"]+sol2[,"Ihr.C.n"]+sol2[,"Ihs.C.u"]+sol2[,"Ihr.C.u"]+sol2[,"Ihs.C.t"]+sol2[,"Ihr.C.t"]
      all.A.TB.h.prev=sol2[,"Ihs.A.n"]+sol2[,"Ihr.A.n"]+sol2[,"Ihs.A.u"]+sol2[,"Ihr.A.u"]+sol2[,"Ihs.A.t"]+sol2[,"Ihr.A.t"]
      
      #TB disease prevalence among those detected, MDR and not, HIV and not
      all.C.TB.d.prev=sol2[,"Ibds.C.n"]+sol2[,"Ibdr.C.n"]+sol2[,"Igds.C.n"]+sol2[,"Igdr.C.n"]+sol2[,"Ibds.C.u"]+sol2[,"Ibdr.C.u"]+sol2[,"Igds.C.u"]+sol2[,"Igdr.C.u"]+sol2[,"Ibds.C.t"]+sol2[,"Ibdr.C.t"]+sol2[,"Igds.C.t"]+sol2[,"Igdr.C.t"]
      all.A.TB.d.prev=sol2[,"Ibds.A.n"]+sol2[,"Ibdr.A.n"]+sol2[,"Igds.A.n"]+sol2[,"Igdr.A.n"]+sol2[,"Ibds.A.u"]+sol2[,"Ibdr.A.u"]+sol2[,"Igds.A.u"]+sol2[,"Igdr.A.u"]+sol2[,"Ibds.A.t"]+sol2[,"Ibdr.A.t"]+sol2[,"Igds.A.t"]+sol2[,"Igdr.A.t"]
  
      #TB disease prevalence among those detected and undetected, MDR and not, HIV and not
      all.C.TB.prev=all.C.TB.h.prev+all.C.TB.d.prev    
      all.A.TB.prev=all.A.TB.h.prev+all.A.TB.d.prev    

      #TB disease prevalence using the whole time-series
      all.C.TB.h.prev.long=sol[,"Ihs.C.n"]+sol[,"Ihr.C.n"]+sol[,"Ihs.C.u"]+sol[,"Ihr.C.u"]+sol[,"Ihs.C.t"]+sol[,"Ihr.C.t"]
      all.A.TB.h.prev.long=sol[,"Ihs.A.n"]+sol[,"Ihr.A.n"]+sol[,"Ihs.A.u"]+sol[,"Ihr.A.u"]+sol[,"Ihs.A.t"]+sol[,"Ihr.A.t"]
      all.C.TB.d.prev.long=sol[,"Ibds.C.n"]+sol[,"Ibdr.C.n"]+sol[,"Igds.C.n"]+sol[,"Igdr.C.n"]+sol[,"Ibds.C.u"]+sol[,"Ibdr.C.u"]+sol[,"Igds.C.u"]+sol[,"Igdr.C.u"]+sol[,"Ibds.C.t"]+sol[,"Ibdr.C.t"]+sol[,"Igds.C.t"]+sol[,"Igdr.C.t"]
      all.A.TB.d.prev.long=sol[,"Ibds.A.n"]+sol[,"Ibdr.A.n"]+sol[,"Igds.A.n"]+sol[,"Igdr.A.n"]+sol[,"Ibds.A.u"]+sol[,"Ibdr.A.u"]+sol[,"Igds.A.u"]+sol[,"Igdr.A.u"]+sol[,"Ibds.A.t"]+sol[,"Ibdr.A.t"]+sol[,"Igds.A.t"]+sol[,"Igdr.A.t"]
      all.C.TB.prev.long=all.C.TB.h.prev.long+all.C.TB.d.prev.long
      all.A.TB.prev.long=all.A.TB.h.prev.long+all.A.TB.d.prev.long

      #all TB infection (latent and disease) prevalence MDR and not, HIV and not
      all.C.TBinf.prev=all.C.TB.prev+all.C.TBlat.prev
      all.A.TBinf.prev=all.A.TB.prev+all.A.TBlat.prev
      
      #TB disease prevalence - MDR positive, HIV and not, detected and not
      all.C.MDR.prev=sol2[,"Ihr.C.n"]+sol2[,"Ihr.C.u"]+sol2[,"Ihr.C.t"]+sol2[,"Ibdr.C.n"]+sol2[,"Igdr.C.n"]+sol2[,"Ibdr.C.u"]+sol2[,"Igdr.C.u"]+sol2[,"Ibdr.C.t"]+sol2[,"Igdr.C.t"]
      all.A.MDR.prev=sol2[,"Ihr.A.n"]+sol2[,"Ihr.A.u"]+sol2[,"Ihr.A.t"]+sol2[,"Ibdr.A.n"]+sol2[,"Igdr.A.n"]+sol2[,"Ibdr.A.u"]+sol2[,"Igdr.A.u"]+sol2[,"Ibdr.A.t"]+sol2[,"Igdr.A.t"]
  
      #TB disease prevalence - HIV positive, MDR and nMDR, detected and not
      all.C.TB.HIV.prev=sol2[,"Ihs.C.u"]+sol2[,"Ihr.C.u"]+sol2[,"Ibds.C.u"]+sol2[,"Ibdr.C.u"]+sol2[,"Igds.C.u"]+sol2[,"Igdr.C.u"]+sol2[,"Ihs.C.t"]+sol2[,"Ihr.C.t"]+sol2[,"Ibds.C.t"]+sol2[,"Ibdr.C.t"]+sol2[,"Igds.C.t"]+sol2[,"Igdr.C.t"]
      all.A.TB.HIV.prev=sol2[,"Ihs.A.u"]+sol2[,"Ihr.A.u"]+sol2[,"Ibds.A.u"]+sol2[,"Ibdr.A.u"]+sol2[,"Igds.A.u"]+sol2[,"Igdr.A.u"]+sol2[,"Ihs.A.t"]+sol2[,"Ihr.A.t"]+sol2[,"Ibds.A.t"]+sol2[,"Ibdr.A.t"]+sol2[,"Igds.A.t"]+sol2[,"Igdr.A.t"]
  
      #HIV prevalence - any TB status
      all.C.HIV.prev=rowSums(sol2[,(13:(13+23))+1])
      all.A.HIV.prev=rowSums(sol2[,(49:(49+23))+1])
                                     
      #HIV treated prevalence - any TB status
      all.C.tx.HIV.prev=sol2[,"Su.C.t"]+sol2[,"Sp.C.t"]+sol2[,"Lus.C.t"]+sol2[,"Lur.C.t"]+sol2[,"Lps.C.t"]+sol2[,"Lpr.C.t"]+sol2[,"Ihs.C.t"]+sol2[,"Ihr.C.t"]+sol2[,"Ibds.C.t"]+sol2[,"Ibdr.C.t"]+sol2[,"Igds.C.t"]+sol2[,"Igdr.C.t"]
      all.A.tx.HIV.prev=sol2[,"Su.A.t"]+sol2[,"Sp.A.t"]+sol2[,"Lus.A.t"]+sol2[,"Lur.A.t"]+sol2[,"Lps.A.t"]+sol2[,"Lpr.A.t"]+sol2[,"Ihs.A.t"]+sol2[,"Ihr.A.t"]+sol2[,"Ibds.A.t"]+sol2[,"Ibdr.A.t"]+sol2[,"Igds.A.t"]+sol2[,"Igdr.A.t"]
  
      #ART among HIV-TB positive
      all.C.tx.TB.HIV.prev=sol2[,"Ihs.C.t"]+sol2[,"Ihr.C.t"]+sol2[,"Ibds.C.t"]+sol2[,"Ibdr.C.t"]+sol2[,"Igds.C.t"]+sol2[,"Igdr.C.t"]
      all.A.tx.TB.HIV.prev=sol2[,"Ihs.A.t"]+sol2[,"Ihr.A.t"]+sol2[,"Ibds.A.t"]+sol2[,"Ibdr.A.t"]+sol2[,"Igds.A.t"]+sol2[,"Igdr.A.t"]
      
      #nHIV nTB prevalence
      nHIV.nTB.prev.C=sol2[,"Su.C.n"]+sol2[,"Sp.C.n"]+sol2[,"Lus.C.n"]+sol2[,"Lur.C.n"]+sol2[,"Lps.C.n"]+sol2[,"Lpr.C.n"] 
      nHIV.nTB.prev.A=sol2[,"Su.A.n"]+sol2[,"Sp.A.n"]+sol2[,"Lus.A.n"]+sol2[,"Lur.A.n"]+sol2[,"Lps.A.n"]+sol2[,"Lpr.A.n"]
      nHIV.nTB.prev.all=nHIV.nTB.prev.A+nHIV.nTB.prev.C
      
      #nHIV TB prevalence
      nHIV.TB.prev.C=sol2[,"Ihs.C.n"]+sol2[,"Ihr.C.n"]+sol2[,"Ibds.C.n"]+sol2[,"Ibdr.C.n"]+sol2[,"Igds.C.n"]+sol2[,"Igdr.C.n"]
      nHIV.TB.prev.A=sol2[,"Ihs.A.n"]+sol2[,"Ihr.A.n"]+sol2[,"Ibds.A.n"]+sol2[,"Ibdr.A.n"]+sol2[,"Igds.A.n"]+sol2[,"Igdr.A.n"]
      nHIV.TB.prev.all=nHIV.TB.prev.A+nHIV.TB.prev.C
     
      #HIV nART nTB prevalence
      HIV.nART.nTB.prev.C=sol2[,"Su.C.u"]+sol2[,"Sp.C.u"]+sol2[,"Lus.C.u"]+sol2[,"Lur.C.u"]+sol2[,"Lps.C.u"]+sol2[,"Lpr.C.u"]
      HIV.nART.nTB.prev.A=sol2[,"Su.A.u"]+sol2[,"Sp.A.u"]+sol2[,"Lus.A.u"]+sol2[,"Lur.A.u"]+sol2[,"Lps.A.u"]+sol2[,"Lpr.A.u"]
      HIV.nART.nTB.prev.all=HIV.nART.nTB.prev.A+HIV.nART.nTB.prev.C
      
      #HIV nART TB prevalence
      HIV.nART.TB.prev.C=sol2[,"Ihs.C.u"]+sol2[,"Ihr.C.u"]+sol2[,"Ibds.C.u"]+sol2[,"Ibdr.C.u"]+sol2[,"Igds.C.u"]+sol2[,"Igdr.C.u"]
      HIV.nART.TB.prev.A= sol2[,"Ihs.A.u"]+sol2[,"Ihr.A.u"]+sol2[,"Ibds.A.u"]+sol2[,"Ibdr.A.u"]+sol2[,"Igds.A.u"]+sol2[,"Igdr.A.u"]
      HIV.nART.TB.prev.all=HIV.nART.TB.prev.A+HIV.nART.TB.prev.C
      
      #HIV+ART nTB prevalence
      HIV.ART.nTB.prev.C=sol2[,"Su.C.t"]+sol2[,"Sp.C.t"]+sol2[,"Lus.C.t"]+sol2[,"Lur.C.t"]+sol2[,"Lps.C.t"]+sol2[,"Lpr.C.t"]
      HIV.ART.nTB.prev.A=sol2[,"Su.A.t"]+sol2[,"Sp.A.t"]+sol2[,"Lus.A.t"]+sol2[,"Lur.A.t"]+sol2[,"Lps.A.t"]+sol2[,"Lpr.A.t"]
      HIV.ART.nTB.prev.all=HIV.ART.nTB.prev.A+HIV.ART.nTB.prev.C

      #HIV+ART TB disease prevalence
      HIV.ART.TB.prev.C=sol2[,"Ihs.C.t"]+sol2[,"Ihr.C.t"]+sol2[,"Ibds.C.t"]+sol2[,"Ibdr.C.t"]+sol2[,"Igds.C.t"]+sol2[,"Igdr.C.t"] 
      HIV.ART.TB.prev.A= sol2[,"Ihs.A.t"]+sol2[,"Ihr.A.t"]+sol2[,"Ibds.A.t"]+sol2[,"Ibdr.A.t"]+sol2[,"Igds.A.t"]+sol2[,"Igdr.A.t"]
      HIV.ART.TB.prev.all=HIV.ART.TB.prev.A+HIV.ART.TB.prev.C
                        
      #number of IPT hosts with HIV and TB latency
      Aux.IPT.HIV.C.prev=sol2[,"Lps.C.u"]+sol2[,"Lpr.C.u"]+sol2[,"Lps.C.t"]+sol2[,"Lpr.C.t"]
      Aux.IPT.HIV.A.prev=sol2[,"Lps.A.u"]+sol2[,"Lpr.A.u"]+sol2[,"Lps.A.t"]+sol2[,"Lpr.A.t"]

      #number of IPT hosts with HIV and ART  - either sus or lat TB 
      Aux.IPT.HIV.ART.C.prev=sol2[,"Lps.C.t"]+sol2[,"Lpr.C.t"]+sol2[,"Sp.C.t"]
      Aux.IPT.HIV.ART.A.prev=sol2[,"Lps.A.t"]+sol2[,"Lpr.A.t"]+sol2[,"Sp.A.t"]
 
      #number of IPT hosts without HIV and TB latency
      Aux.IPT.nHIV.C.prev=sol2[,"Lps.C.n"]+sol2[,"Lpr.C.n"]
      Aux.IPT.nHIV.A.prev=sol2[,"Lps.A.n"]+sol2[,"Lpr.A.n"]
            
      #percent of TB disease incidence due to MDR
      PercMDR.TB.inc.all=all.MDR.inc/(all.A.inc+all.C.inc)*100;
      
      #perceent of TB disease incidence due to recent infection/fast progression
      Perc.Recent.TB.inc.all= (recentDis.C+recentDis.A)/(all.A.inc+all.C.inc)*100;
      Perc.Recent.TB.inc.adults = recentDis.A/all.A.inc*100;
                                             
      ave.dur.disease =  sol2[,'dur.adult']*all.A / all.pop + sol2[,'dur.children']*all.C / all.pop
                                             

      ##########################
      #saving results to matrix for use with TB-MAC spreadsheet
      ##########################
      false.pos.factor=1.06 #multiply treatments to get from true positive only in my simulation to an estimate for all treatments  
   

      tb_treat_noMDR = false.pos.factor * (all.C.tx.s + all.A.tx.s)  #Individuals initiated on a TB treatment regimen in 2012 (in thousands) (all ages)
      tb_treat_MDR = false.pos.factor * (all.C.tx.r + all.A.tx.r)  #Individuals initiated on a MDR-TB treatment regimen in 2012 (in thousands) (all ages)
      tb_treat = tb_treat_MDR + tb_treat_noMDR
      tb_treat_adult = false.pos.factor * (all.A.tx.s + all.A.tx.r)

      rep.time=match(reportyears[-length(reportyears)],sol[,1]) #time for reporting    
      rep.time2=match(reportyears[-length(reportyears)],plot.years) #time for reporting    
      rep.time3=match(plot.years,sol[,1]) #time for reporting    
  
    
      ##########################
      #calibration values - all in 2012
      if (int.nr==0) #calibration baseline
      {
      ind1=which(plot.years==2012)
      ind2=which(sol2[,1]==2012)
      ind1.2011=which(plot.years==2011)
      ind2.2011=which(sol2[,1]==2011)
      tb2012inc=(all.A.inc[ind1]+all.C.inc[ind1])/(all.pop[ind2])*100000
      tb2011inc=(all.A.inc[ind1.2011]+all.C.inc[ind1.2011])/(all.pop[ind2.2011])*100000
      tb.dec=(tb2011inc-tb2012inc)/tb2011inc*100

      
  
      model.res=data.frame(tb_incid_adult=all.A.inc[ind1]/all.A[ind2]*100000, tb_incid_all=tb2012inc,	tb_mort_adult=TB.death.A[ind1]/all.A[ind2]*100000,	tb_mort_all=(TB.death.A[ind1]+TB.death.C[ind1])/all.pop[ind2]*100000,	pop_size_adult=all.A[ind2],	pop_size_all=all.pop[ind2],	pop_size_all_2025=all.pop[which(sol2[,1]==2025)], tb_treat=tb_treat[ind1], tb_treat_MDR=tb_treat_MDR[ind1], annual_decline_tb_incid=tb.dec, per_MDR_new_2002 = "", per_MDR_retreat_2002 = "", 	per_tb_notif_HIV_pos=(all.C.HIV.inc[ind1]+all.A.HIV.inc[ind1])/(all.C.inc[ind1]+all.A.inc[ind1])*100,	HIV_prev_adult=(all.A.HIV.prev[ind2])/all.A[ind2]*100 ,	per_HIV_pos_ART=(all.A.tx.HIV.prev[ind2])/(all.A.HIV.prev[ind2])*100,	per_tb_deaths_HIV_pos=(all.C.HIV.death[ind1]+all.A.HIV.death[ind1])/(TB.death.A[ind1]+TB.death.C[ind1])*100 )

      target.mean=data.frame(tb_incid_adult=TBMAC.TB.Inc.adult.mean, tb_incid_all=TBMAC.TB.Inc.all.mean,	tb_mort_adult=TBMAC.TB.Death.adult.mean,	tb_mort_all=TBMAC.TB.Death.all.mean,	pop_size_adult=TBMAC.PopSize.adult,	pop_size_all=TBMAC.PopSize.all.mean,	pop_size_all_2025=56666*1000, tb_treat=350000, tb_treat_MDR= 6494, annual_decline_tb_incid=TBMAC.TB.Inc.decline.mean*100, per_MDR_new_2002 = "", per_MDR_retreat_2002 = "",	per_tb_notif_HIV_pos=TBMAC.HIV.TB.prev.mean,	HIV_prev_adult=TBMAC.HIV.prev.adult.mean,	per_HIV_pos_ART=35,	per_tb_deaths_HIV_pos=TBMAC.HIV.TB.death.mean)

         target.low=data.frame(tb_incid_adult=TBMAC.TB.Inc.adult.low, tb_incid_all=TBMAC.TB.Inc.all.low,	tb_mort_adult=TBMAC.TB.Death.adult.low,	tb_mort_all=TBMAC.TB.Death.all.low,	pop_size_adult=TBMAC.PopSize.adult,	pop_size_all=TBMAC.PopSize.all.low,	pop_size_all_2025=56666*1000, tb_treat=315000, tb_treat_MDR= 5844, annual_decline_tb_incid=TBMAC.TB.Inc.decline.low*100, per_MDR_new_2002 = "", per_MDR_retreat_2002 = "",	per_tb_notif_HIV_pos=TBMAC.HIV.TB.prev.low,	HIV_prev_adult=TBMAC.HIV.prev.adult.low,	per_HIV_pos_ART=35,	per_tb_deaths_HIV_pos=TBMAC.HIV.TB.death.low)

         target.high=data.frame(tb_incid_adult=TBMAC.TB.Inc.adult.high, tb_incid_all=TBMAC.TB.Inc.all.high,	tb_mort_adult=TBMAC.TB.Death.adult.high,	tb_mort_all=TBMAC.TB.Death.all.high,	pop_size_adult=TBMAC.PopSize.adult,	pop_size_all=TBMAC.PopSize.all.high,	pop_size_all_2025=56666*1000, tb_treat=385000, tb_treat_MDR= 7143, annual_decline_tb_incid=TBMAC.TB.Inc.decline.high*100, per_MDR_new_2002 = "", per_MDR_retreat_2002 = "",	per_tb_notif_HIV_pos=TBMAC.HIV.TB.prev.high,	HIV_prev_adult=TBMAC.HIV.prev.adult.high,	per_HIV_pos_ART=35,	per_tb_deaths_HIV_pos=TBMAC.HIV.TB.death.high)
                    
      calibration=rbind(target.low,model.res,target.high)
      }


      all.A.short=all.A[rep.time]

      ##########################
      #Epi results
      epi.res=data.frame(Intervention=intervention.names[int.nr+1],Scenario=scenario.names[level.nr], Country='south_africa', Year=reportyears[-length(reportyears)], TB_treat_TP=tb_treat_adult[rep.time2]/all.A.short*100000 , TB_treat_FP="", TB_prev=all.A.TB.prev[rep.time]/all.A.short*100000, TB_mort=TB.death.A[rep.time2]/all.A.short*100000, TB_incid=all.A.inc[rep.time2]/all.A.short*100000, Pop_size_adults=all.A[rep.time], MDR_prev = all.A.MDR.prev[rep.time]/all.A[rep.time]*100000, MDR_per_new=PercMDR.TB.inc.all[rep.time2] , MDR_per_retreat="", Per_LTBI=(all.A.TBlat.prev[rep.time])/all.A[rep.time]*100, Per_TB_recent=Perc.Recent.TB.inc.adults[rep.time2], ARI = 100 * (newInf.A[rep.time2]+newInf.C[rep.time2])/all.pop[rep.time], Avg_dur_disease = ave.dur.disease[rep.time], Total_tb_deaths = (TB.death.A[rep.time2]+TB.death.C[rep.time2])/1000)

    


      ##########################
      #DALY results
      daly1=data.frame(Intervention=intervention.names[int.nr+1],Scenario=scenario.names[level.nr], Country='south_africa', Year=reportyears[-length(reportyears)], HIV_neg_TB=nHIV.TB.prev.all[rep.time], HIV_neg_noTB=nHIV.nTB.prev.all[rep.time], HIV_high_TB = "", HIV_high_noTB = "", HIV_mid_TB=HIV.nART.TB.prev.all[rep.time], HIV_mid_noTB=HIV.nART.nTB.prev.all[rep.time], HIV_low_TB="", HIV_low_noTB="", HIV_ART_TB=HIV.ART.TB.prev.all[rep.time],	HIV_ART_noTB=HIV.ART.nTB.prev.all[rep.time] )

      if (max(abs(rowSums(daly1[,c(5,6,9,10,13,14)])-all.pop[rep.time]))>1e-3) {print('mistake in DALY 1'); browser();}

      daly2=data.frame(Intervention=intervention.names[int.nr+1],Scenario=scenario.names[level.nr], Country='south_africa', Year=reportyears[-length(reportyears)],Deaths_0_14=All.annual.death.C[rep.time2], Deaths_15_99=All.annual.death.A[rep.time2])

      ind2035a=which(plot.years==2035)
      ind2035b=which(sol2[,1]==2035)

      daly3.C=data.frame(Intervention=intervention.names[int.nr+1],Scenario=scenario.names[level.nr], Country='south_africa',Age_group="0_14",	HIV_neg_TB=nHIV.TB.prev.C[ind2035b],	HIV_neg_noTB=nHIV.nTB.prev.C[ind2035b], HIV_high_TB = "", HIV_high_noTB = "", HIV_mid_TB=HIV.nART.TB.prev.C[ind2035b],	HIV_mid_noTB=HIV.nART.nTB.prev.C[ind2035b], HIV_low_TB="", HIV_low_noTB="",	HIV_ART_TB=HIV.ART.TB.prev.C[ind2035b],	HIV_ART_noTB=HIV.ART.nTB.prev.C[ind2035b])

      daly3.A=data.frame(Intervention=intervention.names[int.nr+1],Scenario=scenario.names[level.nr], Country='south_africa',Age_group="15_99",	HIV_neg_TB=nHIV.TB.prev.A[ind2035b],	HIV_neg_noTB=nHIV.nTB.prev.A[ind2035b], HIV_high_TB = "", HIV_high_noTB = "", HIV_mid_TB=HIV.nART.TB.prev.A[ind2035b],	HIV_mid_noTB=HIV.nART.nTB.prev.A[ind2035b], HIV_low_TB= "", HIV_low_noTB= "", HIV_ART_TB=HIV.ART.TB.prev.A[ind2035b],	HIV_ART_noTB=HIV.ART.nTB.prev.A[ind2035b])

      daly3=rbind(daly3.C,daly3.A)

      TB.tx.duration=6 / 12 #number of months on treatment for drug sensitive
      MDR.tx.duration=24 / 12 #number of months on treatment for MDR


 #Check:
#TB_diagnoses_IPT' seems about 100 fold too high when compared to 'TB_suspects_IPT', so I wonder if the units are off. Similarly IPT_treatment seems very low compared to what I expected.
#definition
#TB_suspects_IPT		Total number of persons screened for active TB prior to IPT (intervention 6) (in thousands)
#TB_diagnoses_IPT		Total number of persons diagnosed with active TB as a result of screening prior to IPT  (intervention 6) (in thousands)
#IPT_treatment	 	  Treatment of latent TB infection (intervention 6). Enter either [1] total patient-years, or [2] mid-year average of persons on treatment (1 preferred over 2) (in thousands)

#my computations
#Intervention 6 is IPT for HIV positive
TB_suspects_IPT=(Aux.ART.inc.C[rep.time2]+Aux.ART.inc.A[rep.time2]+0.05*(all.A.tx.HIV.prev[rep.time]+all.C.tx.HIV.prev[rep.time]))/1000
#everyone newly on ART is screened, also 5% on ART are screened
#This intervention covers provision of continuous IPT to all individuals receiving ART, regardless of TST status.
#assumption: 5% of the population on ART is screened per year for active TB

TB_diagnoses_IPT=(Aux.ART.TBd.inc.A[rep.time2])/1000
#fraction of those screened (TB_suspects_IPT) who are found to be TB positive
IPT_treatment=Aux.IPT.HIV.ART.A.prev[rep.time]+Aux.IPT.HIV.ART.C.prev[rep.time]


     econ.res=data.frame(Intervention=intervention.names[int.nr+1],Scenario=scenario.names[level.nr], Country='south_africa', Year=reportyears[-length(reportyears)], TB_yr_pre_diag_atmpt=(all.C.TB.h.prev[rep.time]+all.A.TB.h.prev[rep.time])/1000, TB_yr_post_diag_atmpt=(all.C.TB.d.prev[rep.time]+all.A.TB.d.prev[rep.time])/1000,	TB_yr_total= (all.C.TB.h.prev[rep.time]+all.A.TB.h.prev[rep.time]+all.C.TB.d.prev[rep.time]+all.A.TB.d.prev[rep.time])/1000, TB_suspects_passive="", TB_diagnoses_passive=(passive.diagnoses.A[rep.time2]+passive.diagnoses.C[rep.time2])/1000,	TB_suspects_ACF="",	TB_diagnoses_ACF=(Aux.ACF.C[rep.time2]+Aux.ACF.A[rep.time2])/1000,	DST="",	Reg_1st_line_tx_naiv ="", Reg_1st_line_tx_expd="", Reg_1st_line_all=TB.tx.duration*(all.C.tx.s[rep.time2]+all.A.tx.s[rep.time2])/1000, Reg_MDR=MDR.tx.duration*(all.C.tx.r[rep.time2]+all.A.tx.r[rep.time2])/1000, Per_Reg_1st_line_priv="", Per_Reg_MDR_priv="", LTBI_screen=(Aux.IPT.nHIV.C.inc[rep.time2]+Aux.IPT.nHIV.A.inc[rep.time2])/1000, LTBI_treatment=(Aux.IPT.nHIV.C.prev[rep.time]+Aux.IPT.nHIV.A.prev[rep.time])/1000, TB_suspects_IPT=TB_suspects_IPT, TB_diagnoses_IPT=TB_diagnoses_IPT,  IPT_treatment=IPT_treatment, ART_init=(Aux.ART.inc.A[rep.time2]+Aux.ART.inc.C[rep.time2])/1000,	ART=(HIV.ART.nTB.prev.all[rep.time]+HIV.ART.TB.prev.all[rep.time])/1000)



      
      ##########################
      #producing results plots
      #also writing results to screen
      ##########################
      
      if (ploton==1)
      {     
        graphics.off(); #close all graphics windows  
        #a plot with many panels 
        ww=12; wh=9; #size is 17.5cm, needs to be in inches 17.5/2.54 approx 7
        windows(width=ww, height=wh)					#for windows: opens window of the specified dimensions
        
        par(mfrow=c(4,5))
        par(oma=c(0.2,0.2,4,0.2)) #outer margins - bottom, left, top, right margins
        par(mar=c(2, 3, 2, 1)) #bottom, left, top, right margins
        par(mgp = c(2, 1, 0)) #move axes labels closer to axes
     
        #par(cex.main=1.6,cex.lab=1.6,cex.axis=1.2)
        #par(cex=1.5)
        
        t.start.plot=2000;
     

        ##########################
        #population numbers
        ##########################
        plot(sol[,"time"],all.pop,log="y",type="l",col="blue",ylim=c(5e6,5.5e7),xlim=c(t.start.plot,endyear),xlab="",main="Population Size (R)",ylab="Numbers")
        lines(sol[,"time"],all.A,col="green")
        lines(sol[,"time"],all.C,col="magenta")
        #TB-MAC targets
        points(2012,TBMAC.PopSize.all.mean,col="blue",pch=5,lwd=1)
        points(2012,TBMAC.PopSize.all.low,col="blue",pch=4,lwd=1)
        points(2012,TBMAC.PopSize.all.high,col="blue",pch=4,lwd=1)
        points(2012,TBMAC.PopSize.adult,col="green",pch=5,lwd=1)
        points(2012,TBMAC.PopSize.all.mean-TBMAC.PopSize.adult,col="magenta",pch=5,lwd=1)
        legend('bottomright',c('All','Adults','Children'),col=c("blue","green","magenta"),lwd=2,lty=1,bty = "n")
        #print(sprintf('Children/Adult/Total Pop Size: %f, %f, %f',tail(all.C,1),tail(all.A,1),tail(all.C+all.A,1)))
     
        ##########################
        #TB disease incidence
        ##########################
        #all per 100K
        plot(plot.years,(all.C.inc+all.A.inc)/all.pop[rep.time3]*100000,type="l",col="blue",ylim=c(500,2000),xlim=c(t.start.plot,endyear),xlab="",main='TB incidences (R)',ylab="Annual Incidence per 100K")
        lines(plot.years,(all.A.inc)/all.A[rep.time3]*100000,col="red")
        legend('topright',c('TB disease - all','TB disease - adult'),col=c("blue","red"),lwd=2,lty=1,bty = "n")
        #TB-MAC targets
        lines(sol2[rep.time3,"time"],TBMAC.TB.Inc.all.vec,col="blue",lty=3,lwd=2) #all incidence - declining
        lines(sol2[rep.time3,"time"],TBMAC.TB.Inc.adult.vec,col="red",lty=3,lwd=2) #all incidence
        points(2012,TBMAC.TB.Inc.all.mean,col="blue",pch=5,lwd=1)
        points(2012,TBMAC.TB.Inc.all.low,col="blue",pch=4,lwd=1)
        points(2012,TBMAC.TB.Inc.all.high,col="blue",pch=4,lwd=1)
        points(2012,TBMAC.TB.Inc.adult.mean,col="red",pch=5,lwd=1)
        points(2012,TBMAC.TB.Inc.adult.low,col="red",pch=4,lwd=1)
        points(2012,TBMAC.TB.Inc.adult.high,col="red",pch=4,lwd=1)
    
        ##########################
        #TB disease prevalence 
        ##########################
        #all per 100K
        plot(sol2[,"time"],(all.A.TB.prev+all.C.TB.prev)/all.pop*100000,type="l",col="blue",ylim=c(0,2500),xlim=c(t.start.plot,endyear),xlab="",ylab="per 100K",main='TB disease prevalence (R)') #all TB prevalence
        lines(sol[,"time"],all.A.TB.prev.long/all.A*100000,col="green")
        lines(sol[,"time"],all.C.TB.prev.long/all.C*100000,col="magenta")
        points(2012,GTB.TB.Prev.all.mean,col="blue",pch=5,lwd=1) #global TB report
        points(2012,GTB.TB.Prev.all.low,col="blue",pch=4,lwd=1)
        points(2012,GTB.TB.Prev.all.high,col="blue",pch=4,lwd=1)
        legend('topright',c('TBd all','TBd among adults','TBd among children'),col=c("blue","green","magenta"),lwd=2,lty=1,bty = "n")
        #print(sprintf('TB disease prevalence all adults/HIV adults: %f, %f ',tail(all.A.TB.prev/Adult.size*100000,1),tail(all.A.TB.HIV.prev/Adult.size*100000,1)))
      
       
        ##########################
        #TB mortality incidence
        ##########################
        plot(sol2[rep.time3,"time"],(TB.death.A+TB.death.C)/all.pop[rep.time3]*100000,type="l",col="blue",ylim=c(1,500),xlim=c(t.start.plot,endyear),xlab="",main='TB mortality (R)',ylab="Annual TB mortality per 100K")
        lines(sol2[rep.time3,"time"],TB.death.A/all.A[rep.time3]*100000,col="red")
        legend('topright',c('TB death - all','TB death - adult'),col=c("blue","red"),lwd=2,lty=1,bty = "n")
        #TB-MAC targets
        points(2012,TBMAC.TB.Death.all.mean,col="blue",pch=5,lwd=1)
        points(2012,TBMAC.TB.Death.all.low,col="blue",pch=4,lwd=1)
        points(2012,TBMAC.TB.Death.all.high,col="blue",pch=4,lwd=1)
        points(2012,TBMAC.TB.Death.adult.mean,col="red",pch=5,lwd=1)
        points(2012,TBMAC.TB.Death.adult.low,col="red",pch=4,lwd=1)
        points(2012,TBMAC.TB.Death.adult.high,col="red",pch=4,lwd=1)
    
        ##########################
        #TB treatments
        ##########################
        plot(sol2[rep.time3,"time"],tb_treat,type="l",col="blue",ylim=c(100000,500000),xlim=c(t.start.plot,endyear),xlab="",main='TB Treatments (R)',ylab="Annual tx starts")
        #TB-MAC targets
        points(2012,315000,col="blue",pch=4,lwd=1) #this is for all, but reporting will be for adults
        points(2012,350000,col="blue",pch=5,lwd=1)
        points(2012,385000,col="blue",pch=4,lwd=1)
        legend('topright',c('TB treatment - all'),col=c("blue"),lwd=2,lty=1,bty = "n")
                
        ##########################
        #MDR Proportion of new TB disease incidence (all ages) 
        ##########################
        #all per 100K
        plot(sol2[rep.time3,"time"],PercMDR.TB.inc.all,type="l",col="blue",ylim=c(0,20),xlim=c(t.start.plot,endyear),xlab="",main='MDR incidence percentage (R)',ylab="Percent")
        lines(sol2[rep.time3,"time"],rep(1.4,length(plot.years)),col="blue",lty=2,lwd=2) #GTB estimate 2012 - low
        lines(sol2[rep.time3,"time"],rep(8.2,length(plot.years)),col="blue",lty=2,lwd=2) #GTB estimate 2012 - high
        legend('topright',c('MDR percentage - all'),col=c("blue"),lwd=2,lty=1,bty = "n")
        #print(sprintf('Percentage TB incidence that is MDR / children: %f, %f',tail((all.MDR.inc)/(all.C.inc+all.A.inc)*100,1),tail(all.C.inc/(all.C.inc+all.A.inc)*100,1)))
        
        
        ##########################
        #TB latency (excluding disease) prevalence 
        ##########################
        #all per 100K
        plot(sol2[,"time"],(all.A.TBlat.prev+all.C.TBlat.prev)/all.pop*100,type="l",col="blue",ylim=c(0,100),xlim=c(t.start.plot,endyear),xlab="",ylab="Percent",main='TB latency prevalence (R)') #all TB prevalence
        lines(sol2[,"time"],all.A.TBlat.prev/all.A*100,col="green")
        lines(sol2[,"time"],all.C.TBlat.prev/all.C*100,col="magenta")
        lines(sol2[,"time"],rep(80,length(sol2[,1])),col="blue",lty=2,lwd=2) #TBfacts.org estimate
        legend('topright',c('all','adults','children'),col=c("blue","green","magenta"),lwd=2,lty=1,bty = "n")
        #print(sprintf('TB latency all / adults / children: %f, %f, %f ',tail((all.A.TBlat.prev+all.C.TBlat.prev)/(all.A+all.C)*100,1),tail(all.A.TBlat.prev/all.A*100,1),tail(all.C.TBlat.prev/all.C*100,1)))        
                
        ##########################
        #Average duration of disease
        ##########################
        plot(sol2[,"time"],ave.dur.disease,type="l",col="blue",ylim=c(0,2),xlim=c(t.start.plot,endyear),xlab="",ylab="Years",main='Duration of disease (R)')
        legend('topright',c('average time of dis'),col=c("blue"),lwd=2,lty=1,bty = "n")
      
        
        ##########################
        #"Annual risk of Mtb infection (n new infections/total population)"
        ##########################
        plot(sol2[rep.time3,"time"],(newInf.C+newInf.A)/all.pop[rep.time3]*100,type="l",col="blue",ylim=c(0,10),xlim=c(t.start.plot,endyear),xlab="",main='Annual risk of infection (R)',ylab="Percent")
        legend('topright',c('annual risk - all'),col=c("blue"),lwd=2,lty=1)
        lines(sol2[rep.time3,"time"],rep(4,length(plot.years)),col="blue",lty=3,lwd=2) #estimate from Kritzinger 2009 Trop Med - seems around 1-4 from different papers
        lines(sol2[rep.time3,"time"],rep(1,length(plot.years)),col="blue",lty=3,lwd=2) #estimate from Kritzinger 2009 Trop Med - seems around 1-4 from different papers
        #print(sprintf('Annual risk of MTB infection: %f',tail((newInf.C+newInf.A)/(all.C+all.A)*100,1)))
    
        ##########################
        #Percent TB disease due to recent infection
        ##########################
        plot(sol2[rep.time3,"time"],Perc.Recent.TB.inc.all,type="l",col="blue",ylim=c(0,100),xlim=c(t.start.plot,endyear),xlab="",ylab="Percent",main='TB due to recent infection (R)') 
        legend('topright',c('percent - all'),col=c("blue"),lwd=2,lty=1)
      
        ##########################
        #Percentage of MDR among all latently infected
        ##########################
        plot(sol2[,"time"],(all.A.MDRlat.prev+all.C.MDRlat.prev)/(all.C.TBlat.prev+all.A.TBlat.prev)*100 ,type="l",col="blue",ylim=c(0,20),xlim=c(t.start.plot,endyear),xlab="",ylab="Percent",main='MDR among TB infected')
        lines(sol2[,"time"],all.A.MDRlat.prev/(all.A.TBlat.prev)*100,col="red")
        legend('topright',c('MDR prevalence - all','MDR prevalence - adults'),col=c("blue","red"),lwd=2,lty=1,bty = "n")
               
                
        ##########################
        #adults with HIV and ART
        ##########################
        plot(sol2[,"time"],(all.A.HIV.prev)/all.A*100,type="l",col="blue",ylim=c(0,100),xlim=c(t.start.plot,endyear),main="HIV prevalence - Adults",xlab="",ylab="Percent")
        lines(sol2[,"time"],(all.A.tx.HIV.prev)/(all.A.HIV.prev)*100,col="red")
        lines(sol2[,"time"],(all.A.tx.TB.HIV.prev)/(all.A.TB.HIV.prev)*100,col="green")
        legend('topright',c('HIV+','ART among HIV+','ART among TB+HIV+'),col=c("blue","red","green"),lwd=2,lty=1,bty = "n")
        #TB-MAC targets
        points(2012,TBMAC.HIV.prev.adult.mean,col="blue",pch=5,lwd=1)
        points(2012,TBMAC.HIV.prev.adult.low,col="blue",pch=4,lwd=1)
        points(2012,TBMAC.HIV.prev.adult.high,col="blue",pch=4,lwd=1)
        lines(art.year,art.level,col="red",lty=3,lwd=2)
        #print(sprintf('percent adults HIV / ART among HIV / ART among HIV-TB: %f, %f, %f',tail((all.A.HIV.prev)/all.A*100,1),tail((all.A.tx.HIV.prev)/(all.A.HIV.prev)*100,1),tail((all.A.tx.TB.HIV.prev)/(all.A.TB.HIV.prev)*100,1) ))
      
        ##########################
        #TB-HIV co-infection incidence and death targets
        ##########################
        #all in percent
        plot(sol2[rep.time3,"time"],(all.C.HIV.inc+all.A.HIV.inc)/(all.C.inc+all.A.inc)*100,type="l",col="blue",ylim=c(0,100),xlim=c(t.start.plot,endyear),xlab="",main='TB-HIV co-infection',ylab="Percent")
        lines(sol2[rep.time3,"time"],(all.C.HIV.death+all.A.HIV.death)/(TB.death.C+TB.death.A)*100,col="red")
        legend('bottom',c('HIV among incident TB - all','HIV among TB deaths - all'),col=c("blue","red"),lwd=2,lty=1,bty = "n")
        #TB-MAC targets
        points(2012,TBMAC.HIV.TB.prev.mean,col="blue",pch=5,lwd=1)
        points(2012,TBMAC.HIV.TB.prev.low,col="blue",pch=4,lwd=1)
        points(2012,TBMAC.HIV.TB.prev.high,col="blue",pch=4,lwd=1)
        points(2012,TBMAC.HIV.TB.death.mean,col="red",pch=5,lwd=1)
        points(2012,TBMAC.HIV.TB.death.low,col="red",pch=4,lwd=1)
        points(2012,TBMAC.HIV.TB.death.high,col="red",pch=4,lwd=1)
      
        ##########################
        #children with HIV 
        ##########################
        plot(sol2[,"time"],all.C.HIV.prev/all.C*100,type="l",col="blue",log="",ylim=c(0,10),xlim=c(t.start.plot,endyear),main="HIV prevalence - Children",xlab="",ylab="Percent")
        legend('bottom',c('HIV+'),col=c("blue"),lwd=2,lty=1,bty = "n")
        #internal targets, not TB-MAC
        lines(sol2[,"time"],rep(UNAIDS.HIV.Prev.C*100,length(sol2[,"time"])),col="blue",lty=2,lwd=2)
        #lines(sol2[,"time"],rep(100*hiv.treat.frac,length(sol2[,"time"])),col="green",lty=3,lwd=2)
        #print(sprintf('percent children with HIV no ART/HIV ART: %f, %f, %f',tail((sol2[,"S.C.n"]+sol2[,"Ls.C.n"]+sol2[,"Lr.C.n"]+sol2[,"Ihs.C.n"]+sol2[,"Ihr.C.n"])/all.C*100,1),tail((sol2[,"S.C.u"]+sol2[,"Ls.C.u"]+sol2[,"Lr.C.u"]+sol2[,"Ihs.C.u"]+sol2[,"Ihr.C.u"])/all.C*100,1),tail((sol2[,"S.C.t"]+sol2[,"Ls.C.t"]+sol2[,"Lr.C.t"]+sol2[,"Ihs.C.t"]+sol2[,"Ihr.C.t"])/all.C*100,1)))
    
    
                        
        ##########################
        #Percent of new TB disease incidence among children
        ##########################
        plot(sol2[rep.time3,"time"],(all.C.inc)/(all.C.inc+all.A.inc)*100,type="l",col="blue",ylim=c(0,100),xlim=c(t.start.plot,endyear),xlab="",main='TB incidence children',ylab="Percent")
        lines(sol2[rep.time3,"time"],rep(13,length(plot.years)),col="blue",lty=2,lwd=2) #13% estimate for all new TB cases among children from WHO GTR 2013
        legend('topright',c('% TB incidence in children'),col=c("blue"),lwd=2,lty=1,bty="n")

       
       ##########################
       # IPT in HIV+ on ART (sus and lat TB status) - baseline
       ##########################
       plot(sol2[,"time"],(Aux.IPT.HIV.ART.C.prev+Aux.IPT.HIV.ART.A.prev)/(all.HIV.ART.prev.C+all.HIV.ART.prev.A)*100,type="l",col="blue",ylim=c(0,10),xlim=c(t.start.plot,endyear),xlab="",main='IPT of HIV+ART base',ylab="Percent",lty=1,lwd=2)
       lines(sol2[rep.time3,"time"],rep(base.HIV.IPT*100,length(plot.years)),col="blue",lty=2,lwd=2) #2% estimate of IPT among HIV+ at baseline
       legend('topright',c('% IPT among HIV+ART'),col=c("blue"),lwd=2,lty=1,bty="n")

       ##########################
       # IPT in HIV+ on ART (sus and lat TB status) - for scale-up intervention #6
       ##########################
       plot(sol2[,"time"],(Aux.IPT.HIV.C.prev+Aux.IPT.HIV.A.prev)/(all.HIV.ART.prev.C+all.HIV.ART.prev.A)*100,type="l",col="blue",ylim=c(0,100),xlim=c(t.start.plot,endyear),xlab="",main='IPT of HIV+ART scaleup',ylab="Percent",lty=1,lwd=2)
       lines(c(2015:2020),c(5,10,25,40,60,75),col="blue",lty=2,lwd=2) #5% target for IPT among HIV+ for intervention 5
       legend('topright',c('% IPT among HIV+ART'),col=c("blue"),lwd=2,lty=1,bty="n")


       ##########################
       # IPT in HIV-
       ##########################
       plot(sol2[,"time"],(Aux.IPT.nHIV.C.prev+Aux.IPT.nHIV.A.prev)/(TBlat.nHIV.nMDR.prev.C+TBlat.nHIV.MDR.prev.C+TBlat.nHIV.nMDR.prev.A+TBlat.nHIV.MDR.prev.A)*100,type="l",col="blue",ylim=c(0,2),xlim=c(t.start.plot,endyear),xlab="",main='IPT of HIV- with LTB',ylab="Percent",lty=1,lwd=2)
       lines(sol2[rep.time3,"time"],rep(0,length(plot.years)),col="blue",lty=2,lwd=2) #no IPT among HIV- at baseline
       legend('topright',c('% IPT among HIV-'),col=c("blue","red"),lwd=2,lty=1,bty="n")
    
       
        ##########################
        #Hidden and observed infected compartments to check ACF
        ##########################
        plot(sol[,"time"],all.A.TB.h.prev.long,type="l",col="blue",ylim=c(1e3,1e7),xlim=c(t.start.plot,endyear),log="y",xlab="",main=' ',ylab="person-months",lty=1)      
        lines(sol[,"time"],all.A.TB.d.prev.long,col="red",lty=1,lwd=2) 
        lines(sol[,"time"],all.C.TB.h.prev.long,col="blue",lty=2,lwd=2) 
        lines(sol[,"time"],all.C.TB.d.prev.long,col="red",lty=2,lwd=2) 
        legend('topright',c('Hidden - adults','Observed - adults','Hidden - children','Observed - children'),col=c("blue","red","blue","red"),lwd=2,lty=c(1,1,2,2))
       
       pngfilename=paste('intervention-',intervention.names[int.nr+1],'-scenario-',level.nr,'.png',sep="")
       pdffilename=paste('intervention-',intervention.names[int.nr+1],'-scenario-',level.nr,'.pdf',sep="")
       #dev.print(device=pdf,width=ww,height=wh, paper="special",file=pdffilename) 
       dev.print(device=png,width=ww,height=wh,units="in",res=600,file=pngfilename)
  
     
     } #end ploton=0/1 statement
     print(sprintf('finished intervention %s at level %s',intervention.names[int.nr+1],scenario.names[level.nr])); 
    
     
     epi.res.all=rbind(epi.res.all,epi.res)                                                                                
     daly1.all=rbind(daly1.all,daly1)                                                                                
     daly2.all=rbind(daly2.all,daly2)                                                                                
     daly3.all=rbind(daly3.all,daly3)        
     econ.res.all=rbind(econ.res.all,econ.res)                                                                        



     if (int.nr==0) {write.csv(calibration,"TB-MAC-UGA-calibration.csv")}
  
    #save matrix with results to several large csv files
    #filename1=paste("TB-scenario-",as.character(int.nr),"-numbers.csv",sep="");
    write.csv(epi.res.all,"TB-MAC-UGA-Epi-results.csv");
    write.csv(daly1.all,"TB-MAC-UGA-DALY1-results.csv");
    write.csv(daly2.all,"TB-MAC-UGA-DALY2-results.csv");
    write.csv(daly3.all,"TB-MAC-UGA-DALY3-results.csv");
    write.csv(econ.res.all,"TB-MAC-UGA-ECON-results.csv");
  
  

   } #finish inner loop over intervention strengths
      
#browser()

} #finish outer loop over intervention types
